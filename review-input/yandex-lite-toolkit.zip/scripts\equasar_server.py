#!/usr/bin/env python3
"""
equasar_server.py — Кроссплатформенный локальный сервер eQuasar (Windows / Linux / macOS)
Имитирует сервер активации Яндекса, отдавая Станции Лайт команду на включение постоянного ADB.
Работает на портах 80 (HTTP) и 443 (HTTPS) с встроенными сертификатами.
"""

import http.server
import ssl
import sys
import os
import threading
import socketserver

import argparse

SYNC_INFO_PAYLOAD = b'{"status":"ok","config":{"account_config":{"spotter":"alisa"},"device_config":{"name":"quasar"},"system_config":{"adbd":{"remoteActivation":true,"network":true,"fullDurationMs":31536000000}},"adbd":{"remoteActivation":true,"network":true,"fullDurationMs":31536000000}},"subscription":{"mode":"transaction"}}'
NO_UPDATE_PAYLOAD = b'{"hasUpdate":false}'
DOWNGRADE_PAYLOAD = b'{"hasUpdate":true,"version":"0.369.1.48.4790768027.20261019.297","downloadUrl":"https://cdnriqbxswemmatxzibl.svc.cdn.yandex.net/yandexmicro/ota/user/ef296679-9bfd-4e13-b5ea-01526a4074ec/0.369.1.48.4790768027.20261019.297.zip","crc32":627265552,"critical":true,"fallbackUrl":"https://quasar.s3.yandex.net/yandexmicro/ota/user/ef296679-9bfd-4e13-b5ea-01526a4074ec/0.369.1.48.4790768027.20261019.297.zip","fallbackIp":"93.158.134.158","updateId":"154302"}'

CURRENT_UPDATE_PAYLOAD = NO_UPDATE_PAYLOAD

class EquasarHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        client = self.client_address[0]
        proto = "HTTPS" if isinstance(self.connection, ssl.SSLSocket) else "HTTP"
        print(f"[{client}] [{proto}] {self.command} {self.path} -> {args[1] if len(args) > 1 else 'OK'}")
        sys.stdout.flush()

    def do_HEAD(self):
        self.handle_request(send_body=False)

    def do_GET(self):
        self.handle_request(send_body=True)

    def do_POST(self):
        self.handle_request(send_body=True)

    def handle_request(self, send_body=True):
        clean_path = self.path.split("?")[0]
        
        if clean_path in ["/generate_204", "/gen_204", "/ncsi.txt", "/hotspot-detect.html"]:
            self.send_response(204)
            self.end_headers()
            return
            
        if clean_path in ["/get_sync_info", "/quasar/get_sync_info"]:
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(SYNC_INFO_PAYLOAD)))
            self.end_headers()
            if send_body:
                self.wfile.write(SYNC_INFO_PAYLOAD)
            print("  >>> [SUCCESS] Колонке отправлена команда активации ADB! <<<")
            return
            
        if clean_path in ["/check_updates", "/quasar/check_updates"]:
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(CURRENT_UPDATE_PAYLOAD)))
            self.end_headers()
            if send_body:
                self.wfile.write(CURRENT_UPDATE_PAYLOAD)
            if CURRENT_UPDATE_PAYLOAD == DOWNGRADE_PAYLOAD:
                print("  >>> [DOWNGRADE] Колонке отдана уязвимая прошивка 0.369.1.48! <<<")
            else:
                print("  >>> [SECURITY] Запрос обновлений заблокирован (hasUpdate: false) <<<")
            return
            
        # Дефолтный ответ
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", "2")
        self.end_headers()
        if send_body:
            self.wfile.write(b"OK")

class ReusableServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        ex_type, ex_val, _ = sys.exc_info()
        print(f"[{client_address[0]}] [TLS/TCP Ошибка] {ex_type.__name__}: {ex_val}")
        sys.stdout.flush()

def run_http(port=80):
    try:
        httpd = ReusableServer(("0.0.0.0", port), EquasarHandler)
        print(f"[*] HTTP сервер слушает порт {port}...")
        httpd.serve_forever()
    except Exception as e:
        print(f"[!] Ошибка запуска HTTP на порту {port}: {e}")

def sni_callback(ssl_sock, server_name, initial_context):
    try:
        peer = ssl_sock.getpeername()[0]
    except Exception:
        peer = "unknown"
    print(f"[{peer}] [TLS SNI] host='{server_name}'")
    sys.stdout.flush()
    return None

def run_https(cert_file, key_file, port=443):
    try:
        httpd = ReusableServer(("0.0.0.0", port), EquasarHandler)
        ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
        ctx.load_cert_chain(certfile=cert_file, keyfile=key_file)
        ctx.sni_callback = sni_callback
        httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
        print(f"[*] HTTPS сервер слушает порт {port} (с сертификатами)...")
        httpd.serve_forever()
    except Exception as e:
        print(f"[!] Ошибка запуска HTTPS на порту {port}: {e}")

def find_certs():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        (os.path.join(base_dir, "..", "certs", "fullchain.pem"), os.path.join(base_dir, "..", "certs", "quasar-all.key")),
        (os.path.join(base_dir, "..", "nginx-win", "nginx-1.26.2", "conf", "certs", "fullchain.pem"), os.path.join(base_dir, "..", "nginx-win", "nginx-1.26.2", "conf", "certs", "quasar-all.key")),
        (os.path.join(base_dir, "certs", "fullchain.pem"), os.path.join(base_dir, "certs", "quasar-all.key"))
    ]
    for cert_path, key_path in candidates:
        if os.path.exists(cert_path) and os.path.exists(key_path):
            return cert_path, key_path
    return None, None

def main():
    global CURRENT_UPDATE_PAYLOAD
    parser = argparse.ArgumentParser(description="eQuasar Server для Яндекс Станции Лайт 1")
    parser.add_argument("--downgrade", action="store_true", help="Включить отдачу уязвимой прошивки для даунгрейда")
    args = parser.parse_args()

    if args.downgrade:
        CURRENT_UPDATE_PAYLOAD = DOWNGRADE_PAYLOAD

    cert_path, key_path = find_certs()
    if not cert_path or not key_path:
        print("[!] Ошибка: Сертификаты fullchain.pem и quasar-all.key не найдены!")
        sys.exit(1)

    print("==================================================================")
    print("      eQuasar Server — Кроссплатформенный активатор ADB           ")
    print("==================================================================")
    if args.downgrade:
        print("  РЕЖИМ: ДАУНГРЕЙД (отдача уязвимой прошивки 0.369.1.48)")
    else:
        print("  РЕЖИМ: АКТИВАЦИЯ ADB (блокировка OTA + активация порта 5555)")
    print("Готов принимать запросы от Яндекс Станции Лайт.")
    print("Нажмите Ctrl+C для остановки.")
    print("------------------------------------------------------------------")

    t_http = threading.Thread(target=run_http, daemon=True)
    t_https = threading.Thread(target=run_https, args=(cert_path, key_path), daemon=True)

    t_http.start()
    t_https.start()

    try:
        t_http.join()
        t_https.join()
    except KeyboardInterrupt:
        print("\n[*] Сервер остановлен.")

if __name__ == "__main__":
    main()
