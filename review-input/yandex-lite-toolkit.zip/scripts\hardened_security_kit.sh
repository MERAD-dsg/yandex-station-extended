#!/bin/sh
# ==============================================================================
# hardened_security_kit.sh — Тотальное бетонирование Яндекс Станции Лайт 1 (yandexmicro)
# Версия 2.0 (Ultimate Hardened Security):
# 1. Полная блокировка автообновлений Яндекса (OTA) на 3 аппаратных уровнях.
# 2. Фиксация постоянного Root и ADB по сети (:5555) с Fortress Wrapper и chattr +i.
# 3. Полное отключение телеметрии, метрики и слежки в /etc/hosts.
# 4. Защита шаблона DNS-резолвера /data/unbound.conf.head (Cloudflare/Google + refuse).
# 5. Защита аккаунта от удаленного сброса (Anti-Wipe + авто-восстановление в rootkeeper).
# 6. Блокировка скрытой фоновой аудиозаписи (soundLogStorageDir -> /dev/null).
# ==============================================================================

set -u
Q=/system/vendor/quasar
LJ="$Q/launch.json"
PUB="$Q/ota_script.pub"
OTASH="$Q/device_ota_update.sh"
BK=/data/opt/backup
MQ=/data/quasar/activate_adb_quasmodrom
MN=/data/quasar/activate_network_adb
UNBOUND_HEAD=/data/unbound.conf.head
ACCOUNT_FILE=/data/quasar/account_storage.dat
ACCOUNT_BK=/data/quasar/account_storage.dat.backup

DUMMY_PUB='-----BEGIN RSA PUBLIC KEY-----
MIIBCgKCAQEAjQ29hAZE6u/Tly4UA7VIrzN+TweZM0nWT6L0HkYR2evczsdMPhZL
NZxzoZYt5ogstEMydG20xAs9m/k6qZ65sDiLkO9uNaGkR7JUn4+/0bOgJ7MWqgkU
hduLRgRsTQeOjuS16rjwnBxo5vwmb6P2cH+pof9Mri0IOHMuquQzF17YD7vxVIg8
w0c9FEyuoxc0DuedVVU2E9paPp5BkaUtkAqbz7hGzfij9aH8FBg/AkY5CKsFrdPo
gyVfA4qg84zQ7Y7PT7i1WSxPk4ShFtwYO5hYaEiZ+fCsf8Pp8Nd8RSa2kuObXE2X
Qt5QqXHjDoI9jyBgx7igBWAKHvQBwix/AwIDAQAB
-----END RSA PUBLIC KEY-----'

say(){ echo "[*] $*"; }
ok(){ echo "  [OK] $*"; }
err(){ echo "[!] $*" >&2; }

need_root(){
  if [ "$(id -u)" != "0" ]; then
    err "Скрипт должен быть запущен с правами root!"
    exit 1
  fi
}

rw(){
  mount -o remount,rw / 2>/dev/null || { err "Не удалось перемонтировать / в rw"; exit 1; }
}

ro(){
  sync
  mount -o remount,ro / 2>/dev/null
}

backup_files(){
  mkdir -p "$BK" || exit 1
  [ -f "$BK/launch.json.orig" ]          || cp "$LJ"    "$BK/launch.json.orig" 2>/dev/null || true
  [ -f "$BK/ota_script.pub.orig" ]       || cp "$PUB"   "$BK/ota_script.pub.orig" 2>/dev/null || true
  [ -f "$BK/device_ota_update.sh.orig" ] || cp "$OTASH" "$BK/device_ota_update.sh.orig" 2>/dev/null || true
  [ -f "$BK/hosts.orig" ]                || cp "/etc/hosts" "$BK/hosts.orig" 2>/dev/null || true
}

strip_updatesd(){
  awk '
    { lines[NR]=$0 }
    /--updatesd/ { key=NR }
    END{
      if (key==0){ for(i=1;i<=NR;i++) print lines[i]; exit }
      s=0; for(i=key;i>=1;i--){ if(lines[i] ~ /^[[:space:]]*\{[[:space:]]*$/){ s=i; break } }
      e=0; for(i=key;i<=NR;i++){ if(lines[i] ~ /^[[:space:]]*\},?[[:space:]]*$/){ e=i; break } }
      if (s==0 || e==0){ exit }
      for(i=1;i<=NR;i++){ if(i>=s && i<=e) continue; print lines[i] }
    }' "$1"
}

block_ota(){
  say "Уровень 1-3: Бетонирование OTA-обновлений..."
  rw
  backup_files
  
  # 1. Замена публичного ключа верификации подписи обновления
  printf '%s\n' "$DUMMY_PUB" > "$PUB"
  ok "ota_script.pub -> заменён на фейковый RSA-ключ (официальные прошивки отклоняются)"

  # 2. Заглушка апдейтера
  cat << 'EOF' > "$OTASH"
#!/bin/sh
# Disabled permanently by hardened_security_kit
logger -t noupdate "OTA update attempt permanently blocked" 2>/dev/null
exit 0
EOF
  chmod +x "$OTASH"
  ok "device_ota_update.sh -> заменён на заглушку (без флеша и ребута)"

  # 3. Вырезание демона updatesd из launch.json
  if grep -q -- '--updatesd' "$LJ"; then
    TMP=/tmp/.kit_lj.$$
    strip_updatesd "$LJ" > "$TMP" 2>/dev/null
    if grep -q -- '--mediad' "$TMP" && grep -q -- '--platformd' "$TMP"; then
      cat "$TMP" > "$LJ"
      ok "updatesd исключён из автозапуска в launch.json"
    else
      err "Ошибка валидации launch.json, оставлен защищенным ключом"
    fi
    rm -f "$TMP"
  else
    ok "updatesd в launch.json уже отсутствует"
  fi
  ro
}

fortress_adb(){
  say "Фиксация ADB и защита от отключения облаком..."
  rw
  
  # 1. Обёртка Fortress для activate_adb.sh
  ACT="$Q/activate_adb.sh"
  if [ -f "$ACT" ]; then
    if ! grep -q "FORTRESS-WRAPPER" "$ACT"; then
      [ -f "$ACT.orig" ] || cp "$ACT" "$ACT.orig" && chmod 755 "$ACT.orig"
      cat <<'WRAP' > "$ACT"
#!/bin/sh
# FORTRESS-WRAPPER: 'deactivate' -> no-op, 'activate' -> always --network
case " $* " in
  *" deactivate "*)
      echo "`date`: FORTRESS: remote deactivate blocked" >> /data/quasar/quasar_adb.log
      exit 0
      ;;
esac
case " $* " in
  *" activate "*)
      case " $* " in
        *" --network "*) : ;;
        *) set -- "$@" --network ;;
      esac
      ;;
esac
exec /system/vendor/quasar/activate_adb.sh.orig "$@"
WRAP
      chmod 755 "$ACT"
      ok "activate_adb.sh обёрнут в Fortress (команда deactivate заблокирована)"
    else
      ok "Fortress wrapper уже установлен в activate_adb.sh"
    fi
  fi

  # 2. Неубиваемый демон rootkeeper.sh с защитой аккаунта
  mkdir -p /data/quasar
  cat <<'KEEP' > /data/quasar/rootkeeper.sh
#!/bin/sh
M=/data/quasar/activate_adb_quasmodrom
N=/data/quasar/activate_network_adb
listening() { awk '$2 ~ /:15B3$/ && $4=="0A" {f=1} END{exit !f}' /proc/net/tcp 2>/dev/null; }
while :; do
  [ -f "$M" ] || touch "$M"
  [ -f "$N" ] || touch "$N"
  if ! listening; then
    pidof adbd >/dev/null 2>&1 && kill $(pidof adbd) 2>/dev/null
    sleep 1
    start-stop-daemon -S -b -x /usr/bin/adbd 2>/dev/null
  fi
  # Anti-Wipe guard
  if [ ! -s /data/quasar/account_storage.dat ] && [ -s /data/quasar/account_storage.dat.backup ]; then
    cp -p /data/quasar/account_storage.dat.backup /data/quasar/account_storage.dat
  fi
  sleep 60
done
KEEP
  chmod 755 /data/quasar/rootkeeper.sh
  ok "rootkeeper.sh установлен в /data/quasar/"

  # 3. Добавление rootkeeper в onboot.sh
  ONBOOT="$Q/onboot.sh"
  if [ -f "$ONBOOT" ] && ! grep -q rootkeeper "$ONBOOT"; then
    echo '[ -x /data/quasar/rootkeeper.sh ] && /data/quasar/rootkeeper.sh >/dev/null 2>&1 &' >> "$ONBOOT"
    ok "rootkeeper добавлен в системный onboot.sh"
  fi

  # 4. Флаги активации с атрибутом immutable (+i)
  for m in "$MQ" "$MN"; do
    [ -e "$m" ] || : > "$m"
    chattr +i "$m" 2>/dev/null || true
  done
  ok "Маркеры активации ADB защищены атрибутом chattr +i"

  # 5. Запуск adbd если ещё не запущен
  pidof adbd >/dev/null 2>&1 || start-stop-daemon -S -b -x adbd 2>/dev/null || true
  ro
}

block_telemetry_and_surveillance(){
  say "Блокировка серверов телеметрии, слежки и фоновой прослушки..."
  rw
  
  # 1. /etc/hosts Sinkhole
  DOMAINS="
127.0.0.1 clck.yandex.net
127.0.0.1 report.appmetrica.yandex.net
127.0.0.1 appmetrica.yandex.net
127.0.0.1 metrica.yandex.net
127.0.0.1 metrika.yandex.ru
127.0.0.1 mc.yandex.ru
127.0.0.1 telemetry.quasar.yandex.net
127.0.0.1 extmaps-scbh.yandex.net
127.0.0.1 log.appmetrica.yandex.net
127.0.0.1 startup.mobile.yandex.net
127.0.0.1 certificate.mobile.yandex.net
"
  for d in $DOMAINS; do
    if [ "$d" != "127.0.0.1" ]; then
      if ! grep -q "$d" /etc/hosts; then
        echo "127.0.0.1 $d" >> /etc/hosts
      fi
    fi
  done
  ok "11 доменов телеметрии перенаправлены на 127.0.0.1 в /etc/hosts"

  # 2. Патч и фиксация шаблона Unbound DNS
  if [ -d "/data" ]; then
    chattr -i "$UNBOUND_HEAD" 2>/dev/null || true
    cat <<'UHEAD' > "$UNBOUND_HEAD"
server:
	msg-cache-size: 2m
	rrset-cache-size: 2m
	username: "nobody"
	local-zone: "clck.yandex.net." refuse
	local-zone: "clck.yasmina.yango.com." refuse
	local-zone: "report.appmetrica.yandex.net." refuse
	local-zone: "startup.mobile.yandex.net." refuse
forward-zone:
	name: "."
	forward-addr: "1.1.1.1"
	forward-addr: "8.8.8.8"
	forward-addr: "192.168.1.1"
UHEAD
    cp -f "$UNBOUND_HEAD" /etc/unbound/unbound.conf 2>/dev/null || true
    chattr +i "$UNBOUND_HEAD" 2>/dev/null || true
    ok "DNS-шаблон /data/unbound.conf.head защищён (Cloudflare/Google + refuse)"
  fi

  # 3. Блокировка скрытой фоновой аудиозаписи (RandomSoundLogger -> /dev/null)
  rm -rf /data/quasar/soundLogStorageDir /data/quasar/soundLogStorage.dat 2>/dev/null || true
  ln -s /dev/null /data/quasar/soundLogStorageDir 2>/dev/null || true
  ln -s /dev/null /data/quasar/soundLogStorage.dat 2>/dev/null || true
  ok "Канал скрытых звуковых дампов (RandomSoundLogger) перенаправлен в /dev/null"

  # 4. Защита токенов авторизации от удаленного сброса (Anti-Wipe)
  if [ -s "$ACCOUNT_FILE" ]; then
    chattr -i "$ACCOUNT_BK" 2>/dev/null || true
    cp -p "$ACCOUNT_FILE" "$ACCOUNT_BK" 2>/dev/null || true
    chattr +i "$ACCOUNT_BK" 2>/dev/null || true
    ok "Резервная копия токенов аккаунта создана и защищена chattr +i"
  fi

  ro
}

show_status(){
  echo ""
  echo "=========================================================="
  echo "         СТАТУС ТОТАЛЬНОЙ БЕЗОПАСНОСТИ СТАНЦИИ ЛАЙТ 1     "
  echo "=========================================================="
  
  # Проверка ключа OTA
  if grep -q "DUMMY" "$PUB" 2>/dev/null || grep -q "MIIBCgKCAQEAjQ29hAZE" "$PUB" 2>/dev/null; then
    echo "  [OK] Ключ OTA-подписи       : ЗАБЕТОНИРОВАН (поддельный RSA)"
  else
    echo "  [!]  Ключ OTA-подписи       : ЗАВОДСКОЙ (Яндекс может обновить!)"
  fi

  # Проверка скрипта обновления
  if grep -q "disabled permanently" "$OTASH" 2>/dev/null || grep -q "noupdate" "$OTASH" 2>/dev/null; then
    echo "  [OK] Скрипт апдейтера      : ЗАБЛОКИРОВАН (заглушка exit 0)"
  else
    echo "  [!]  Скрипт апдейтера      : АКТИВЕН"
  fi

  # Проверка updatesd
  if grep -q -- '--updatesd' "$LJ" 2>/dev/null; then
    echo "  [!]  Демон updatesd         : АКТИВЕН в launch.json"
  else
    echo "  [OK] Демон updatesd         : ВЫРЕЗАН из launch.json"
  fi

  # Проверка ADB
  if pidof adbd >/dev/null 2>&1; then
    echo "  [OK] Демон ADB (:5555)      : РАБОТАЕТ"
  else
    echo "  [!]  Демон ADB (:5555)      : НЕ ЗАПУЩЕН"
  fi

  # Проверка Fortress
  if grep -q "FORTRESS-WRAPPER" "$Q/activate_adb.sh" 2>/dev/null; then
    echo "  [OK] Защита от сброса ADB   : АКТИВНА (Fortress Wrapper)"
  else
    echo "  [!]  Защита от сброса ADB   : НЕ УСТАНОВЛЕНА"
  fi

  # Проверка Immutable флагов
  if lsattr "$MQ" 2>/dev/null | grep -q "i"; then
    echo "  [OK] Файловая защита ADB    : АКТИВНА (chattr +i immutable)"
  else
    echo "  [!]  Файловая защита ADB    : НЕТ ФЛАГА +i"
  fi

  # Проверка DNS шаблона
  if lsattr "$UNBOUND_HEAD" 2>/dev/null | grep -q "i"; then
    echo "  [OK] DNS Unbound шаблон     : ЗАЩИЩЕН (Cloudflare/Google + chattr +i)"
  else
    echo "  [!]  DNS Unbound шаблон     : Заводской (Яндекс DNS)"
  fi

  # Проверка скрытой записи
  if [ -L "/data/quasar/soundLogStorageDir" ]; then
    echo "  [OK] Скрытая запись звука   : ОБЕЗВРЕЖЕНА (/dev/null)"
  else
    echo "  [!]  Скрытая запись звука   : НЕ ЗАБЛОКИРОВАНА"
  fi

  # Проверка Anti-Wipe
  if [ -f "$ACCOUNT_BK" ]; then
    echo "  [OK] Защита от сброса (Wipe): АКТИВНА (бэкап токенов + chattr +i)"
  else
    echo "  [!]  Защита от сброса (Wipe): Бэкап токенов отсутствует"
  fi

  # Проверка телеметрии
  if grep -q "appmetrica" /etc/hosts 2>/dev/null; then
    echo "  [OK] Блокировка слежки      : АКТИВНА (/etc/hosts sinkhole)"
  else
    echo "  [!]  Блокировка слежки      : ВЫКЛЮЧЕНА"
  fi
  echo "=========================================================="
  echo ""
}

case "${1:-all}" in
  all)
    need_root
    block_ota
    fortress_adb
    block_telemetry_and_surveillance
    show_status
    say "Бетонирование v2.0 успешно завершено! Все 10 рубежей защиты активны."
    ;;
  status)
    show_status
    ;;
  *)
    echo "Использование: $0 [all|status]"
    exit 1
    ;;
esac
