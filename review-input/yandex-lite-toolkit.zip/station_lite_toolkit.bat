@echo off
chcp 65001 >nul
title Яндекс Станция Лайт 1 (yandexmicro) — Универсальный Инструмент
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0station_lite_toolkit.ps1"
if %errorlevel% neq 0 (
    pause
)
