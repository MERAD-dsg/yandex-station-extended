﻿# Requires Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

$Host.UI.RawUI.WindowTitle = "eQuasar - Включение ADB на Яндекс Станции"
Clear-Host
Write-Host "=====================================================================" -ForegroundColor Green
Write-Host "                eQuasar: Включение ADB на Яндекс Станции" -ForegroundColor Green
Write-Host "=====================================================================" -ForegroundColor Green
Write-Host ""

$baseDir = Split-Path -Parent $PSScriptRoot
$nginxDir = Join-Path $baseDir "nginx-win\nginx-1.26.2"
$hostsPath = "$env:SystemRoot\System32\drivers\etc\hosts"
$hostsBackup = "$env:SystemRoot\System32\drivers\etc\hosts.equasar_bak"

# Динамическое определение IP-адреса хот-спота / сетевого адаптера ПК
$detectedIP = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object {
    $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*"
} | Sort-Object {
    if ($_.InterfaceAlias -match "Hotspot|Хот-спот|Wi-Fi|Беспроводная") { 0 } else { 1 }
} | Select-Object -First 1).IPAddress

if (-not $detectedIP) { $detectedIP = "127.0.0.1" }
$hotspotIP = $detectedIP
Write-Host "[*] Определен активный IP-адрес ПК: $hotspotIP" -ForegroundColor Cyan

# Backup hosts
if (-not (Test-Path $hostsBackup)) {
    Write-Host "[*] Создание резервной копии hosts..." -ForegroundColor Gray
    Copy-Item $hostsPath $hostsBackup -Force
}

# Update hosts
Write-Host "[*] Настройка перенаправлений DNS в файле hosts..." -ForegroundColor Cyan
$currentHosts = [System.IO.File]::ReadAllText($hostsPath, [System.Text.Encoding]::UTF8)
$cleanHosts = [System.Text.RegularExpressions.Regex]::Replace($currentHosts, "(?s)\r?\n?# === EQUASAR REDIRECT START ===.*?# === EQUASAR REDIRECT END ===\r?\n?", "")

$entries = @(
    "",
    "# === EQUASAR REDIRECT START ===",
    "$hotspotIP quasar.yandex.net",
    "$hotspotIP quasar.yandex.ru",
    "$hotspotIP scbh.yandex.net",
    "# === EQUASAR REDIRECT END ===",
    ""
)
$redirectBlock = $entries -join "`r`n"

[System.IO.File]::WriteAllText($hostsPath, ($cleanHosts.TrimEnd() + "`r`n" + $redirectBlock), [System.Text.Encoding]::UTF8)
ipconfig /flushdns | Out-Null
Write-Host "[OK] Домены quasar и scbh перенаправлены на ПК. Голос и сервисы Алисы оставлены штатными." -ForegroundColor Green

# Kill previous Nginx instances
Write-Host "[*] Перезапуск Nginx..." -ForegroundColor Cyan
taskkill /f /im nginx.exe 2>$null | Out-Null
Start-Sleep -Milliseconds 800

Set-Location $nginxDir
Start-Process -FilePath ".\nginx.exe" -WorkingDirectory $nginxDir
Start-Sleep -Seconds 2

# Verify Nginx
try {
    $resp = & curl.exe -k -s -H "Host: quasar.yandex.net" https://127.0.0.1/check_updates
    if ($resp -match "hasUpdate") {
        Write-Host "[OK] Nginx успешно запущен и готов к обновлению/активации Станции Лайт!" -ForegroundColor Green
    } else {
        Write-Host "[!] Ответ от Nginx получен, но payload не совпал: $resp" -ForegroundColor Yellow
    }
} catch {
    Write-Host "[!] Ошибка проверки Nginx: $_" -ForegroundColor Red
}

Write-Host ""
Write-Host "=====================================================================" -ForegroundColor Yellow
Write-Host "                    ИНСТРУКЦИЯ ДЛЯ СТАНЦИИ ЛАЙТ:" -ForegroundColor Yellow
Write-Host "=====================================================================" -ForegroundColor Yellow
Write-Host "1. Ваша колонка сейчас находится на Factory-прошивке (20230208.factory)." -ForegroundColor White
Write-Host "2. Сервер Nginx теперь настроен отдать ей релизную прошивку 0.369.1.46 (от 13.10.2026)." -ForegroundColor White
Write-Host "3. Подключите / настройте Станцию через 'Дом с Алисой' (подключив к хот-споту ПК)." -ForegroundColor White
Write-Host "4. Колонка запросит обновление (/check_updates), скачает подписанную Yandex-прошивку и обновится." -ForegroundColor White
Write-Host "5. После обновления она автоматически получит adbd remoteActivation и откроет порт 5555!" -ForegroundColor Green
Write-Host "---------------------------------------------------------------------" -ForegroundColor Gray
Write-Host "Ниже в реальном времени отображается лог обращений колонки к серверу." -ForegroundColor Gray
Write-Host "Нажмите Ctrl+C для выхода. Изменения сохраняются до запуска 3_STOP_AND_RESTORE." -ForegroundColor Gray
Write-Host "=====================================================================" -ForegroundColor Yellow
Write-Host ""

$logPath = Join-Path $nginxDir "logs\quasar.access.log"
if (-not (Test-Path $logPath)) {
    New-Item -ItemType File -Path $logPath -Force | Out-Null
}

Get-Content -Path $logPath -Wait -Tail 20
