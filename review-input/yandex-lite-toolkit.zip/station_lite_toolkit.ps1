﻿<#
.SYNOPSIS
    Yandex Station Lite 1 (yandexmicro) — Универсальный инструмент: Взлом, Даунгрейд, Бетонирование v2.0 и Бункер-режим.
.DESCRIPTION
    РАЗРАБОТАНО ИСКЛЮЧИТЕЛЬНО ДЛЯ:
    - Яндекс Станция Лайт (1-е поколение, 2021 г., модель YNDX-00025, кодовое имя yandexmicro, процессор Amlogic A113X).

    НЕ ПОДДЕРЖИВАЕТ ДРУГИЕ МОДЕЛИ:
    - Станция Лайт 2 (plum)
    - Станция Мини 1, 2, 3, 3 Про (yandexmini, yandexmini_2, bergamot, pickle)
    - Станция 1, 2, 3 (yandexstation, yandexmidi, orion)
    - Станция Миди (cucumber), Станция Макс (yandexstation_2), Дуо Макс (chiron), Стрит (mango)
    - Сторонние колонки с Алисой (JBL, Elari, Prestigio, LG)
#>

[CmdletBinding()]
param()

$baseDir = $PSScriptRoot
if (-not $baseDir) {
    $baseDir = if ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path } else { (Get-Location).Path }
}
$adbCandidates = @(
    (Join-Path $baseDir "tools\adb\adb.exe"),
    (Join-Path $baseDir "yandex-restore\tools\adb\adb.exe"),
    (Join-Path $baseDir "adb\adb.exe")
)
$adbBin = "adb"
foreach ($cand in $adbCandidates) {
    if (Test-Path $cand) {
        $adbBin = $cand
        break
    }
}
$scriptDir = Join-Path $baseDir "scripts"
$nginxDir = Join-Path $baseDir "nginx-win\nginx-1.26.2"
$nginxConf = Join-Path $nginxDir "conf\nginx.conf"

$defaultIP = "192.168.1.55"

function Print-Header {
    Clear-Host
    Write-Host "╔══════════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║     ЯНДЕКС СТАНЦИЯ ЛАЙТ 1 (2021 | yandexmicro | SoC Amlogic A113X)       ║" -ForegroundColor Yellow
    Write-Host "║       Универсальный комбайн: Взлом, Даунгрейд, Защита v2 и Бункер        ║" -ForegroundColor White
    Write-Host "╚══════════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host "  СХЕМА РАБОТЫ:" -ForegroundColor DarkGray
    Write-Host "   • Стандартный взлом : [2] ВЗЛОМ -> [4] БЕТОНИРОВАНИЕ v2.0 -> ГОТОВО!" -ForegroundColor Gray
    Write-Host "   • Если прошивка новая: [3] ДАУНГРЕЙД -> [2] ВЗЛОМ -> [4] БЕТОНИРОВАНИЕ" -ForegroundColor Gray
    Write-Host "──────────────────────────────────────────────────────────────────────────" -ForegroundColor DarkCyan
}

function Discover-SpeakerIP {
    Write-Host "[*] Автопоиск Станции Лайт в локальной сети и на хот-споте..." -ForegroundColor Cyan
    
    # 1. Проверяем уже подключенные adb устройства
    $adbDevs = & $adbBin devices 2>$null
    foreach ($line in ($adbDevs -split "`r?`n")) {
        if ($line -match '^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):5555\s+device') {
            $foundIP = $matches[1]
            Write-Host "  [+] Найдена подключенная колонка по ADB: $foundIP" -ForegroundColor Green
            return $foundIP
        }
    }

    # 2. Проверяем хот-спот Windows (192.168.137.x)
    $arp = arp -a
    $hotspotClients = @()
    foreach ($line in ($arp -split "`r?`n")) {
        if ($line -match '^\s*(192\.168\.137\.\d+)\s+([0-9a-f-]+)\s+динамический') {
            $hotspotClients += $matches[1]
        }
    }
    foreach ($hip in $hotspotClients) {
        Write-Host "  [*] Проверка клиента хот-спота ($hip)..." -ForegroundColor Gray
        & $adbBin connect "${hip}:5555" 2>$null | Out-Null
        $devs = & $adbBin devices
        if ($devs -match "$hip:5555\s+device") {
            Write-Host "  [+] Станция найдена на хот-споте: $hip!" -ForegroundColor Green
            return $hip
        }
    }

    # 3. Проверяем дефолтный сохраненный IP
    Write-Host "  [*] Проверка сохранённого IP ($defaultIP)..." -ForegroundColor Gray
    & $adbBin connect "${defaultIP}:5555" 2>$null | Out-Null
    $devs = & $adbBin devices
    if ($devs -match "$defaultIP:5555\s+device") {
        Write-Host "  [+] Станция найдена по адресу: $defaultIP" -ForegroundColor Green
        return $defaultIP
    }

    # 4. Сканируем ARP таблицу локальной сети на открытый порт ADB (5555)
    $arpIPs = @()
    foreach ($line in ($arp -split "`r?`n")) {
        if ($line -match '^\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\s+') {
            $ip = $matches[1]
            if ($ip -notmatch '(\.255|\.1)$' -and $ip -ne "127.0.0.1" -and $ip -ne $defaultIP) {
                $arpIPs += $ip
            }
        }
    }
    foreach ($cand in ($arpIPs | Select-Object -Unique)) {
        $tcp = Test-NetConnection -ComputerName $cand -Port 5555 -WarningAction SilentlyContinue -InformationLevel Quiet
        if ($tcp) {
            Write-Host "  [+] Найдено устройство с открытым ADB: $cand!" -ForegroundColor Green
            return $cand
        }
    }

    Write-Host "  [-] Автопоиск не обнаружил активный порт 5555. Используем: $defaultIP" -ForegroundColor Yellow
    return $defaultIP
}

function Test-SpeakerConnection {
    param([string]$targetIP)
    Write-Host "[*] Диагностика подключения и безопасности $targetIP..." -ForegroundColor Cyan
    Write-Host ""

    # 1. Пинг
    $ping = Test-Connection -ComputerName $targetIP -Count 1 -Quiet -ErrorAction SilentlyContinue
    if (-not $ping) {
        Write-Host "  [-] ICMP Пинг    : Нет ответа. (Колонка выключена или не подключена к Wi-Fi)" -ForegroundColor Red
    } else {
        Write-Host "  [+] ICMP Пинг    : В сети (связь с роутером/ПК есть)" -ForegroundColor Green
    }

    # 2. ADB
    & $adbBin connect "${targetIP}:5555" | Out-Null
    $adbDevices = & $adbBin devices
    $adbOk = $false
    if ($adbDevices -match "${targetIP}:5555\s+device") {
        Write-Host "  [+] ADB (:5555)  : ОТКРЫТ! Доступен полный Root-доступ." -ForegroundColor Green
        $adbOk = $true
    } else {
        Write-Host "  [-] ADB (:5555)  : ЗАКРЫТ. Требуется выполнить [2] ВЗЛОМ или [3] ДАУНГРЕЙД." -ForegroundColor Yellow
    }

    # 3. SSH
    $sshCheck = & ssh.exe -o StrictHostKeyChecking=no -o ConnectTimeout=2 -o BatchMode=yes root@$targetIP "id" 2>$null
    if ($sshCheck -match "uid=0\(root\)") {
        Write-Host "  [+] SSH (:22)    : ОТКРЫТ (Dropbear)! Вход без пароля работает." -ForegroundColor Green
    } else {
        Write-Host "  [-] SSH (:22)    : Закрыт (будет установлен на шаге бетонирования)." -ForegroundColor Gray
    }

    # 4. Проверка статуса Quasar
    if ($adbOk) {
        $qStatus = & $adbBin -s "${targetIP}:5555" shell "ps | grep -E 'maind|platformd' | grep -v grep" 2>$null
        if ($qStatus -match "maind") {
            Write-Host "  [+] Quasar/Алиса : АКТИВЕН (штатный режим)" -ForegroundColor Green
        } else {
            Write-Host "  [!] Quasar/Алиса : ВЫКЛЮЧЕН (Режим Бункера / Изоляция)" -ForegroundColor Yellow
        }

        # 5. Вывод отчета бетонирования
        Write-Host ""
        Write-Host "[*] Проверка 10 рубежей бетонирования на колонке..." -ForegroundColor Cyan
        & $adbBin -s "${targetIP}:5555" push "$scriptDir\hardened_security_kit.sh" /tmp/hardened_security_kit.sh 2>$null | Out-Null
        & $adbBin -s "${targetIP}:5555" shell "chmod +x /tmp/hardened_security_kit.sh; /tmp/hardened_security_kit.sh status"
    }
    Write-Host ""
}

function Set-NginxUpdatePayload {
    param([bool]$hasUpdate)
    if (-not (Test-Path $nginxConf)) { return }
    $content = [System.IO.File]::ReadAllText($nginxConf, [System.Text.Encoding]::UTF8)
    if ($hasUpdate) {
        $payload = 'return 200 ''{"hasUpdate":true,"version":"0.369.1.48.4790768027.20261019.297","downloadUrl":"https://cdnriqbxswemmatxzibl.svc.cdn.yandex.net/yandexmicro/ota/user/ef296679-9bfd-4e13-b5ea-01526a4074ec/0.369.1.48.4790768027.20261019.297.zip","crc32":627265552,"critical":true,"fallbackUrl":"https://quasar.s3.yandex.net/yandexmicro/ota/user/ef296679-9bfd-4e13-b5ea-01526a4074ec/0.369.1.48.4790768027.20261019.297.zip","fallbackIp":"93.158.134.158","updateId":"154302"}'';'
    } else {
        $payload = 'return 200 ''{"hasUpdate":false}'';'
    }
    $updated = [System.Text.RegularExpressions.Regex]::Replace($content, '(?s)location = /check_updates\s*\{[^}]*\}', "location = /check_updates {`r`n            default_type application/json;`r`n            $payload`r`n        }")
    [System.IO.File]::WriteAllText($nginxConf, $updated, [System.Text.Encoding]::UTF8)
}

function Run-EquasarActivation {
    Write-Host ""
    Write-Host "==========================================================================" -ForegroundColor Yellow
    Write-Host "            ШАГ: ПОЛУЧЕНИЕ ПЕРВИЧНОГО ДОСТУПА К ADB (eQuasar)             " -ForegroundColor Yellow
    Write-Host "==========================================================================" -ForegroundColor Yellow
    Write-Host "Этот режим запускает локальный сервер eQuasar на ПК для активации ADB."
    Write-Host ""
    Write-Host "ПОШАГОВАЯ ИНСТРУКЦИЯ:" -ForegroundColor Cyan
    Write-Host " 1. Включите 'Мобильный хот-спот' в Windows (Параметры -> Сеть -> Мобильный хот-спот)."
    Write-Host " 2. Убедитесь, что колонка в режиме настройки (светодиод переливается цветами)."
    Write-Host "    (Если колонка уже привязана — сбросьте её: выключите питание, зажмите микрофон,"
    Write-Host "    вставьте провод и держите 7 секунд до звука сброса)."
    Write-Host " 3. В приложении 'Дом с Алисой' на телефоне начните подключение колонки и выберите"
    Write-Host "    имя и пароль хот-спота вашего ПК."
    Write-Host " 4. Наш сервер перехватит запрос и скомандует колонке: 'remoteActivation: true'."
    Write-Host " 5. Колонка откроет порт 5555 (ADB) с правами Root!"
    Write-Host ""
    
    $confirm = Read-Host "Запустить сервер активации eQuasar? (Y/N)"
    if ($confirm -eq "Y" -or $confirm -eq "y" -or $confirm -eq "д" -or $confirm -eq "Д") {
        Set-NginxUpdatePayload -hasUpdate $false
        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$scriptDir\start_equasar.ps1`"" -Verb RunAs
        Write-Host "[OK] Сервер запущен в отдельном окне. После подключения колонки выполните [4] БЕТОНИРОВАНИЕ!" -ForegroundColor Green
    }
}

function Run-Downgrade {
    Write-Host ""
    Write-Host "==========================================================================" -ForegroundColor Yellow
    Write-Host "           ШАГ: ДАУНГРЕЙД / ОТКАТ ПРОШИВКИ НА УЯЗВИМУЮ ВЕРСИЮ            " -ForegroundColor Yellow
    Write-Host "==========================================================================" -ForegroundColor Yellow
    Write-Host "Используется, если ваша Станция Лайт обновилась на закрытую прошивку Яндекса."
    Write-Host "Сервер eQuasar отдаст колонке подписанную официальную уязвимую версию"
    Write-Host "прошивки Яндекса (0.369.1.48), которая поддерживает открытие сетевого ADB."
    Write-Host ""
    Write-Host "ПОШАГОВАЯ ИНСТРУКЦИЯ:" -ForegroundColor Cyan
    Write-Host " 1. Включите 'Мобильный хот-спот' в Windows."
    Write-Host " 2. Сбросьте Станцию Лайт к заводским: выключите питание, зажмите микрофон,"
    Write-Host "    включите провод и удерживайте кнопку 7 секунд до звука сброса."
    Write-Host " 3. В приложении 'Дом с Алисой' подключите Станцию Лайт к хот-споту ПК."
    Write-Host " 4. Колонка запросит обновление, скачает уязвимую прошивку (займёт 3-5 минут)"
    Write-Host "    и перезагрузится."
    Write-Host " 5. ЧТО ДЕЛАТЬ ПОСЛЕ ДАУНГРЕЙДА:" -ForegroundColor Magenta
    Write-Host "    • Нажмите [1] для проверки связи." -ForegroundColor White
    Write-Host "    • Если порт 5555 открыт — сразу переходите к шагу [4] БЕТОНИРОВАНИЕ." -ForegroundColor White
    Write-Host "    • Если порт закрыт — просто запустите [2] ВЗЛОМ и переподключите её." -ForegroundColor White
    Write-Host ""

    $confirm = Read-Host "Включить режим даунгрейда и запустить сервер? (Y/N)"
    if ($confirm -eq "Y" -or $confirm -eq "y" -or $confirm -eq "д" -or $confirm -eq "Д") {
        Set-NginxUpdatePayload -hasUpdate $true
        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$scriptDir\start_equasar.ps1`"" -Verb RunAs
        Write-Host "[OK] Сервер даунгрейда запущен! После перезагрузки колонки проверьте связь через [1]." -ForegroundColor Green
    }
}

function Run-Hardening {
    param([string]$targetIP)
    Write-Host ""
    Write-Host "==========================================================================" -ForegroundColor Yellow
    Write-Host "       ШАГ: ТОТАЛЬНОЕ БЕТОНИРОВАНИЕ ПРОШИВКИ И ОТКЛЮЧЕНИЕ СЛЕЖКИ v2.0     " -ForegroundColor Yellow
    Write-Host "==========================================================================" -ForegroundColor Yellow
    Write-Host "Выполняется ОДИН раз после открытия ADB (порт 5555)."
    Write-Host ""
    Write-Host "ЧТО БУДЕТ ЗАБЕТОНИРОВАНО НА КОЛОНКЕ:" -ForegroundColor Cyan
    Write-Host " [1] ПОЛНАЯ БЛОКИРОВКА ОБНОВЛЕНИЙ ЯНДЕКСА (3 АППАРАТНЫХ УРОВНЯ):"
    Write-Host "     - Подмена ota_script.pub на фейковый RSA-ключ."
    Write-Host "     - Замена установщика device_ota_update.sh на заглушку exit 0."
    Write-Host "     - Вырезание демона updatesd из launch.json."
    Write-Host " [2] ФИКСАЦИЯ ROOT И НЕУБИВАЕМЫЙ ADB С CHATTR +I:"
    Write-Host "     - Fortress Wrapper для activate_adb.sh (команда отзыва ADB блокируется)."
    Write-Host "     - Демон rootkeeper.sh циклически держит порт 5555 активным."
    Write-Host "     - Маркеры активации зафиксированы аппаратным флагом chattr +i (immutable)."
    Write-Host " [3] ВЫРЕЗКА ТЕЛЕМЕТРИИ В /ETC/HOSTS:"
    Write-Host "     - 11 серверов сбора метрики и трекинга замкнуты на 127.0.0.1."
    Write-Host " [4] ПАТЧ И ФИКСАЦИЯ ШАБЛОНА UNBOUND DNS:"
    Write-Host "     - DNS Яндекса заменены на Cloudflare (1.1.1.1) и Google (8.8.8.8)."
    Write-Host "     - Шаблон /data/unbound.conf.head защищен chattr +i от перезаписи Quasar."
    Write-Host " [5] БЛОКИРОВКА СКРЫТОЙ ФОНОВОЙ ПРОСЛУШКИ:"
    Write-Host "     - Дампы RandomSoundLogger залинкованы на /dev/null."
    Write-Host " [6] ЗАЩИТА ТОКЕНОВ АККАУНТА ОТ СБРОСА (ANTI-WIPE):"
    Write-Host "     - Резервная копия account_storage.dat.backup защищена chattr +i."
    Write-Host "     - Демон rootkeeper автоматически восстанавливает авторизацию при атаке."
    Write-Host ""

    $confirm = Read-Host "Применить тотальное бетонирование v2.0 на $targetIP? (Y/N)"
    if ($confirm -ne "Y" -and $confirm -ne "y" -and $confirm -ne "д" -and $confirm -ne "Д") {
        return
    }

    $kitScript = Join-Path $scriptDir "hardened_security_kit.sh"
    Write-Host "[*] Передача скрипта безопасности на колонку..." -ForegroundColor Cyan
    
    & $adbBin connect "${targetIP}:5555" | Out-Null
    & $adbBin -s "${targetIP}:5555" push $kitScript /tmp/hardened_security_kit.sh
    & $adbBin -s "${targetIP}:5555" shell "chmod +x /tmp/hardened_security_kit.sh"

    Write-Host "[*] Выполнение бетонирования в системе..." -ForegroundColor Cyan
    & $adbBin -s "${targetIP}:5555" shell "/tmp/hardened_security_kit.sh all"
}

function Toggle-BunkerMode {
    param([string]$targetIP)
    Write-Host ""
    Write-Host "==========================================================================" -ForegroundColor Yellow
    Write-Host "               РЕЖИМ БУНКЕРА (QUASAR KILL SWITCH / LOCKDOWN)              " -ForegroundColor Yellow
    Write-Host "==========================================================================" -ForegroundColor Yellow
    Write-Host "Позволяет моментально изолировать колонку от серверов Яндекса или вернуть назад."
    Write-Host ""

    & $adbBin connect "${targetIP}:5555" | Out-Null
    $qCheck = & $adbBin -s "${targetIP}:5555" shell "ps | grep -E 'maind|platformd' | grep -v grep" 2>$null
    $isQuasarActive = ($qCheck -match "maind")

    if ($isQuasarActive) {
        Write-Host "Текущий статус: " -NoNewline
        Write-Host "ШТАТНЫЙ РЕЖИМ (Quasar активен, Алиса подключена к серверам Яндекса)" -ForegroundColor Green
        Write-Host ""
        Write-Host "Действие: " -NoNewline
        Write-Host "ВКЛЮЧИТЬ РЕЖИМ БУНКЕРА (ИЗОЛЯЦИЯ)" -ForegroundColor Red
        Write-Host "  - Quasar (Алиса) будет полностью выключен."
        Write-Host "  - Аппаратный файрвол заблокирует ВЕСЬ исходящий интернет во внешний мир."
        Write-Host "  - Локальная сеть, ADB, SSH и локальные службы останутся активными."
        Write-Host "  - Яндекс физически не сможет послать никаких команд на колонку."
        Write-Host ""
        $c = Read-Host "Включить режим бункера и изолировать колонку? (Y/N)"
        if ($c -eq "Y" -or $c -eq "y" -or $c -eq "д" -or $c -eq "Д") {
            Write-Host "[*] Применение изоляции и отключение Quasar..." -ForegroundColor Cyan
            & $adbBin -s "${targetIP}:5555" shell "mount -o remount,rw /; cp -f /system/vendor/quasar/launch.json.disabled /system/vendor/quasar/launch.json; cp -f /data/quasar/firewall_lockdown.sh /etc/init.d/S41firewall_lockdown; chmod +x /etc/init.d/S41firewall_lockdown; mount -o remount,ro /; /etc/init.d/S41firewall_lockdown start; sync; reboot"
            Write-Host "[OK] Режим бункера активирован! Колонка перезагружается в режим изоляции." -ForegroundColor Green
        }
    } else {
        Write-Host "Текущий статус: " -NoNewline
        Write-Host "РЕЖИМ БУНКЕРА (Колонка изолирована от интернета, Quasar отключен)" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Действие: " -NoNewline
        Write-Host "ВЫКЛЮЧИТЬ БУНКЕР / ВОСКРЕСИТЬ АЛИСУ" -ForegroundColor Green
        Write-Host "  - Quasar будет восстановлен."
        Write-Host "  - Доступ к облаку Алисы откроется (распознавание речи, музыка)."
        Write-Host "  - Все 10 уровней защиты (блокировка OTA, DNS, фейковый ключ) останутся активны!"
        Write-Host ""
        $c = Read-Host "Воскресить Алису и вернуть штатный режим? (Y/N)"
        if ($c -eq "Y" -or $c -eq "y" -or $c -eq "д" -or $c -eq "Д") {
            Write-Host "[*] Восстановление конфигурации Quasar и открытие доступа..." -ForegroundColor Cyan
            & $adbBin -s "${targetIP}:5555" shell "mount -o remount,rw /; cp -f /system/vendor/quasar/launch.json.enabled /system/vendor/quasar/launch.json; rm -f /etc/init.d/S41firewall_lockdown; mount -o remount,ro /; sync; reboot"
            Write-Host "[OK] Алиса включена! Колонка перезагружается в штатный защищённый режим." -ForegroundColor Green
        }
    }
}

function Stop-Equasar {
    Write-Host "[*] Остановка локального сервера eQuasar и очистка файла hosts..." -ForegroundColor Cyan
    $stopScript = Join-Path $scriptDir "stop_equasar.ps1"
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$stopScript`"" -Verb RunAs
    Write-Host "[OK] Сервер остановлен, системный файл hosts возвращён в исходное состояние." -ForegroundColor Green
}

# --- Главный цикл меню ---
$targetIP = Discover-SpeakerIP

while ($true) {
    Print-Header
    Write-Host "Целевой IP-адрес Станции Лайт: " -NoNewline
    Write-Host "$targetIP" -ForegroundColor Green
    Write-Host ""
    Write-Host " [1] 📡 Проверить статус связи и безопасность (Пинг, ADB, SSH, 10 рубежей)" -ForegroundColor White
    Write-Host " [2] 🔓 ВЗЛОМ: Запустить eQuasar (получение постоянного ADB)" -ForegroundColor Yellow
    Write-Host " [3] ⬇️  ДАУНГРЕЙД: Откат прошивки на уязвимую через eQuasar" -ForegroundColor Cyan
    Write-Host " [4] 🛡️  БЕТОНИРОВАНИЕ v2.0: Тотальная блокировка OTA + слежки + флеш-защита" -ForegroundColor Green
    Write-Host " [5] 🏰 РЕЖИМ БУНКЕРА: Экстренная изоляция от Яндекса (Quasar Kill Switch)" -ForegroundColor Magenta
    Write-Host " [6] 🔍 АВТОПОИСК: Найти IP колонки в сети автоматически" -ForegroundColor DarkCyan
    Write-Host " [7] 💻 КОНСОЛЬ: Открыть Root Shell по SSH" -ForegroundColor White
    Write-Host " [8] 🛑 СТОП: Закрыть сервер eQuasar и вернуть hosts" -ForegroundColor Gray
    Write-Host " [9] ✏️  Сменить IP-адрес вручную" -ForegroundColor DarkYellow
    Write-Host " [0] 🚪 Выход" -ForegroundColor DarkGray
    Write-Host ""
    
    $choice = Read-Host "Выберите действие (0-9)"
    switch ($choice) {
        "1" { Test-SpeakerConnection $targetIP; Pause }
        "2" { Run-EquasarActivation; Pause }
        "3" { Run-Downgrade; Pause }
        "4" { Run-Hardening $targetIP; Pause }
        "5" { Toggle-BunkerMode $targetIP; Pause }
        "6" { 
            $found = Discover-SpeakerIP
            if ($found) { $targetIP = $found }
            Pause
        }
        "7" { 
            Write-Host "[*] Подключение к SSH root@$targetIP..." -ForegroundColor Green
            & ssh.exe -o StrictHostKeyChecking=no root@$targetIP
        }
        "8" { Stop-Equasar; Pause }
        "9" {
            $newIP = Read-Host "Введите новый IP-адрес колонки"
            if ($newIP -match '^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$') {
                $targetIP = $newIP
            } else {
                Write-Host "[!] Некорректный IP-адрес!" -ForegroundColor Red
                Start-Sleep -Seconds 1
            }
        }
        "0" { exit }
        default { Write-Host "Неверный выбор!" -ForegroundColor Red; Start-Sleep -Milliseconds 800 }
    }
}
