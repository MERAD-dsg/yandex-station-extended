# AGENTS.md — Справочник для AI-ассистентов (Yandex Station Lite 1 Toolkit v2.0)

> [!WARNING]
> **ОТКАЗ ОТ ОТВЕТСТВЕННОСТИ (DISCLAIMER):**  
> Данное ПО предоставляется "AS IS". Автор не несёт ответственности за любые возможные повреждения, сбои, потерю гарантии или окирпичивание вашей Яндекс Станции. Все действия производятся исключительно под личную ответственность пользователя.

> **Назначение документа:**  
> Этот файл предназначен для автономных AI-агентов (Claude, GPT, Cursor, Antigravity, Copilot и др.), работающих с данным репозиторием. Здесь описана архитектура, способы неинтерактивного запуска, алгоритмы автоматической диагностики и критические правила безопасности.

---

## 1. Аппаратный профиль и архитектура

| Параметр | Значение |
| :--- | :--- |
| **Устройство** | Яндекс Станция Лайт (1-е поколение, 2021 г.) |
| **Кодовое имя платы** | `yandexmicro` (Yandex Station Micro v1.2) |
| **Модель** | `YNDX-00025` |
| **Процессор (SoC)** | Amlogic A113X / AXG (4x ARM Cortex-A53 @ 1.2 GHz) |
| **Память NAND** | 256 MB SLC NAND Flash (`/dev/mtd0` ... `/dev/mtd7`) |
| **Оперативная память** | 512 MB DDR3/DDR4 |
| **ОС** | Linux 4.9.68 (aarch64 ядро) |
| **Юзерспейс (Rootfs)** | Buildroot / 32-bit `armhf` (ELFCLASS32) |
| **Сетевые порты** | ADB: `5555` (root, без авторизации), SSH Dropbear: `22` (root, без пароля) |

---

## 2. Критические аппаратные ограничения (НЕ НАРУШАТЬ)

1. **Внешний Type-C НЕ имеет линий данных:**
   * На разъёме Type-C физически распаяны ТОЛЬКО `+5V` и `GND`. Линии `D+` и `D-` не выведены наружу.
   * Все подключения производятся **исключительно по Wi-Fi (ADB / SSH)**.
2. **Аппаратный сторожевой таймер (Hardware Watchdog):**
   * В ядре активен `/sbin/watchdog -t 1 -T 5 /dev/watchdog`.
   * **КАТЕГОРИЧЕСКИ ЗАПРЕЩЕНО выполнять `killall quasar_launcher2`!** Плата уходит в аппаратный ребут через 5 секунд.
   * Для безопасного перезапуска системы всегда используйте: `sync; reboot`.
3. **Несовместимость 32-bit ALSA dmix и 64-bit процессов:**
   * Базовая система Quasar скомпилирована как 32-bit `armhf`. Пакеты Entware (`/opt`) — 64-bit `aarch64`.
   * Любые аудиодемоны обязаны быть 32-битными `armhf`, иначе вызов `dmix` упадёт с ошибкой `unable to create IPC shm instance`.
4. **Сброс к заводским настройкам:**
   * Выполняется **удержанием кнопки микрофона** при подаче питания в течение 7 секунд.

---

## 3. Механизм взлома, даунгрейда и защиты v2.0

1. **Вектор eQuasar (MITM активация):**
   * При первичной настройке колонка обращается к `https://quasar.yandex.net/get_sync_info`.
   * Локальный сервер eQuasar перехватывает запрос благодаря валидной цепочке сертификатов (eMudhra -> кросс-корень AAA Certificate Services).
   * Отдаётся JSON с флагом `adbd.remoteActivation: true`. Встроенный скрипт `/system/vendor/quasar/activate_adb.sh` запускает сетевой ADB на порту `5555`.
2. **Откат прошивки (Downgrade):**
   * Сервер eQuasar отдаёт официальную подписанную уязвимую версию прошивки Яндекса `0.369.1.48`.
3. **10 Рубежей Бетонирования (Hardening Suite v2.0):**
   1. Подмена `ota_script.pub` на фейковый RSA-ключ.
   2. Замена `device_ota_update.sh` на заглушку `exit 0`.
   3. Вырезание демона `updatesd` из `launch.json`.
   4. Fortress Wrapper для `activate_adb.sh`.
   5. Сторожевой пёс `rootkeeper.sh` на порту 5555.
   6. Блокировка 11 доменов телеметрии в `/etc/hosts`.
   7. Патч шаблона `/data/unbound.conf.head` (DNS 1.1.1.1 + 8.8.8.8, блокировка телеметрии).
   8. Файловая неизменяемость UBIFS (`chattr +i` на маркеры ADB и DNS).
   9. Блокировка фоновой записи звука `RandomSoundLogger` (симлинк на `/dev/null`).
   10. Защита токенов аккаунта `account_storage.dat.backup` с авто-восстановлением.
4. **Режим Бункера (Quasar Kill Switch):**
   * Моментальное отключение Quasar и включение WAN-файрвола (`S41firewall_lockdown`) для полной изоляции устройства от Яндекса.

---

## 4. Инструкция для автономного выполнения агентом (Headless / CLI)

### А. Автоматический поиск IP колонки
```powershell
# В Windows через PowerShell:
$arp = Get-NetNeighbor -AddressFamily IPv4 | Where-Object { $_.State -ne 'Permanent' -and $_.IPAddress -notlike '127.*' }
foreach ($entry in $arp) {
    $t = New-Object Net.Sockets.TcpClient
    $iar = $t.BeginConnect($entry.IPAddress, 5555, $null, $null)
    if ($iar.AsyncWaitHandle.WaitOne(150, $false)) {
        try { $t.EndConnect($iar); Write-Output "FOUND_SPEAKER_IP: $($entry.IPAddress)"; break } catch {}
    }
    $t.Close()
}
```

```bash
# В Linux через Bash:
for ip in $(ip neigh show | awk '{print $1}'); do
    nc -z -w 1 "$ip" 5555 2>/dev/null && echo "FOUND_SPEAKER_IP: $ip" && break
done
```

### Б. Проверка статуса сервисов и 10 рубежей
```bash
adb connect <SPEAKER_IP>:5555
adb -s <SPEAKER_IP>:5555 push scripts/hardened_security_kit.sh /tmp/hardened_security_kit.sh
adb -s <SPEAKER_IP>:5555 shell "chmod +x /tmp/hardened_security_kit.sh && /tmp/hardened_security_kit.sh status"
```

### В. Применение бетонирования v2.0
```bash
adb -s <SPEAKER_IP>:5555 push scripts/hardened_security_kit.sh /tmp/hardened_security_kit.sh
adb -s <SPEAKER_IP>:5555 shell "chmod +x /tmp/hardened_security_kit.sh && /tmp/hardened_security_kit.sh all"
```

---

## 5. Структура каталога тулкита

```text
yandex-lite-toolkit/
├── AGENTS.md                  <- Этот файл (справочник для AI-агентов)
├── README.md                  <- Пользовательская инструкция
├── station_lite_toolkit.bat   <- Windows 1-клик лаунчер
├── station_lite_toolkit.ps1   <- Главный управляющий PowerShell-скрипт v2.0
├── station_lite_toolkit.sh    <- Универсальный скрипт для Linux / macOS v2.0
├── certs/                     <- Сертификаты eMudhra для MITM перехвата
├── firmware/                  <- Метаданные и файлы даунгрейда
├── scripts/
│   ├── equasar_server.py      <- Локальный кроссплатформенный сервер (активация / даунгрейд)
│   ├── start_equasar.ps1      <- Запуск Nginx / eQuasar под Windows
│   ├── stop_equasar.ps1       <- Остановка сервисов и возврат hosts
│   └── hardened_security_kit.sh <- Скрипт бетонирования v2.0 (10 рубежей)
├── nginx-win/                 <- Автономный портативный Nginx с сертификатами
└── tools/adb/                 <- Автономный комплект ADB для Windows
```
