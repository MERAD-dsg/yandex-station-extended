﻿$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

$Host.UI.RawUI.WindowTitle = 'eQuasar - Остановка и очистка'
Clear-Host
Write-Host '=====================================================================' -ForegroundColor Yellow
Write-Host '                eQuasar: Остановка и восстановление' -ForegroundColor Yellow
Write-Host '=====================================================================' -ForegroundColor Yellow
Write-Host ''

$baseDir = Split-Path -Parent $PSScriptRoot
$nginxDir = Join-Path $baseDir 'nginx-win\nginx-1.26.2'
$hostsPath = "$env:SystemRoot\System32\drivers\etc\hosts"

# 1. Stop Nginx
Write-Host '[*] Остановка Nginx...' -ForegroundColor Cyan
try {
    Set-Location $nginxDir
    & .\nginx.exe -s stop 2>$null
} catch {}
Stop-Process -Name 'nginx' -Force -ErrorAction SilentlyContinue
Write-Host '[OK] Nginx остановлен.' -ForegroundColor Green

# 2. Restore hosts
Write-Host '[*] Очистка файла hosts...' -ForegroundColor Cyan
if (Test-Path $hostsPath) {
    $currentHosts = [System.IO.File]::ReadAllText($hostsPath, [System.Text.Encoding]::UTF8)
    $cleanHosts = [System.Text.RegularExpressions.Regex]::Replace($currentHosts, '(?s)\r?\n?# === EQUASAR REDIRECT START ===.*?# === EQUASAR REDIRECT END ===\r?\n?', '')
    [System.IO.File]::WriteAllText($hostsPath, ($cleanHosts.TrimEnd() + "`r`n"), [System.Text.Encoding]::UTF8)
    ipconfig /flushdns | Out-Null
    Write-Host '[OK] Записи eQuasar удалены из hosts, кэш DNS очищен.' -ForegroundColor Green
}

Write-Host ''
Write-Host '=====================================================================' -ForegroundColor Green
Write-Host 'Система полностью возвращена в штатное состояние!' -ForegroundColor Green
Write-Host '=====================================================================' -ForegroundColor Green
Write-Host ''
Write-Host 'Готово. Нажмите Enter для закрытия...'
$null = Read-Host
