#!/usr/bin/env bash
# ==============================================================================
# Yandex Station Lite 1 (yandexmicro) — Универсальный инструмент (Linux / macOS)
# Взлом через eQuasar, даунгрейд, бетонирование v2.0 и Бункер-режим (Kill Switch).
# РАЗРАБОТАНО СТРОГО ДЛЯ СТАНЦИИ ЛАЙТ 1 (2021, yandexmicro, Amlogic A113X).
# ==============================================================================

set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT_DIR="$BASE_DIR/scripts"
DEFAULT_IP="192.168.1.55"
TARGET_IP="$DEFAULT_IP"

# Цвета терминала
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
GRAY='\033[0;90m'
NC='\033[0m'

print_header() {
    clear
    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}║     ЯНДЕКС СТАНЦИЯ ЛАЙТ 1 (2021 | yandexmicro | SoC Amlogic A113X)       ║${NC}"
    echo -e "║       Универсальный комбайн: Взлом, Даунгрейд, Защита v2 и Бункер        ║"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════════════╝${NC}"
    echo -e "  ${GRAY}СХЕМА РАБОТЫ:${NC}"
    echo -e "   • Стандартный взлом : [2] ВЗЛОМ -> [4] БЕТОНИРОВАНИЕ v2.0 -> ГОТОВО!"
    echo -e "   • Если прошивка новая: [3] ДАУНГРЕЙД -> [2] ВЗЛОМ -> [4] БЕТОНИРОВАНИЕ"
    echo -e "${CYAN}──────────────────────────────────────────────────────────────────────────${NC}"
}

discover_ip() {
    echo -e "${CYAN}[*] Автопоиск Станции Лайт в локальной сети...${NC}"

    # 1. Проверяем adb devices
    if command -v adb >/dev/null 2>&1; then
        local adb_found
        adb_found=$(adb devices | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+:5555[[:space:]]+device' | awk -F: '{print $1}' | head -n1 || true)
        if [ -n "$adb_found" ]; then
            echo -e "  ${GREEN}[+] Найдена подключенная колонка по ADB: $adb_found${NC}"
            TARGET_IP="$adb_found"
            return
        fi
    fi

    # 2. Проверяем дефолтный IP
    if ping -c 1 -W 1 "$DEFAULT_IP" >/dev/null 2>&1; then
        echo -e "  ${GREEN}[+] Станция найдена по адресу: $DEFAULT_IP${NC}"
        TARGET_IP="$DEFAULT_IP"
        return
    fi

    # 3. ARP сканирование
    if command -v arp >/dev/null 2>&1; then
        local arp_candidates
        arp_candidates=$(arp -an | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | grep -vE '(\.255|\.1)$' || true)
        for cand in $arp_candidates; do
            if nc -z -w 1 "$cand" 5555 >/dev/null 2>&1; then
                echo -e "  ${GREEN}[+] Найдено устройство с открытым ADB: $cand!${NC}"
                TARGET_IP="$cand"
                return
            fi
        done
    fi

    echo -e "  ${YELLOW}[-] Автопоиск не обнаружил активный порт 5555. Используется: $DEFAULT_IP${NC}"
}

check_connection() {
    echo -e "${CYAN}[*] Диагностика подключения и безопасности $TARGET_IP...${NC}\n"
    
    # 1. Пинг
    if ping -c 1 -W 2 "$TARGET_IP" >/dev/null 2>&1; then
        echo -e "  ${GREEN}[+] ICMP Пинг    : В сети (связь с роутером/ПК есть)${NC}"
    else
        echo -e "  ${RED}[-] ICMP Пинг    : Нет ответа (проверьте питание или сеть)${NC}"
    fi

    # 2. ADB
    local adb_ok=0
    if command -v adb >/dev/null 2>&1; then
        adb connect "${TARGET_IP}:5555" >/dev/null 2>&1 || true
        if adb devices | grep -q "${TARGET_IP}:5555.*device"; then
            echo -e "  ${GREEN}[+] ADB (:5555)  : ОТКРЫТ! Доступен полный Root-доступ.${NC}"
            adb_ok=1
        else
            echo -e "  ${YELLOW}[-] ADB (:5555)  : ЗАКРЫТ. Требуется выполнить [2] ВЗЛОМ или [3] ДАУНГРЕЙД.${NC}"
        fi
    else
        echo -e "  ${YELLOW}[-] ADB          : Утилита adb не установлена в системе${NC}"
    fi

    # 3. SSH
    if ssh -o StrictHostKeyChecking=no -o ConnectTimeout=2 -o BatchMode=yes "root@$TARGET_IP" "id" 2>/dev/null | grep -q "uid=0"; then
        echo -e "  ${GREEN}[+] SSH (:22)    : ОТКРЫТ (Dropbear)! Вход без пароля работает.${NC}"
    else
        echo -e "  ${YELLOW}[-] SSH (:22)    : Закрыт (будет установлен на шаге бетонирования).${NC}"
    fi

    # 4. Проверка статуса Quasar
    if [ "$adb_ok" -eq 1 ]; then
        local q_status
        q_status=$(adb -s "${TARGET_IP}:5555" shell "ps | grep -E 'maind|platformd' | grep -v grep" 2>/dev/null || true)
        if echo "$q_status" | grep -q "maind"; then
            echo -e "  ${GREEN}[+] Quasar/Алиса : АКТИВЕН (штатный режим)${NC}"
        else
            echo -e "  ${YELLOW}[!] Quasar/Алиса : ВЫКЛЮЧЕН (Режим Бункера / Изоляция)${NC}"
        fi

        echo ""
        echo -e "${CYAN}[*] Проверка 10 рубежей бетонирования на колонке...${NC}"
        adb -s "${TARGET_IP}:5555" push "$SCRIPT_DIR/hardened_security_kit.sh" /tmp/hardened_security_kit.sh >/dev/null 2>&1 || true
        adb -s "${TARGET_IP}:5555" shell "chmod +x /tmp/hardened_security_kit.sh; /tmp/hardened_security_kit.sh status" 2>/dev/null || true
    fi
    echo ""
}

run_equasar() {
    echo ""
    echo -e "${YELLOW}==========================================================================${NC}"
    echo -e "${YELLOW}            ШАГ: ПОЛУЧЕНИЕ ПЕРВИЧНОГО ДОСТУПА К ADB (eQuasar)             ${NC}"
    echo -e "${YELLOW}==========================================================================${NC}"
    echo "Запуск локального сервера активации eQuasar (HTTP :80 + HTTPS :443)."
    echo ""
    echo -e "${CYAN}ПОШАГОВАЯ ИНСТРУКЦИЯ:${NC}"
    echo " 1. Раздайте Wi-Fi сеть (хот-спот) с вашего компьютера/ноутбука."
    echo " 2. Добавьте в /etc/hosts строку: <IP_вашего_ПК> quasar.yandex.net"
    echo " 3. Сбросьте Станцию Лайт: выключите питание, зажмите микрофон, включите провод и держите 7 сек."
    echo " 4. В приложении 'Дом с Алисой' подключите Станцию Лайт к вашему хот-споту."
    echo " 5. Сервер eQuasar отдаст колонке команду активации ADB (:5555)."
    echo ""
    read -rp "Запустить сервер сейчас? (y/N): " confirm
    if [[ "$confirm" =~ ^[YyДд]$ ]]; then
        sudo python3 "$SCRIPT_DIR/equasar_server.py"
    fi
}

run_downgrade() {
    echo ""
    echo -e "${YELLOW}==========================================================================${NC}"
    echo -e "${YELLOW}           ШАГ: ДАУНГРЕЙД / ОТКАТ ПРОШИВКИ НА УЯЗВИМУЮ ВЕРСИЮ            ${NC}"
    echo -e "${YELLOW}==========================================================================${NC}"
    echo "Используется, если ваша Станция Лайт обновилась на закрытую прошивку Яндекса."
    echo "Сервер eQuasar отдаст колонке подписанную официальную уязвимую версию"
    echo "прошивки Яндекса (0.369.1.48), которая поддерживает открытие сетевого ADB."
    echo ""
    echo -e "${CYAN}ПОШАГОВАЯ ИНСТРУКЦИЯ:${NC}"
    echo " 1. Раздайте Wi-Fi сеть (хот-спот) с вашего компьютера/ноутбука."
    echo " 2. Добавьте в /etc/hosts строку: <IP_вашего_ПК> quasar.yandex.net"
    echo " 3. Сбросьте Станцию Лайт к заводским: выключите питание, зажмите микрофон,"
    echo "    включите провод и удерживайте кнопку 7 секунд до звука сброса."
    echo " 4. В приложении 'Дом с Алисой' подключите Станцию Лайт к хот-споту ПК."
    echo " 5. Колонка скачает уязвимую прошивку (3-5 минут) и перезагрузится."
    echo " 6. После отката проверьте связь через [1], а затем выполните [4] БЕТОНИРОВАНИЕ."
    echo ""
    read -rp "Запустить сервер даунгрейда сейчас? (y/N): " confirm
    if [[ "$confirm" =~ ^[YyДд]$ ]]; then
        sudo python3 "$SCRIPT_DIR/equasar_server.py" --downgrade
    fi
}

run_hardening() {
    echo ""
    echo -e "${YELLOW}==========================================================================${NC}"
    echo -e "${YELLOW}       ШАГ: ТОТАЛЬНОЕ БЕТОНИРОВАНИЕ ПРОШИВКИ И ОТКЛЮЧЕНИЕ СЛЕЖКИ v2.0     ${NC}"
    echo -e "${YELLOW}==========================================================================${NC}"
    echo "Выполняется ОДИН раз после открытия ADB (порт 5555)."
    echo ""
    echo -e "${CYAN}ЧТО БУДЕТ ЗАБЕТОНИРОВАНО НА КОЛОНКЕ:${NC}"
    echo " [1] ПОЛНАЯ БЛОКИРОВКА ОБНОВЛЕНИЙ ЯНДЕКСА (3 АППАРАТНЫХ УРОВНЯ):"
    echo "     - Подмена ota_script.pub на фейковый RSA-ключ."
    echo "     - Замена установщика device_ota_update.sh на заглушку exit 0."
    echo "     - Вырезание демона updatesd из launch.json."
    echo " [2] ФИКСАЦИЯ ROOT И НЕУБИВАЕМЫЙ ADB С CHATTR +I:"
    echo "     - Fortress Wrapper для activate_adb.sh (команда отзыва ADB блокируется)."
    echo "     - Демон rootkeeper.sh циклически держит порт 5555 активным."
    echo "     - Маркеры активации зафиксированы аппаратным флагом chattr +i (immutable)."
    echo " [3] ВЫРЕЗКА ТЕЛЕМЕТРИИ В /ETC/HOSTS:"
    echo "     - 11 серверов сбора метрики и трекинга замкнуты на 127.0.0.1."
    echo " [4] ПАТЧ И ФИКСАЦИЯ ШАБЛОНА UNBOUND DNS:"
    echo "     - DNS Яндекса заменены на Cloudflare (1.1.1.1) и Google (8.8.8.8)."
    echo "     - Шаблон /data/unbound.conf.head защищен chattr +i от перезаписи Quasar."
    echo " [5] БЛОКИРОВКА СКРЫТОЙ ФОНОВОЙ ПРОСЛУШКИ:"
    echo "     - Дампы RandomSoundLogger залинкованы на /dev/null."
    echo " [6] ЗАЩИТА ТОКЕНОВ АККАУНТА ОТ СБРОСА (ANTI-WIPE):"
    echo "     - Резервная копия account_storage.dat.backup защищена chattr +i."
    echo "     - Демон rootkeeper автоматически восстанавливает авторизацию при атаке."
    echo ""
    read -rp "Применить тотальное бетонирование v2.0 на $TARGET_IP? (y/N): " confirm
    if [[ "$confirm" =~ ^[YyДд]$ ]]; then
        echo -e "${CYAN}[*] Загрузка и запуск скрипта безопасности...${NC}"
        if command -v adb >/dev/null 2>&1; then
            adb connect "${TARGET_IP}:5555" >/dev/null 2>&1 || true
            adb -s "${TARGET_IP}:5555" push "$SCRIPT_DIR/hardened_security_kit.sh" /tmp/hardened_security_kit.sh
            adb -s "${TARGET_IP}:5555" shell "chmod +x /tmp/hardened_security_kit.sh && /tmp/hardened_security_kit.sh all"
        else
            ssh -o StrictHostKeyChecking=no "root@$TARGET_IP" "cat > /tmp/hardened_security_kit.sh && chmod +x /tmp/hardened_security_kit.sh && /tmp/hardened_security_kit.sh all" < "$SCRIPT_DIR/hardened_security_kit.sh"
        fi
        echo -e "${GREEN}[OK] Бетонирование успешно завершено!${NC}"
    fi
}

toggle_bunker() {
    echo ""
    echo -e "${YELLOW}==========================================================================${NC}"
    echo -e "${YELLOW}               РЕЖИМ БУНКЕРА (QUASAR KILL SWITCH / LOCKDOWN)              ${NC}"
    echo -e "${YELLOW}==========================================================================${NC}"
    echo "Позволяет моментально изолировать колонку от серверов Яндекса или вернуть назад."
    echo ""

    local is_quasar=0
    if command -v adb >/dev/null 2>&1; then
        adb connect "${TARGET_IP}:5555" >/dev/null 2>&1 || true
        local q_check
        q_check=$(adb -s "${TARGET_IP}:5555" shell "ps | grep -E 'maind|platformd' | grep -v grep" 2>/dev/null || true)
        if echo "$q_check" | grep -q "maind"; then
            is_quasar=1
        fi
    fi

    if [ "$is_quasar" -eq 1 ]; then
        echo -e "Текущий статус: ${GREEN}ШТАТНЫЙ РЕЖИМ (Quasar активен, Алиса подключена к Яндексу)${NC}\n"
        echo -e "Действие: ${RED}ВКЛЮЧИТЬ РЕЖИМ БУНКЕРА (ИЗОЛЯЦИЯ)${NC}"
        echo "  - Quasar (Алиса) будет полностью выключен."
        echo "  - Аппаратный файрвол заблокирует ВЕСЬ исходящий интернет во внешний мир."
        echo "  - Локальная сеть, ADB, SSH и локальные службы останутся активными."
        echo "  - Яндекс физически не сможет послать никаких команд на колонку."
        echo ""
        read -rp "Включить режим бункера и изолировать колонку? (y/N): " confirm
        if [[ "$confirm" =~ ^[YyДд]$ ]]; then
            echo -e "${CYAN}[*] Применение изоляции и отключение Quasar...${NC}"
            adb -s "${TARGET_IP}:5555" shell "mount -o remount,rw /; cp -f /system/vendor/quasar/launch.json.disabled /system/vendor/quasar/launch.json; cp -f /data/quasar/firewall_lockdown.sh /etc/init.d/S41firewall_lockdown; chmod +x /etc/init.d/S41firewall_lockdown; mount -o remount,ro /; /etc/init.d/S41firewall_lockdown start; sync; reboot"
            echo -e "${GREEN}[OK] Режим бункера активирован! Колонка перезагружается в режим изоляции.${NC}"
        fi
    else
        echo -e "Текущий статус: ${YELLOW}РЕЖИМ БУНКЕРА (Колонка изолирована от интернета, Quasar отключен)${NC}\n"
        echo -e "Действие: ${GREEN}ВЫКЛЮЧИТЬ БУНКЕР / ВОСКРЕСИТЬ АЛИСУ${NC}"
        echo "  - Quasar будет восстановлен."
        echo "  - Доступ к облаку Алисы откроется (распознавание речи, музыка)."
        echo "  - Все 10 уровней защиты (блокировка OTA, DNS, фейковый ключ) останутся активны!"
        echo ""
        read -rp "Воскресить Алису и вернуть штатный режим? (y/N): " confirm
        if [[ "$confirm" =~ ^[YyДд]$ ]]; then
            echo -e "${CYAN}[*] Восстановление конфигурации Quasar и открытие доступа...${NC}"
            adb -s "${TARGET_IP}:5555" shell "mount -o remount,rw /; cp -f /system/vendor/quasar/launch.json.enabled /system/vendor/quasar/launch.json; rm -f /etc/init.d/S41firewall_lockdown; mount -o remount,ro /; sync; reboot"
            echo -e "${GREEN}[OK] Алиса включена! Колонка перезагружается в штатный защищённый режим.${NC}"
        fi
    fi
}

discover_ip

while true; do
    print_header
    echo -e "Целевой IP-адрес Станции Лайт: ${GREEN}$TARGET_IP${NC}\n"
    echo -e " [1] 📡 Проверить статус связи и безопасность (Пинг, ADB, SSH, 10 рубежей)"
    echo -e " [2] 🔓 ${YELLOW}ВЗЛОМ: Запустить eQuasar (получение постоянного ADB)${NC}"
    echo -e " [3] ⬇️  ${CYAN}ДАУНГРЕЙД: Откат прошивки на уязвимую через eQuasar${NC}"
    echo -e " [4] 🛡️  ${GREEN}БЕТОНИРОВАНИЕ v2.0: Тотальная блокировка OTA + слежки + флеш-защита${NC}"
    echo -e " [5] 🏰 ${MAGENTA}РЕЖИМ БУНКЕРА: Экстренная изоляция от Яндекса (Quasar Kill Switch)${NC}"
    echo -e " [6] 🔍 ${BLUE}АВТОПОИСК: Найти IP колонки в сети автоматически${NC}"
    echo -e " [7] 💻 КОНСОЛЬ: Открыть Root Shell по SSH"
    echo -e " [8] ✏️  Сменить IP-адрес вручную"
    echo -e " [0] 🚪 Выход"
    echo ""
    read -rp "Выберите действие (0-8): " choice
    case "$choice" in
        1) check_connection; read -rp "Нажмите Enter для продолжения..." ;;
        2) run_equasar; read -rp "Нажмите Enter для продолжения..." ;;
        3) run_downgrade; read -rp "Нажмите Enter для продолжения..." ;;
        4) run_hardening; read -rp "Нажмите Enter для продолжения..." ;;
        5) toggle_bunker; read -rp "Нажмите Enter для продолжения..." ;;
        6) discover_ip; read -rp "Нажмите Enter для продолжения..." ;;
        7) ssh -o StrictHostKeyChecking=no "root@$TARGET_IP" ;;
        8) 
            read -rp "Введите новый IP-адрес: " new_ip
            if [[ "$new_ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
                TARGET_IP="$new_ip"
            else
                echo -e "${RED}[!] Некорректный IP-адрес!${NC}"
                sleep 1
            fi
            ;;
        0) exit 0 ;;
        *) echo -e "${RED}Неверный выбор!${NC}"; sleep 1 ;;
    esac
done
