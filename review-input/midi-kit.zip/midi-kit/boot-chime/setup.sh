#!/bin/sh

# Install the startup chime on the Yandex Station Midi.

set -eu

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
host=${SPOTIFY_HOST:-root@192.168.1.107}
install_dir=/data/local/boot-chime

ssh -o BatchMode=yes "$host" "mkdir -p '$install_dir'"
COPYFILE_DISABLE=1 tar -cf - -C "$script_dir" chime.wav S96chime | \
    ssh -o BatchMode=yes "$host" "tar -xf - -C '$install_dir'"

ssh -o BatchMode=yes "$host" "
    set -e
    if ! cmp -s '$install_dir/S96chime' /etc/init.d/S96chime; then
        mount -o remount,rw /
        trap 'mount -o remount,ro /' EXIT INT TERM
        cp '$install_dir/S96chime' /etc/init.d/S96chime
        chmod 0755 /etc/init.d/S96chime
        sync
        mount -o remount,ro /
        trap - EXIT INT TERM
    fi
"

echo "Boot chime installed. Test it with: ssh $host /etc/init.d/S96chime play"
