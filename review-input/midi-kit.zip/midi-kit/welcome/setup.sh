#!/bin/sh

# Install the SSH welcome screen on the Yandex Station Midi.

set -eu

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
host=${SPOTIFY_HOST:-root@192.168.1.107}
install_dir=/data/local/welcome

python3 "$script_dir/make_banner.py" >/dev/null

ssh -o BatchMode=yes "$host" "mkdir -p '$install_dir'"
(cd "$script_dir" && COPYFILE_DISABLE=1 tar -cf - banner.ans banner-[0-9][0-9].ans welcome.sh zz-welcome.sh) | \
    ssh -o BatchMode=yes "$host" "tar -xf - -C '$install_dir'"

ssh -o BatchMode=yes "$host" "
    set -e
    chmod 0755 '$install_dir/welcome.sh'
    if ! cmp -s '$install_dir/zz-welcome.sh' /etc/profile.d/zz-welcome.sh; then
        mount -o remount,rw /
        trap 'mount -o remount,ro /' EXIT INT TERM
        cp '$install_dir/zz-welcome.sh' /etc/profile.d/zz-welcome.sh
        chmod 0644 /etc/profile.d/zz-welcome.sh
        sync
        mount -o remount,ro /
        trap - EXIT INT TERM
    fi
"

echo "Welcome screen installed; it shows on the next interactive ssh login."
