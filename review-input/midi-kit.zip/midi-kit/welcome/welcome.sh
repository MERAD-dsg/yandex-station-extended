#!/bin/sh

# SSH welcome screen for the Yandex Station Midi: banner plus a live
# summary of the system, Spotify, the animations and the shortcuts.

dir=/data/local/welcome
spotify=/data/local/spotify
runtime="$spotify/runtime"

esc=$(printf '\033')
reset="${esc}[0m"
dim="${esc}[38;2;140;140;170m"
label="${esc}[38;2;170;120;255m"
value="${esc}[38;2;235;235;250m"
good="${esc}[38;2;80;220;140m"
warn="${esc}[38;2;255;170;60m"
pink="${esc}[38;2;255;80;170m"
blue="${esc}[38;2;90;150;255m"

row() {
    printf '  %s%-11s%s %s\n' "$label" "$1" "$reset" "$2"
}

# Pick a different generated picture for each login. BusyBox ash provides
# RANDOM; uptime remains a fallback for shells that do not.
set -- "$dir"/banner-[0-9][0-9].ans
if [ -f "$1" ]; then
    banner_count=$#
    uptime_seconds=$(cut -d. -f1 /proc/uptime 2>/dev/null)
    random_seed=${RANDOM:-$((${uptime_seconds:-0} + $$))}
    banner_pick=$(( random_seed % banner_count + 1 ))
    banner_index=1
    for banner_candidate in "$dir"/banner-[0-9][0-9].ans; do
        [ "$banner_index" -eq "$banner_pick" ] && banner_file=$banner_candidate && break
        banner_index=$((banner_index + 1))
    done
    cat "$banner_file" 2>/dev/null
else
    cat "$dir/banner.ans" 2>/dev/null
fi
echo

# System
up=$(awk '{ s = int($1); d = int(s / 86400); h = int(s % 86400 / 3600); m = int(s % 3600 / 60);
            if (d) printf "%dd %dh %dm", d, h, m; else if (h) printf "%dh %dm", h, m; else printf "%dm", m }' /proc/uptime)
temp=$(awk '{ printf "%.1f°C", $1 / 1000 }' /sys/class/thermal/thermal_zone0/temp 2>/dev/null)
load=$(cut -d' ' -f1 /proc/loadavg)
mem=$(awk '/MemTotal/ { t = $2 } /MemAvailable/ { a = $2 } END { printf "%d / %d MB free", a / 1024, t / 1024 }' /proc/meminfo)
disk=$(df -h /data 2>/dev/null | awk 'NR == 2 { print $4 " free on /data" }')
lux=$(cut -d. -f1 /sys/bus/iio/devices/iio:device1/in_intensity_input 2>/dev/null)
row "system" "${value}up $up${reset}  ${dim}·${reset}  ${value}$temp${reset}  ${dim}·${reset}  ${value}load $load${reset}  ${dim}·${reset}  ${value}${lux:-?} lux${reset}"
row "memory" "${value}$mem${reset}  ${dim}·${reset}  ${value}$disk${reset}"

# Network
ip=$(ip -4 addr show wlan0 2>/dev/null | awk '/inet / { sub(/\/.*/, "", $2); print $2; exit }')
ssid=$(iw dev wlan0 link 2>/dev/null | awk -F': ' '/SSID/ { print $2 }')
signal=$(iw dev wlan0 link 2>/dev/null | awk '/signal/ { print $2 }')
row "wi-fi" "${value}${ssid:-offline}${reset}  ${dim}·${reset}  ${value}${signal:-?} dBm${reset}  ${dim}·${reset}  ${value}${ip:-no address}${reset}"

# Firmware and the update block
fw=$(cat /system/vendor/quasar/version_full 2>/dev/null)
if grep -q "OTA apply blocked" /system/vendor/quasar/device_ota_update.sh 2>/dev/null &&
   ! grep -q updatesd /system/vendor/quasar/launch.json 2>/dev/null; then
    updates="${good}✓ updates blocked${reset}"
else
    updates="${warn}⚠ updates NOT blocked${reset}"
fi
row "firmware" "${value}${fw:-?}${reset}  ${dim}·${reset}  $updates"

# Spotify
now=$(LD_LIBRARY_PATH="$runtime/lib" "$runtime/bin/soloist" ctl -w 127.0.0.1:24879 now --json 2>/dev/null | head -n 1)
if [ -z "$now" ]; then
    music="${warn}Soloist is not running${reset}"
else
    item=${now#*\"item\":}
    title=${item#*\"identity\":{\"name\":\"}
    title=${title%%\"*}
    artist=${item#*\"creators\":}
    artist=${artist#*\"identity\":{\"name\":\"}
    artist=${artist%%\"*}
    status=$(printf '%s' "$now" | sed -n 's/.*"status":"\([a-z]*\)".*/\1/p')
    volume=$(printf '%s' "$now" | sed -n 's/.*"volume":\([0-9]*\).*/\1/p')
    case "$now" in *'"is_active":true'*) active=1 ;; *) active=0 ;; esac
    case "$status" in
        playing) icon="${good}▶${reset}" ;;
        paused) icon="${blue}⏸${reset}" ;;
        *) icon="${dim}■${reset}" ;;
    esac
    if [ "$item" = "$now" ] || [ -z "$title" ]; then
        music="$icon ${dim}nothing queued${reset}"
    else
        music="$icon ${value}$title${reset} ${dim}—${reset} ${pink}$artist${reset}  ${dim}·${reset}  ${value}vol ${volume:-?}%${reset}"
    fi
    [ "$active" = 1 ] || music="$music  ${dim}(speaker not selected)${reset}"
fi
row "spotify" "$music"

# Animations
info=$("$spotify/indicator.sh" info 2>/dev/null)
if [ -n "$info" ]; then
    set -- $(printf '%s' "$info" | sed -n 's/.*"current":\[\([0-9]*\),\([0-9]*\),\([0-9]*\)\].*/\1 \2 \3/p')
    pick() {
        printf '%s' "$info" | sed -n "s/.*\"$1\":\[\([^]]*\)\].*/\1/p" | tr -d '"' | tr ',' '\n' | sed -n "$(($2 + 1))p"
    }
    anim="${value}$(pick patterns "${1:-0}")${reset} ${dim}·${reset} ${value}$(pick palettes "${2:-0}")${reset} ${dim}·${reset} ${value}$(pick clock_patterns "${3:-0}")${reset}"
    case "$info" in *'"enabled":false'*) anim="${dim}off${reset}" ;; esac
    case "$info" in *'"locked":true'*) anim="$anim  ${dim}(locked)${reset}" ;; esac
    row "animation" "$anim"
fi

row "remote" "${blue}http://${ip:-192.168.1.107}:8088/${reset}"
echo
printf '  %svoice%s  %sдальше · назад · пауза · стоп · играй · громче · тише · хватит×3 = reboot%s\n' \
    "$label" "$reset" "$dim" "$reset"
printf '  %sspotify%s %s%s/service.sh {status|restart|log}%s\n' "$label" "$reset" "$dim" "$spotify" "$reset"
echo
