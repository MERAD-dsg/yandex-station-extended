#!/usr/bin/env python3
"""Build fixed-width, truecolor ASCII banners for the Midi SSH login.

Only printable ASCII is used in the artwork so every cell occupies exactly
one terminal column. Colors are baked in here; the speaker only reads files.
"""

from pathlib import Path
from textwrap import dedent


WIDTH = 70
GLYPHS = {
    "A": [" ### ", "#   #", "#####", "#   #", "#   #"],
    "B": ["#### ", "#   #", "#### ", "#   #", "#### "],
    "C": [" ####", "#    ", "#    ", "#    ", " ####"],
    "D": ["#### ", "#   #", "#   #", "#   #", "#### "],
    "E": ["#####", "#    ", "#### ", "#    ", "#####"],
    "F": ["#####", "#    ", "#### ", "#    ", "#    "],
    "G": [" ####", "#    ", "#  ##", "#   #", " ####"],
    "H": ["#   #", "#   #", "#####", "#   #", "#   #"],
    "I": ["#####", "  #  ", "  #  ", "  #  ", "#####"],
    "J": ["#####", "   # ", "   # ", "#  # ", " ##  "],
    "K": ["#   #", "#  # ", "###  ", "#  # ", "#   #"],
    "L": ["#    ", "#    ", "#    ", "#    ", "#####"],
    "M": ["#   #", "## ##", "# # #", "#   #", "#   #"],
    "N": ["#   #", "##  #", "# # #", "#  ##", "#   #"],
    "O": [" ### ", "#   #", "#   #", "#   #", " ### "],
    "P": ["#### ", "#   #", "#### ", "#    ", "#    "],
    "Q": [" ### ", "#   #", "# # #", "#  ##", " ####"],
    "R": ["#### ", "#   #", "#### ", "#  # ", "#   #"],
    "S": [" ####", "#    ", " ### ", "    #", "#### "],
    "T": ["#####", "  #  ", "  #  ", "  #  ", "  #  "],
    "U": ["#   #", "#   #", "#   #", "#   #", " ### "],
    "V": ["#   #", "#   #", "#   #", " # # ", "  #  "],
    "W": ["#   #", "#   #", "# # #", "## ##", "#   #"],
    "X": ["#   #", " # # ", "  #  ", " # # ", "#   #"],
    "Y": ["#   #", " # # ", "  #  ", "  #  ", "  #  "],
    "Z": ["#####", "   # ", "  #  ", " #   ", "#####"],
    "0": [" ### ", "#  ##", "# # #", "##  #", " ### "],
    "1": ["  #  ", " ##  ", "  #  ", "  #  ", " ### "],
    " ": ["     "] * 5,
}


def wordmark(message):
    """Make a five-row logo; each glyph is five terminal cells wide."""
    assert all(letter in GLYPHS for letter in message), message
    lines = [" ".join(GLYPHS[letter][row] for letter in message) for row in range(5)]
    assert all(len(line) <= WIDTH - 4 for line in lines), message
    return lines


def panel(message, sketch, caption, palette):
    words = [message] if isinstance(message, str) else message
    logo = []
    for word in words:
        if logo:
            logo.append("")
        logo.extend(wordmark(word))
    return {"logo": logo, "sketch": sketch, "caption": caption, "palette": palette}


def picture(sketch, caption, palette, strike=False):
    """An illustration-first banner without a block-letter heading."""
    return {"logo": [], "sketch": sketch, "caption": caption,
            "palette": palette, "strike": strike}


def crossed_wordmark(message):
    """Strike through a large wordmark with an ASCII X."""
    source = wordmark(message)
    width = len(source[0])
    crossed = []
    for row, line in enumerate(source):
        letters = list(line)
        left = round(row * (width - 1) / 4)
        right = width - 1 - left
        letters[left] = "\\"
        letters[right] = "/"
        crossed.append("".join(letters))
    return crossed


def console(lines):
    """Draw a rectangular terminal with measured padding."""
    width = max(len(line) for line in lines) + 4
    return (["+" + "-" * (width - 2) + "+"]
            + ["| " + line.ljust(width - 4) + " |" for line in lines]
            + ["+" + "-" * (width - 2) + "+"])


PURPLE = [(120, 70, 255), (40, 180, 255), (255, 60, 190)]
ICE = [(40, 220, 255), (170, 245, 255), (90, 120, 255)]
FIRE = [(255, 40, 110), (255, 105, 35), (255, 215, 65)]
MATRIX = [(40, 255, 145), (20, 185, 255), (110, 95, 255)]
PINK = [(255, 50, 195), (165, 70, 255), (40, 190, 255)]

BANNERS = [
    panel("SN0W", [
        "         .       *       .       *       .       *",
        "             \\   |   /             \\   |   /",
        "          ----  *  ----       ----  *  ----",
        "             /   |   \\             /   |   \\",
        "         *       .       *       .       *       .",
    ], "SN0W // ICE-COLD ROOT SHELL", ICE),
    panel(("FUCK", "YANDEX"), [
        "     /!\\   DEVICE OWNED BY ITS OWNER   /!\\",
        "     ------------------------------------------------",
        "     0% vendor approval required  |  100% your rules",
    ], "FUCK YANDEX // OWNER MODE", FIRE),
    panel("JAILBREAK", console([
        "[X] LOCKED     [ ] UNLOCKED",
        "    \\___________/",
        "THE CAGE IS OPEN",
    ]), "JAILBREAK // NO MORE CAGE", MATRIX),
    panel("ROOT", [
        "              .----.",
        "             /  __  \\",
        "            |  (  )  |====================>",
        "             \\  --  /",
        "              '----'       OWNER KEY",
    ], "ROOT // KEYS BELONG TO YOU", FIRE),
    panel("MIDI", console([
        "o o o o o o o o o o o o",
        "YANDEX STATION MIDI",
        "CUSTOM ROOT SHELL",
    ]), "MIDI // FREE RANGE FIRMWARE", PURPLE),
    panel("NO CAGE", [
        "       |  |  |  |  |     |  |  |  |  |",
        "       |  |  |  |  /     \\  |  |  |  |",
        "       |  |  |  /    >>>    \\  |  |  |",
        "       |  |  /      >>>      \\  |  |",
        "       `--'--'                  `--'--'",
    ], "NO CAGE // EXIT THROUGH THE FIREWALL", PINK),
    panel("OVERRIDE", console([
        "vendor_policy : /dev/null",
        "local_control : ENABLED",
        "operator      : YOU",
    ]), "SYSTEM OVERRIDE // TAKE THE WHEEL", FIRE),
    panel("GHOST", [
        "                    .-~~~~-.",
        "                   /  o  o  \\",
        "                  |    __    |",
        "                  |   /__\\   |",
        "                   \\  /  \\  /",
        "                    `------'",
    ], "GHOST IN THE MACHINE // ROOT IS HERE", PINK),
    panel("OWNED", console([
        "root@midi:~# whoami",
        "root",
        "root@midi:~# echo 'my speaker, my rules'",
        "my speaker, my rules",
    ]), "OWNED BY THE OWNER // NOT THE VENDOR", MATRIX),
    panel("UNLOCKED", console([
        "[ LOCK ]  --/ /-->  [ OPEN ]",
        "",
        "permission: NO MASTER",
    ]), "UNLOCKED // MAKE SOME NOISE", PURPLE),
    panel("ICEBREAKER", [
        "                  *       *       *",
        "              *      \\   |   /      *",
        "            *     ----  /!\\  ----     *",
        "              *      /   |   \\      *",
        "                  *       *       *",
    ], "ICEBREAKER // SN0W WAS HERE", ICE),
    panel("QUASAR", console([
        "SIGNAL ............... ONLINE",
        "SHELL ................ ROOT",
        "VENDOR PERMISSION ... SKIPPED",
    ]), "QUASAR // INDEPENDENT FREQUENCY", MATRIX),
    picture([
        "              *       \\  |  /       *",
        "                \\      \\ | /      /",
        "         *-------\\------\\|/------/-------*",
        "                  \\      *      /",
        "         *-------/------/|\\------\\-------*",
        "                /      / | \\      \\",
        "              *       /  |  \\       *",
    ], "SN0W // CRYSTAL CORE", ICE),
    picture([
        "        \\ | /              .              \\ | /",
        "       -- * --      .             .       -- * --",
        "        / | \\              .              / | \\",
        "",
        "            .        \\  |  /        .",
        "                   ---  *  ---",
        "            .        /  |  \\        .",
        "",
        "        \\ | /       .       .       \\ | /",
        "       -- * --   .     . .     .   -- * --",
        "        / | \\                       / | \\",
    ], "SN0W // FULL TERMINAL BLIZZARD", ICE),
    picture([
        "                .--- VENDOR SIGNAL ---.",
        "",
        *crossed_wordmark("YANDEX"),
        "",
        "                '--- SIGNAL CUT ---'",
    ], "YANDEX LOGO // CROSSED OUT", FIRE, strike=True),
    picture([
        "                  .---------------------.",
        "               .-'     \\         /     '-.",
        "             .'         \\   Y   /         '.",
        "            /            \\ / \\ /            \\",
        "           |              X   X              |",
        "            \\            / \\ / \\            /",
        "             '.         /   Y   \\         .'",
        "               '-.     /         \\     .-'",
        "                  '---------------------'",
        "",
        "                 Y A N D E X  :  N O",
    ], "FUCK YANDEX // CANCEL THE MONOGRAM", FIRE, strike=True),
    picture([
        "                       .--.",
        "                      |o_o |",
        "                      |:_/ |",
        "                     //   \\ \\",
        "                    (|     | )",
        "                   /  \\___/  \\",
        "                   \\___)=(___/",
        "",
        "               L I N U X  //  R O O T",
    ], "LINUX // PENGUIN IN CHARGE", MATRIX),
    picture([
        "                        .--.",
        "                       |o_o |       +--------------------+",
        "                       |:_/ |       | KERNEL: RUNNING    |",
        "                      //   \\ \\      | SHELL : ROOT       |",
        "                     (|     | )     | OWNER : PRESENT    |",
        "                    /  \\___/  \\     +--------------------+",
        "                    \\___)=(___/",
    ], "LINUX // OWNERSPACE BOOT", PURPLE),
    picture([
        "             .------.   .------.      .------.",
        "            /        \\_/        \\    /        \\",
        "            \\        / \\        /    \\        /",
        "             '------'   '------'      '------'",
        "                       \\                  /",
        "                        \\   *  SNAP!  *  /",
        "                         '------------'",
    ], "JAILBREAK // CHAIN BROKEN", PINK),
    picture([
        "                          _===_",
        "                         (o   o)",
        "                         (  ^  )",
        "                        /|  :  |\\",
        "                       /_|  :  |_\\",
        "                          /   \\",
        "                         /_____\\",
        "",
        "                    root@sn0w:~# _",
    ], "SN0W // COLD HANDS, WARM SHELL", ICE),
    picture([
        "                 .-------------------------.",
        "                /  \\                   /    \\",
        "               |    \\     Y A         /      |",
        "               |     \\   N D E X     /       |",
        "               |      \\             /        |",
        "               |       \\     X     /         |",
        "               |        \\   / \\   /          |",
        "                \\        \\ /   \\ /          /",
        "                 '---------X-----X---------'",
    ], "YANDEX // CUT THE CONTROL LOOP", FIRE, strike=True),
    picture(console([
        "       .-=========-.",
        "      /   *  |  *   \\",
        "     |  --  SN0W  -- |",
        "      \\   *  |  *   /",
        "       '-=========-'",
        "LINUX / ROOT / NO VENDOR LOCK",
    ]), "SN0W + LINUX // FREE THE SPEAKER", PINK),
]

RESET = "\033[0m"
CAPTION = "\033[38;2;170;175;205m"


def color_at(stops, fraction):
    position = max(0.0, min(1.0, fraction)) * (len(stops) - 1)
    index = min(int(position), len(stops) - 2)
    blend = position - index
    blend = blend * blend * (3 - 2 * blend)
    return tuple(round(stops[index][channel] * (1 - blend) + stops[index + 1][channel] * blend)
                 for channel in range(3))


def colored_line(line, row, rows, stops, strike=False):
    output = []
    for column, character in enumerate(line):
        if character == " ":
            output.append(character)
            continue
        red, green, blue = color_at(stops, 0.75 * column / max(len(line) - 1, 1) +
                                    0.25 * row / max(rows - 1, 1))
        if strike and character in "/\\X":
            red, green, blue = (255, 40, 55)
        output.append(f"\033[38;2;{red};{green};{blue}m{character}")
    return "".join(output) + RESET


def render(banner):
    interior = WIDTH - 4
    sketch = dedent("\n".join(banner["sketch"])).splitlines()
    sketch_width = max(len(line) for line in sketch)
    art = banner["logo"] + ([""] if banner["logo"] else []) + [
        line.ljust(sketch_width) for line in sketch
    ]
    assert all(line.isascii() and len(line) <= interior for line in art)
    frame_red, frame_green, frame_blue = banner["palette"][0]
    frame_color = f"\033[38;2;{frame_red};{frame_green};{frame_blue}m"
    lines = ["", "  " + frame_color + "+" + "-" * interior + "+" + RESET]
    for row, picture in enumerate(art):
        centered = picture.center(interior)
        lines.append("  " + frame_color + "|" + RESET +
                     colored_line(centered, row, len(art), banner["palette"],
                                  banner.get("strike", False)) +
                     frame_color + "|" + RESET)
    lines.append("  " + frame_color + "+" + "-" * interior + "+" + RESET)
    lines.append(" " * ((WIDTH - len(banner["caption"])) // 2) + CAPTION + banner["caption"] + RESET)
    return "\n".join(lines) + "\n"


def main():
    directory = Path(__file__).resolve().parent
    for index, banner in enumerate(BANNERS, start=1):
        path = directory / f"banner-{index:02d}.ans"
        path.write_text(render(banner), encoding="ascii")
        print("wrote", path)
    (directory / "banner.ans").write_text(render(BANNERS[0]), encoding="ascii")


if __name__ == "__main__":
    main()
