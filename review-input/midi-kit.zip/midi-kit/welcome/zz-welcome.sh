# Installed as /etc/profile.d/zz-welcome.sh: welcome screen and a coloured
# prompt for interactive SSH logins. The screen itself lives on /data so it
# can change without remounting the root filesystem.
if [ -n "$PS1" ] && [ -t 1 ]; then
    [ -x /data/local/welcome/welcome.sh ] && /data/local/welcome/welcome.sh
    PS1='\[\033[38;2;170;0;255m\]midi\[\033[0m\] \[\033[38;2;200;220;255m\]❄\[\033[0m\] \[\033[38;2;90;150;255m\]\w\[\033[0m\] # '
    export PS1
fi
