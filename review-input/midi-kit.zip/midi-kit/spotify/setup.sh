#!/bin/sh

set -eu

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
device_name=${1:-Yandex Station Midi Spotify}
spotify_host=${SPOTIFY_HOST:-root@192.168.1.107}
install_dir=/data/local/spotify

if [ ! -x "$script_dir/build/runtime/bin/soloist" ]; then
    python3 "$script_dir/build_runtime.py"
fi

tmp_dir=$(mktemp -d "${TMPDIR:-/tmp}/spotify-setup.XXXXXX")
trap 'rm -rf "$tmp_dir"' EXIT INT TERM

cp -R "$script_dir/build/runtime" "$tmp_dir/runtime"
cp "$script_dir/service.sh" "$script_dir/indicator.sh" "$script_dir/voice.sh" "$script_dir/S98spotify" "$tmp_dir/"
cp -R "$script_dir/web" "$tmp_dir/web"
cp -R "$script_dir/airplay" "$tmp_dir/airplay"
printf '%s\n' "$device_name" >"$tmp_dir/device-name"
files="runtime web airplay service.sh indicator.sh voice.sh S98spotify device-name"
if [ -n "${SOLOIST_PROXY:-}" ]; then
    printf '%s\n' "$SOLOIST_PROXY" >"$tmp_dir/proxy"
    files="$files proxy"
fi
if [ -n "${SOLOIST_API_KEY:-}" ]; then
    (umask 077; printf '%s\n' "$SOLOIST_API_KEY" >"$tmp_dir/api-key")
    files="$files api-key"
fi

echo "Installing Spotify Soloist as: $device_name"

ssh -o BatchMode=yes "$spotify_host" \
    "mkdir -p '$install_dir'; \
     if [ -x '$install_dir/service.sh' ]; then '$install_dir/service.sh' stop || true; fi; \
     rm -rf '$install_dir/runtime' '$install_dir/web' '$install_dir/airplay'"

COPYFILE_DISABLE=1 tar -cf - -C "$tmp_dir" $files | ssh -o BatchMode=yes "$spotify_host" "tar -xf - -C '$install_dir'"

ssh -o BatchMode=yes "$spotify_host" "
    set -e
    chmod 0755 '$install_dir/service.sh' '$install_dir/indicator.sh' '$install_dir/voice.sh' '$install_dir/S98spotify' '$install_dir/web/cgi-bin/api' '$install_dir/airplay/airplay-hook.sh' '$install_dir/airplay/airplay-meta.sh'
    [ ! -f '$install_dir/api-key' ] || chmod 0600 '$install_dir/api-key'
    # One-time root filesystem changes: the init script, plus what avahi
    # needs for AirPlay (its D-Bus policy and an 'avahi' system user).
    policy=/etc/dbus-1/system.d/avahi-dbus.conf
    if ! cmp -s '$install_dir/S98spotify' /etc/init.d/S98spotify ||
       ! cmp -s '$install_dir/runtime/share/avahi-dbus.conf' \$policy ||
       ! grep -q '^avahi:' /etc/passwd; then
        mount -o remount,rw /
        trap 'mount -o remount,ro /' EXIT INT TERM
        cp '$install_dir/S98spotify' /etc/init.d/S98spotify
        chmod 0755 /etc/init.d/S98spotify
        cp '$install_dir/runtime/share/avahi-dbus.conf' \$policy
        chmod 0644 \$policy
        grep -q '^avahi:' /etc/passwd || echo 'avahi:x:70:70:Avahi mDNS daemon:/run/avahi-daemon:/bin/false' >>/etc/passwd
        grep -q '^avahi:' /etc/group || echo 'avahi:x:70:' >>/etc/group
        sync
        mount -o remount,ro /
        trap - EXIT INT TERM
        kill -HUP \$(pidof dbus-daemon) 2>/dev/null || true
    fi
    if [ -s '$install_dir/api-key' ]; then
        '$install_dir/service.sh' start
        '$install_dir/service.sh' status
    else
        echo 'No API key yet: rerun with SOLOIST_API_KEY=... ./setup.sh'
    fi
"

echo "Spotify Soloist installation complete."
echo "Service: $install_dir/service.sh {start|stop|restart|status|log}"
