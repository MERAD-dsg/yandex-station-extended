#!/bin/sh

# Reads shairport-sync's metadata pipe and passes each new track title to
# the LED indicator (via airplay-hook.sh), so the clock scrolls AirPlay
# titles the way it does for Spotify.
#
# The pipe carries items like:
#   <item><type>636f7265</type><code>6d696e6d</code><length>12</length>
#   <data encoding="base64">
#   0JHQvtC70YzQvdC+</data></item>
# where code 6d696e6d ("minm") is the track name, base64-encoded.

pipe=/run/soloist/airplay-meta
hook=/data/local/spotify/airplay/airplay-hook.sh

[ -p "$pipe" ] || { rm -f "$pipe"; mkfifo "$pipe"; }

code=
data=
in_data=0
last=
while IFS= read -r line; do
    case "$line" in
        *'<code>'*)
            code=${line#*<code>}
            code=${code%%</code>*}
            ;;
    esac
    case "$line" in
        *'<data encoding="base64">'*)
            in_data=1
            data=${line#*<data encoding=\"base64\">}
            ;;
        *)
            [ "$in_data" = 1 ] && data="$data$line"
            ;;
    esac
    case "$line" in
        *'</data>'*)
            in_data=0
            data=${data%%</data>*}
            if [ "$code" = 6d696e6d ]; then
                title=$(printf '%s' "$data" | base64 -d 2>/dev/null)
                if [ -n "$title" ] && [ "$title" != "$last" ]; then
                    last=$title
                    "$hook" title "$title"
                fi
            fi
            data=
            ;;
        *'</item>'*)
            code=
            ;;
    esac
done <"$pipe"
