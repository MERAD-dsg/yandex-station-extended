#!/bin/sh

# shairport-sync session hook. "begin": an AirPlay stream starts, so pause
# Spotify, mark AirPlay active and tell the LED indicator; "end": clear the
# mark and tell the indicator. When Spotify starts playing while the mark is
# set, indicator.sh drops the AirPlay session.

install_dir=/data/local/spotify
runtime="$install_dir/runtime"
flag=/run/soloist/airplay.active
events=/run/soloist/events.fifo

ctl() {
    LD_LIBRARY_PATH="$runtime/lib" "$runtime/bin/soloist" ctl -w 127.0.0.1:24879 "$@"
}

# The indicator reads Soloist's events from this FIFO; AirPlay events join
# the same stream. Written in the background so a restarting indicator can
# never block shairport-sync.
send_event() {
    [ -p "$events" ] || return 0
    (printf '%s\n' "$*" >"$events") &
}

case "${1:-}" in
    begin)
        touch "$flag"
        if ctl now --json 2>/dev/null | grep -q '"status":"playing"'; then
            ctl pause >/dev/null 2>&1
        fi
        send_event "airplay begin"
        ;;
    end)
        rm -f "$flag"
        send_event "airplay end"
        ;;
    title)
        shift
        send_event "airplay title $*"
        ;;
esac
