#!/bin/sh

# Playback indicator for Soloist on the Yandex Cucumber (Station Midi).
# While a track plays the LED ring (/dev/fb0) and logo (/dev/fb1) run one of
# many pattern + palette combinations and the clock digits run one of several
# patterns. A new track scrolls its title across the clock, and the
# animation changes on every new track and every 45 seconds.

set -eu

install_dir=/data/local/spotify
runtime="$install_dir/runtime"
ws_addr=127.0.0.1:24879
state_dir="$install_dir/indicator"
frames_version=6
title_file=/run/soloist/title
level_file=/run/soloist/level
led_root="/sys/class/leds/cucumber:white:clock"
patterns="comet gradient twin breathe sparkle fill wave scanner chase meteors ripple fire
confetti split beat stripes balls segments plasma storm kaleido
strobe colorcut wipe wipealt radar pacman loading grow zipper fireworks
raindrops static glitch dna pendulum heartbeat spokes gears binary stack
lighthouse checker meet chaserev morse accel halves
bounce snakegame automata fireflies sort pong hunt hourglass spring heat
crystal cradle vu bassspin flash bloom"
pattern_count=64
sim_patterns="bounce snakegame automata fireflies sort pong hunt hourglass spring heat crystal cradle"
reactive_patterns="vu bassspin flash bloom"
sim_frames=960
reactive_levels=13
palette_names="violet sunset ocean aurora lava cyber sakura ice citrus rainbow
neon berry tropical royal mint-peach deep-sea candy fire-ice"
palette_count=18
clock_names="equalizer snake spin rain bounce wave zigzag sweep lift slot
converge breathe heartbeat matrix pingpong twosnakes fillup words firefly
stack time police sparks"
clock_pattern_count=23
# Web interface control files.
anim_pid_file=/run/soloist/anim.pid
request_file=/run/soloist/anim.request
current_file="$state_dir/current"
lock_file="$state_dir/locked"
disabled_file="$state_dir/disabled"
frame_count=192
# Frame delay drifts between these bounds so the ring speeds up and slows down.
delay_min_us=15000
delay_max_us=90000
switch_after_us=45000000
title_step_us=180000
brightness=60

# Prints octal-escaped B,G,R bytes for every frame of ring pattern $1 (or
# "logo") in palette $2 on a strip of $3 pixels. Busybox awk has no math
# functions or rand(), so curves are polynomials and randomness is an LCG.
# Shared awk helpers for every frame generator: palette colours, output
# encoding and small maths (busybox awk has no math library).
awk_lib='
        function pcolor(u, v,    k, t) {
            u -= int(u)
            if (u < 0) u += 1
            if (pal == 9) {
                rainbow(u * 256, v)
                return
            }
            k = int(u * NS)
            t = u * NS - k
            t = t * t * (3 - 2 * t)
            put(PR[k] + (PR[(k + 1) % NS] - PR[k]) * t,
                PG[k] + (PG[(k + 1) % NS] - PG[k]) * t,
                PB[k] + (PB[(k + 1) % NS] - PB[k]) * t, v)
        }
        # Integer HSV rainbow; an integer hue keeps every channel in 0..220.
        function rainbow(h, v,    sector, rem, q, t) {
            h = int(h) % 256
            sector = int(h / 43)
            rem = (h - sector * 43) * 6
            q = int(220 * (255 - rem) / 255)
            t = int(220 * rem / 255)
            if      (sector == 0) put(220, t, 0, v)
            else if (sector == 1) put(q, 220, 0, v)
            else if (sector == 2) put(0, 220, t, v)
            else if (sector == 3) put(0, q, 220, v)
            else if (sector == 4) put(t, 0, 220, v)
            else                  put(220, 0, q, v)
        }
        function put(r, g, b, v) {
            if (v < 0) v = 0
            if (v > 1) v = 1
            printf "\\%03o\\%03o\\%03o", int(b * v), int(g * v), int(r * v)
        }
        # Triangle wave: 0 -> 1 -> 0 as x goes 0 -> 1.
        function tri(x) {
            x -= int(x)
            if (x < 0) x += 1
            return x < 0.5 ? 2 * x : 2 - 2 * x
        }
        function lcg() {
            seed = (seed * 75 + 74) % 65537
            return seed / 65537
        }
        function abs(x) { return x < 0 ? -x : x }
        # Distance behind a comet head moving up the strip.
        function behind(head, i,    d) {
            d = head - i
            if (d < 0) d += px
            return d
        }
        function sq(x) { return x * x }
        function smooth(t) { return t * t * (3 - 2 * t) }
        # Square root by Newton iterations (no math library).
        function sqrt1(x,    r, n) {
            if (x <= 0) return 0
            r = x > 1 ? x : 1
            for (n = 0; n < 12; n++) r = (r + x / r) / 2
            return r
        }
        # Distance between two positions around the ring.
        function cdist(a, b,    d) {
            d = abs(a - b)
            d -= int(d / px) * px
            return d > px / 2 ? px - d : d
        }
        # Heartbeat envelope: sharp rise, quick decay.
        function env(x) { return x >= 0 && x < 0.15 ? sq(1 - x / 0.15) : 0 }
        function init_palette(    stops, c, k) {
            P[0] = "170,0,255 0,25,255 170,0,255 255,20,150"     # violet
            P[1] = "255,60,0 255,0,90 150,0,255 255,120,0"       # sunset
            P[2] = "0,255,180 0,120,255 40,0,255 0,200,255"      # ocean
            P[3] = "0,255,90 0,200,200 120,0,255 0,255,160"      # aurora
            P[4] = "255,0,0 255,70,0 255,160,0 255,30,0"         # lava
            P[5] = "255,0,200 0,220,255 120,0,255 0,255,200"     # cyber
            P[6] = "255,40,120 255,120,170 200,60,255 255,80,140" # sakura
            P[7] = "120,200,255 0,90,255 180,120,255 220,240,255" # ice
            P[8] = "180,255,0 255,200,0 255,90,0 0,255,80"       # citrus
            P[9] = "0,0,0"                                       # rainbow
            P[10] = "57,255,20 255,0,255 0,255,255 255,230,0"    # neon
            P[11] = "130,0,255 255,0,120 255,0,40 180,0,200"     # berry
            P[12] = "255,0,120 255,140,0 0,255,160 0,160,255"    # tropical
            P[13] = "60,0,255 255,180,0 140,0,255 255,120,0"     # royal
            P[14] = "0,255,170 255,150,90 255,90,140 0,220,255"  # mint-peach
            P[15] = "0,40,255 0,255,220 0,0,160 80,0,255"        # deep sea
            P[16] = "255,80,200 80,200,255 255,180,60 200,80,255" # candy
            P[17] = "255,40,0 255,140,0 0,160,255 0,40,255"      # fire-ice
            NS = split(P[pal], stops, " ")
            for (k = 0; k < NS; k++) {
                split(stops[k + 1], c, ",")
                PR[k] = c[1]; PG[k] = c[2]; PB[k] = c[3]
            }
        }
'

gen_frames() {
    awk -v frames="$frame_count" -v pattern="$1" -v pal="$2" -v px="$3" "$awk_lib"'
        BEGIN {
            init_palette()

            seed = 4242
            # Flicker periods divide the loop length so the loop is seamless.
            split("48 64 96 192", periods, " ")
            for (i = 0; i < px; i++) {
                T1[i] = periods[1 + int(lcg() * 4)]
                T2[i] = periods[1 + int(lcg() * 4)]
                PH1[i] = int(lcg() * 192)
                PH2[i] = int(lcg() * 192)
            }
            split("2 3 5", speeds, " ")
            NB = 6
            for (m = 0; m < NB; m++) {
                BF[m] = int(lcg() * (frames - 4))
                BC[m] = int(lcg() * px)
            }
            for (m = 0; m < 5; m++) RB[m] = int(lcg() * px)
            for (m = 0; m < 12; m++) {
                GF[m] = int(lcg() * (frames - 5))
                GC[m] = int(lcg() * px)
                GW[m] = 1 + int(lcg() * 3)
                GD[m] = 2 + int(lcg() * 3)
                GP[m] = lcg()
            }
            POW[0] = 1
            for (b = 1; b < 8; b++) POW[b] = POW[b - 1] * 2
            # SOS in frames: dot 4 on, dash 12 on, 4 off between signals,
            # 12 off between letters, padded with silence to the loop length.
            SOS = ""
            split("4 4 4 0 12 12 12 0 4 4 4", sig, " ")
            for (m = 1; m <= 11; m++) {
                if (sig[m] == 0) { SOS = SOS "00000000"; continue }
                for (n = 0; n < sig[m]; n++) SOS = SOS "1"
                SOS = SOS "0000"
            }
            while (length(SOS) < frames) SOS = SOS "0"

            for (f = 0; f < frames; f++) {
                u = f / frames
                for (i = 0; i < px; i++) {
                    if (pattern == "logo") {
                        t = tri(u * 4)
                        pcolor(u + i / 24, 0.25 + 0.75 * t * t)
                    } else if (pattern == "comet") {
                        d = behind((u * px * 4) % px, i)
                        pcolor(u - d * 0.03, d < 10 ? sq(1 - d / 10) : 0)
                    } else if (pattern == "gradient") {
                        pcolor(i / px + u * 2, 0.85)
                    } else if (pattern == "twin") {
                        head = (u * px * 3) % px
                        d1 = behind(head, i)
                        d2 = behind((head + px / 2) % px, i)
                        if (d1 <= d2) pcolor(u - d1 * 0.04, d1 < 7 ? sq(1 - d1 / 7) : 0)
                        else          pcolor(u + 0.5 - d2 * 0.04, d2 < 7 ? sq(1 - d2 / 7) : 0)
                    } else if (pattern == "breathe") {
                        t = tri(u * 3)
                        pcolor(i / (px * 2) + u, 0.06 + 0.94 * t * t)
                    } else if (pattern == "sparkle") {
                        t = ((f + PH1[i]) % T1[i]) / T1[i]
                        pcolor(i / px + u, 0.04 + (t < 0.3 ? sq(1 - t / 0.3) : 0))
                    } else if (pattern == "fill") {
                        level = tri(u * 2) * 12.99
                        d = i <= px / 2 ? i : px - i
                        v = d < int(level) ? 1 : (d == int(level) ? level - int(level) : 0)
                        pcolor(d / 30 + u, v)
                    } else if (pattern == "wave") {
                        t = tri(i * 3 / px - u * 6)
                        pcolor(i / px + u, 0.06 + 0.94 * t * t * t)
                    } else if (pattern == "scanner") {
                        pos = tri(u * 4) * (px - 1)
                        d = abs(i - pos)
                        pcolor(u * 2 + i / (px * 3), 0.03 + (d < 4 ? sq(1 - d / 4) : 0))
                    } else if (pattern == "chase") {
                        k = (i + int(u * 96)) % 4
                        pcolor(i / px + u, k == 0 ? 1 : (k == 1 ? 0.25 : 0.03))
                    } else if (pattern == "meteors") {
                        v = 0
                        off = 0
                        for (m = 1; m <= 3; m++) {
                            d = behind((u * px * speeds[m] + m * 8) % px, i)
                            w = d < 6 ? sq(1 - d / 6) : 0
                            if (w > v) { v = w; off = m * 0.33 - d * 0.03 }
                        }
                        pcolor(u + off, v)
                    } else if (pattern == "ripple") {
                        d = i <= px / 2 ? i : px - i
                        v = 0
                        for (m = 0; m < 2; m++) {
                            r = (u * 3 + m * 0.5)
                            r = (r - int(r)) * 14
                            w = 1 - abs(d - r) / 2.5
                            if (w > 0) w = w * w * (1 - r / 14); else w = 0
                            if (w > v) v = w
                        }
                        pcolor(u + d / 40, 0.02 + v)
                    } else if (pattern == "fire") {
                        t1 = tri((f + PH1[i]) / T1[i])
                        t2 = tri((f + PH2[i]) / T2[i])
                        pcolor(u + i / (px * 4) + 0.15 * t1, 0.25 + 0.4 * t1 + 0.35 * t2 * t2)
                    } else if (pattern == "confetti") {
                        # Quick flashes, each pixel in its own palette colour.
                        t = ((f + PH1[i]) % (T1[i] / 2)) / (T1[i] / 2)
                        pcolor(PH2[i] / 192 + u, t < 0.2 ? sq(1 - t / 0.2) : 0)
                    } else if (pattern == "split") {
                        # Two halves rotating their gradients in opposite directions.
                        if (i < px / 2) pcolor(i / px + u * 2, 0.9)
                        else            pcolor(0.5 - i / px - u * 2, 0.9)
                    } else if (pattern == "beat") {
                        # Kick drum: sharp attack, slow decay, eight beats a loop.
                        t = u * 8 - int(u * 8)
                        pcolor(u + i / (px * 3), 0.05 + 0.95 * (1 - t) * (1 - t) * (1 - t))
                    } else if (pattern == "stripes") {
                        k = int((i + u * px * 2) / 3) % 2
                        pcolor(u + k * 0.5, 0.9)
                    } else if (pattern == "balls") {
                        p1 = tri(u * 3) * (px - 1)
                        p2 = tri(u * 5 + 0.5) * (px - 1)
                        d1 = abs(i - p1)
                        d2 = abs(i - p2)
                        if (d1 <= d2) pcolor(u, d1 < 3 ? sq(1 - d1 / 3) : 0)
                        else          pcolor(u + 0.5, d2 < 3 ? sq(1 - d2 / 3) : 0)
                    } else if (pattern == "segments") {
                        # Three coloured arcs rotating around the ring.
                        k = int((i + u * px * 3) / 8) % 3
                        pcolor(u + k / 3, 0.85)
                    } else if (pattern == "plasma") {
                        t = tri(i * 2 / px + u * 2) * tri(i * 3 / px - u * 3)
                        pcolor(i / px + t * 0.3 + u, 0.1 + 0.9 * t)
                    } else if (pattern == "storm") {
                        # Dim clouds with lightning bursts at fixed random frames.
                        v = 0.12 + 0.08 * tri(i / px + u * 2)
                        for (m = 0; m < NB; m++) {
                            age = f - BF[m]
                            if (age >= 0 && age < 4 && abs(i - BC[m]) < 4)
                                v = 1 - age / 4
                        }
                        pcolor(u + i / (px * 2), v)
                    } else if (pattern == "kaleido") {
                        pcolor(abs(i - px / 2) / px * 2 + u * 2, 0.85)
                    } else if (pattern == "strobe") {
                        # Whole ring flashes, jumping to a new colour each time.
                        pcolor(int(f / 12) / 16, f % 12 < 3 ? 1 : 0)
                    } else if (pattern == "colorcut") {
                        # Solid colour with hard cuts and a quick fade-in.
                        t = (f % 24) / 24
                        pcolor(int(f / 24) / 8 + i / (px * 6), t < 0.15 ? t / 0.15 : 1 - (t - 0.15) * 0.3)
                    } else if (pattern == "wipe" || pattern == "wipealt") {
                        # Colour wipes, each painting over the previous colour;
                        # wipealt reverses direction every wipe.
                        k = int(f / 48)
                        j = (pattern == "wipealt" && k % 2) ? px - 1 - i : i
                        prog = (f % 48) / 48 * px
                        if (j < int(prog)) pcolor((k + 1) / 4, 0.9)
                        else if (j == int(prog)) pcolor((k + 1) / 4, 1)
                        else pcolor(k / 4, 0.9)
                    } else if (pattern == "radar") {
                        # Sweeping beam that lights up blips as it passes.
                        b = (u * px * 2) % px
                        d = behind(b, i)
                        v = d < 3 ? (1 - d / 3) * 0.7 : 0.02
                        w = u
                        for (m = 0; m < 5; m++) {
                            if (i == RB[m]) {
                                age = behind(b, RB[m]) / px
                                if (sq(1 - age) > v) { v = sq(1 - age); w = u + 0.5 }
                            }
                        }
                        pcolor(w, v)
                    } else if (pattern == "pacman") {
                        # Lit body with a mouth opening and closing as it turns.
                        c = (u * px) % px
                        mouth = 0.5 + 4 * tri(u * 8)
                        pcolor(u, cdist(i, c) > mouth ? 0.9 : 0)
                    } else if (pattern == "loading") {
                        # Progress bar, then three blinks when complete.
                        if (f < 144) {
                            prog = f / 144 * px
                            v = i < int(prog) ? 0.8 : (i == int(prog) ? 1 : 0.03)
                            pcolor(i / (px * 2) + u, v)
                        } else {
                            pcolor(u, int((f - 144) / 8) % 2 == 0 ? 1 : 0.1)
                        }
                    } else if (pattern == "grow") {
                        # A snake grows to fill the ring, then its tail eats it.
                        s = u * 48
                        if (s < 24) v = i < s ? (i > s - 1.5 ? 1 : 0.7) : 0
                        else v = i >= s - 24 ? 0.7 : 0
                        pcolor(i / px + u, v)
                    } else if (pattern == "zipper") {
                        # Opens from the top down both sides, flashes, closes.
                        t = tri(u * 2)
                        r = t * 12
                        d = i <= px / 2 ? i : px - i
                        v = d <= r ? (d > r - 1 ? 1 : 0.35) : 0
                        if (t > 0.97) v = 1
                        pcolor(u + d / 24, v)
                    } else if (pattern == "fireworks") {
                        # A rocket climbs, then bursts outward and fades.
                        c = f % 96
                        cyc = int(f / 96)
                        target = 6 + cyc * 12
                        if (c < 24) {
                            p = target - 12 + c / 24 * 12
                            d = cdist(i, p)
                            pcolor(cyc * 0.5, d < 1 ? 1 : (d < 2.5 ? 0.15 : 0))
                        } else {
                            age = (c - 24) / 72
                            radius = age * 10
                            d = cdist(i, target)
                            w = (1 - age) * sqrt1(1 - age)
                            pcolor(cyc * 0.5 + d / 24, d <= radius ? w * (d > radius - 2 ? 1 : 0.4) : 0)
                        }
                    } else if (pattern == "raindrops") {
                        # Drops land at full brightness and fade out slowly.
                        t = ((f + PH1[i]) % T1[i]) / T1[i]
                        v = t < 0.05 ? t / 0.05 : (1 - (t - 0.05) / 0.95)
                        pcolor(PH2[i] / 192 + u * 0.5, v * v * v)
                    } else if (pattern == "static") {
                        # TV noise: every pixel random every frame.
                        n = lcg()
                        pcolor(lcg(), n * n * 0.8)
                    } else if (pattern == "glitch") {
                        # Dim base with short blocks jumping to other colours.
                        v = 0.12
                        w = u
                        for (m = 0; m < 12; m++) {
                            age = f - GF[m]
                            if (age >= 0 && age < GD[m] && abs(i - GC[m]) < GW[m]) {
                                v = 1
                                w = GP[m]
                            }
                        }
                        pcolor(w, v)
                    } else if (pattern == "dna") {
                        # Two dots crossing each other with eased motion.
                        t = smooth(tri(u * 2))
                        p1 = t * (px - 1)
                        p2 = (1 - t) * (px - 1)
                        d1 = abs(i - p1)
                        d2 = abs(i - p2)
                        if (d1 <= d2) pcolor(u, d1 < 2 ? 1 - d1 / 2 : 0.02)
                        else          pcolor(u + 0.5, d2 < 2 ? 1 - d2 / 2 : 0.02)
                    } else if (pattern == "pendulum") {
                        # A blob swinging with inertia, wider at the bottom.
                        s = smooth(tri(u * 3))
                        p = 2 + s * 20
                        width = 2 + 2 * (1 - abs(s * 2 - 1))
                        d = abs(i - p)
                        pcolor(u + s * 0.3, d < width ? sq(1 - d / width) : 0)
                    } else if (pattern == "heartbeat") {
                        t = (f % 48) / 48
                        pcolor(u + i / (px * 4), 0.04 + env(t) + 0.7 * env(t - 0.2))
                    } else if (pattern == "spokes") {
                        # Four spokes spinning forward, slowing, spinning back.
                        a = smooth(tri(u)) * px * 1.5
                        v = 0
                        w = 0
                        for (m = 0; m < 4; m++) {
                            d = cdist(i, a + m * 6)
                            if (d < 1.2 && 1 - d / 1.2 > v) { v = 1 - d / 1.2; w = m / 4 }
                        }
                        pcolor(u + w, v + 0.02)
                    } else if (pattern == "gears") {
                        # Neighbouring groups turn in opposite directions.
                        g = int(i / 6)
                        o = i % 6
                        ph = int(u * 48) * (g % 2 ? -1 : 1)
                        pcolor(g / 4 + u, ((o + ph) % 6 + 6) % 6 < 2 ? 1 : 0.05)
                    } else if (pattern == "binary") {
                        # An 8-bit counter, three pixels per bit.
                        count = int(f * 4 / 3)
                        b = 7 - int(i / 3)
                        pcolor(b / 8 + u, int(count / POW[b]) % 2 ? 0.9 : 0.03)
                    } else if (pattern == "stack") {
                        # Drops fall down both sides and pile up at the bottom.
                        k = int(f / 16)
                        drop = (f % 16) / 16 * (12 - k)
                        d = i <= px / 2 ? i : px - i
                        if (d > 12 - k) pcolor(d / 12 + u, 0.7)
                        else if (abs(d - drop) < 0.8) pcolor(u + 0.5, 1)
                        else pcolor(u, 0)
                    } else if (pattern == "lighthouse") {
                        # Two broad soft beams turning slowly, swelling.
                        b = u * px
                        d = cdist(i, b)
                        d2 = cdist(i, b + px / 2)
                        if (d2 < d) d = d2
                        w = d < 5 ? sq(1 - d / 5) : 0
                        pcolor(u, 0.04 + 0.96 * w * (0.6 + 0.4 * tri(u * 4)))
                    } else if (pattern == "checker") {
                        k = int(f / 12) % 2
                        pcolor(u + (i % 2) * 0.5, (i + k) % 2 == 0 ? 1 : 0.04)
                    } else if (pattern == "meet") {
                        # Two comets race toward each other and flash on impact.
                        t = (f % 48) / 48
                        d = i <= px / 2 ? i : px - i
                        if (t < 0.8) {
                            pos = t / 0.8 * 12
                            e = pos - d
                            v = e >= 0 && e < 4 ? sq(1 - e / 4) : 0
                        } else {
                            v = (1 - (t - 0.8) / 0.2) * (d >= 9 ? 1 : 0.3)
                        }
                        pcolor(int(f / 48) / 4 + d / 40, v)
                    } else if (pattern == "chaserev") {
                        # Chase that brakes and reverses halfway.
                        s = f < 96 ? int(f / 2) : int((192 - f) / 2)
                        k = (i + s) % 4
                        pcolor(i / px + u, k == 0 ? 1 : (k == 1 ? 0.2 : 0.02))
                    } else if (pattern == "morse") {
                        # SOS blinked by the whole ring.
                        pcolor(u, substr(SOS, f + 1, 1) == "1" ? 1 : 0.03)
                    } else if (pattern == "accel") {
                        # A comet that keeps speeding up through the loop.
                        d = behind((u * u * px * 6) % px, i)
                        pcolor(u * 2 - d * 0.04, d < 6 ? sq(1 - d / 6) : 0)
                    } else if (pattern == "halves") {
                        # Left and right halves fading in turn.
                        t = smooth(tri(u * 4))
                        if (i < px / 2) pcolor(u, t)
                        else            pcolor(u + 0.5, 1 - t)
                    }
                }
            }
        }
    '
}

# Simulations: small worlds with physics or rules, run for sim_frames frames
# instead of a short loop. Each frame fills V (brightness) and U (palette
# position) for the 24 ring pixels and emits them.
gen_sim() {
    awk -v frames="$sim_frames" -v pattern="$1" -v pal="$2" -v px=24 "$awk_lib"'
        function clear(base, u,    i) { for (i = 0; i < px; i++) { V[i] = base; U[i] = u } }
        function emit(    i) { for (i = 0; i < px; i++) pcolor(U[i], V[i]) }
        # Soft dot at fractional ring position p.
        function dot(p, value, u, radius,    i, d, w) {
            for (i = 0; i < px; i++) {
                d = cdist(i, p)
                if (d < radius) {
                    w = value * (1 - d / radius)
                    if (w > V[i]) { V[i] = w; U[i] = u }
                }
            }
        }
        function wrap(i) { i %= px; return i < 0 ? i + px : i }
        # Shortest step (+1 or -1) from a toward b around the ring.
        function toward(a, b,    d) {
            d = wrap(b - a)
            return d == 0 ? 0 : (d <= px / 2 ? 1 : -1)
        }
        # Height 0 (top) .. 12 (bottom) on the left or right side of the ring.
        function side(h, s) { return s == 0 ? h : px - h }

        function sim_bounce(    f, b, u) {
            for (b = 0; b < 4; b++) { Y[b] = -lcg() * 8; VY[b] = 0; S[b] = b % 2 }
            for (f = 0; f < frames; f++) {
                u = f / frames
                clear(0.02, u)
                for (b = 0; b < 4; b++) {
                    VY[b] += 0.035
                    Y[b] += VY[b]
                    if (Y[b] >= 12) {
                        Y[b] = 12
                        VY[b] = -VY[b] * 0.78
                        if (VY[b] > -0.08) { Y[b] = -lcg() * 10; VY[b] = 0; S[b] = int(lcg() * 2) }
                    }
                    if (Y[b] >= 0) dot(side(Y[b], S[b]), 1, u + b * 0.25, 1.6)
                }
                emit()
            }
        }

        function sim_snake(    f, len, k, food, head, u, flash) {
            len = 3; for (k = 0; k < len; k++) B[k] = wrap(-k)
            food = 12; flash = 0
            for (f = 0; f < frames; f++) {
                u = f / frames
                clear(0.02, u)
                if (flash > 0) {
                    flash--
                    for (k = 0; k < px; k++) { V[k] = (flash % 6 < 3) ? 1 : 0.1; U[k] = u + k / px }
                    if (flash == 0) { len = 3; for (k = 0; k < len; k++) B[k] = wrap(B[0] - k) }
                    emit(); continue
                }
                if (f % 3 == 0) {
                    head = wrap(B[0] + toward(B[0], food))
                    for (k = len; k > 0; k--) B[k] = B[k - 1]
                    B[0] = head
                    if (head == food) {
                        len++
                        if (len >= 20) flash = 36
                        do { food = int(lcg() * px); hit = 0; for (k = 0; k < len; k++) if (B[k] == food) hit = 1 } while (hit)
                    }
                }
                for (k = len - 1; k >= 0; k--) { V[B[k]] = k == 0 ? 1 : 0.75 - 0.5 * k / len; U[B[k]] = u + k * 0.02 }
                V[food] = f % 8 < 4 ? 1 : 0.25; U[food] = u + 0.5
                emit()
            }
        }

        function sim_automata(    f, i, r, rule, idx, n, gen, alive) {
            split("30 90 110 184", rules, " ")
            r = 0; gen = 0
            for (i = 0; i < px; i++) { C[i] = 0; L[i] = 0 }
            C[12] = 1
            for (f = 0; f < frames; f++) {
                if (f % 240 == 0 && f > 0) {
                    r = (r + 1) % 4
                    for (i = 0; i < px; i++) C[i] = rules[r + 1] >= 110 ? (lcg() < 0.45) : (i == 12)
                }
                if (f % 4 == 0) {
                    rule = rules[r + 1]
                    alive = 0
                    for (i = 0; i < px; i++) {
                        idx = C[wrap(i - 1)] * 4 + C[i] * 2 + C[wrap(i + 1)]
                        N[i] = int(rule / POW[idx]) % 2
                        alive += N[i]
                    }
                    for (i = 0; i < px; i++) C[i] = N[i]
                    if (alive == 0 || alive == px) for (i = 0; i < px; i++) C[i] = lcg() < 0.4
                }
                for (i = 0; i < px; i++) {
                    L[i] = C[i] ? 1 : L[i] * 0.6
                    V[i] = 0.02 + L[i] * 0.98
                    U[i] = r / 4 + i / (px * 2) + f / frames
                }
                emit()
            }
        }

        function sim_fireflies(    f, i, j, k, fired, more, coupling) {
            for (i = 0; i < px; i++) { PHS[i] = lcg(); W[i] = (0.9 + 0.2 * lcg()) / 40; L[i] = 0 }
            for (f = 0; f < frames; f++) {
                if (f % 480 == 0 && f > 0) for (i = 0; i < px; i++) PHS[i] = lcg()
                coupling = 0.06 * (f % 480) / 480
                for (i = 0; i < px; i++) { PHS[i] += W[i]; FIRE[i] = 0 }
                # Pulse coupling: a flash nudges everyone else toward firing.
                more = 1
                while (more) {
                    more = 0
                    for (i = 0; i < px; i++) if (PHS[i] >= 1 && !FIRE[i]) {
                        FIRE[i] = 1; more = 1
                        for (j = 0; j < px; j++) if (!FIRE[j]) PHS[j] += coupling
                    }
                }
                for (i = 0; i < px; i++) {
                    if (FIRE[i]) { PHS[i] -= int(PHS[i]); L[i] = 1 }
                    else L[i] *= 0.8
                    V[i] = 0.03 + 0.97 * L[i]
                    U[i] = i / (px * 2) + f / frames
                }
                emit()
            }
        }

        function sim_sort(    f, i, j, t, swapped, party, n) {
            for (i = 0; i < px; i++) A[i] = lcg()
            j = 0; swapped = 0; party = 0
            for (f = 0; f < frames; f++) {
                if (party > 0) {
                    party--
                    for (i = 0; i < px; i++) { V[i] = 0.3 + 0.7 * tri(i / px - party / 24); U[i] = A[i] * 0.9 }
                    if (party == 0) {
                        for (i = px - 1; i > 0; i--) { n = int(lcg() * (i + 1)); t = A[i]; A[i] = A[n]; A[n] = t }
                        j = 0; swapped = 0
                    }
                    emit(); continue
                }
                if (f % 2 == 0) {
                    if (A[j] > A[j + 1]) { t = A[j]; A[j] = A[j + 1]; A[j + 1] = t; swapped = 1 }
                    j++
                    if (j >= px - 1) { j = 0; if (!swapped) party = 48; swapped = 0 }
                }
                for (i = 0; i < px; i++) { V[i] = (i == j || i == j + 1) ? 1 : 0.35; U[i] = A[i] * 0.9 }
                emit()
            }
        }

        function sim_pong(    f, x, v, dir, boom, winner, u) {
            x = 12; v = 0.15; dir = 1; boom = 0
            for (f = 0; f < frames; f++) {
                u = f / frames
                clear(0.02, u)
                if (boom > 0) {
                    boom--
                    for (k = 0; k < px; k++) { V[k] = boom / 30; U[k] = winner ? u + 0.5 : u }
                    if (boom == 0) { x = 12; v = 0.15; dir = lcg() < 0.5 ? 1 : -1 }
                    emit(); continue
                }
                x += v * dir
                if (x >= 18 || x <= 6) {
                    if (lcg() < (v - 0.15) * 1.3) { winner = x <= 6; boom = 30; emit(); continue }
                    dir = -dir; v *= 1.12
                    x = x >= 18 ? 18 : 6
                }
                dot(6, 0.8, u, 1.5); dot(18, 0.8, u + 0.5, 1.5)
                dot(x, 1, u + 0.25, 1.2)
                emit()
            }
        }

        function sim_hunt(    f, k, best, d, nearest, u, step, t) {
            HP = 0
            for (k = 0; k < 3; k++) { PP[k] = 6 + k * 6; PD[k] = lcg() < 0.5 ? 1 : -1; BURST[k] = 0 }
            for (f = 0; f < frames; f++) {
                u = f / frames
                clear(0.02, u)
                best = 99
                for (k = 0; k < 3; k++) if (BURST[k] == 0) { d = cdist(HP, PP[k]); if (d < best) { best = d; nearest = k } }
                if (best < 99) {
                    step = toward(int(HP + 0.5), int(PP[nearest] + 0.5))
                    HP = HP + step * 0.21; HP -= int(HP / px) * px; if (HP < 0) HP += px
                }
                for (k = 0; k < 3; k++) {
                    if (BURST[k] > 0) {
                        BURST[k]--
                        dot(PP[k], BURST[k] / 20, u + 0.6, 1 + (20 - BURST[k]) / 3)
                        if (BURST[k] == 0) PP[k] = wrap(int(HP) + 12)
                        continue
                    }
                    if (lcg() < 0.03) PD[k] = -PD[k]
                    d = cdist(HP, PP[k])
                    # Flee: keep moving in the direction away from the hunter.
                    if (d < 5) { t = toward(int(HP + 0.5), int(PP[k] + 0.5)); PD[k] = t ? t : 1 }
                    PP[k] += PD[k] * (d < 5 ? 0.16 : 0.07); PP[k] -= int(PP[k] / px) * px; if (PP[k] < 0) PP[k] += px
                    if (d < 0.5) BURST[k] = 20
                    else dot(PP[k], 0.8, u + 0.4, 1.3)
                }
                dot(HP, 1, u, 1.8)
                emit()
            }
        }

        function sim_hourglass(    f, top, bottom, fall, fy, flip, k, h, u, shift) {
            top = 6; bottom = 0; fall = 0; flip = 0
            for (f = 0; f < frames; f++) {
                u = f / frames
                clear(0.02, u)
                if (flip > 0) {
                    flip--
                    shift = (24 - flip) / 24 * 12
                    for (k = 0; k < bottom; k++) { dot(side(12 - k, 0) + shift, 0.8, u + k / 30, 1); dot(side(12 - k, 1) + shift, 0.8, u + k / 30, 1) }
                    if (flip == 0) { top = bottom; bottom = 0 }
                    emit(); continue
                }
                if (!fall && top > 0 && f % 10 == 0) { top--; fall = 1; fy = top }
                if (fall) {
                    fy += 0.25
                    if (fy >= 12 - bottom) { fall = 0; bottom++ }
                }
                for (k = 0; k < top; k++) { dot(side(k, 0), 0.8, u + k / 30, 1); dot(side(k, 1), 0.8, u + k / 30, 1) }
                for (k = 0; k < bottom; k++) { dot(side(12 - k, 0), 0.8, u + 0.4 + k / 30, 1); dot(side(12 - k, 1), 0.8, u + 0.4 + k / 30, 1) }
                if (fall) { dot(side(fy, 0), 1, u + 0.2, 1); dot(side(fy, 1), 1, u + 0.2, 1) }
                if (top == 0 && !fall) flip = 24
                emit()
            }
        }

        function sim_spring(    f, i, acc, y) {
            for (i = 0; i < px; i++) { SY[i] = 0; SV[i] = 0 }
            for (f = 0; f < frames; f++) {
                if (f % 70 == 0) {
                    i = int(lcg() * px); y = lcg() < 0.5 ? 1.6 : -1.6
                    SY[i] += y; SY[wrap(i - 1)] += y * 0.5; SY[wrap(i + 1)] += y * 0.5
                }
                for (i = 0; i < px; i++) ACC[i] = 0.15 * (SY[wrap(i - 1)] + SY[wrap(i + 1)] - 2 * SY[i]) - 0.05 * SV[i]
                for (i = 0; i < px; i++) { SV[i] += ACC[i]; SY[i] += SV[i] }
                for (i = 0; i < px; i++) {
                    V[i] = 0.03 + abs(SY[i]) * 1.2
                    U[i] = f / frames + (SY[i] > 0 ? 0 : 0.5)
                }
                emit()
            }
        }

        function sim_heat(    f, i) {
            for (i = 0; i < px; i++) T[i] = 0
            for (f = 0; f < frames; f++) {
                if (lcg() < 0.05) { i = int(lcg() * px); T[i] += 1.6 }
                for (i = 0; i < px; i++) NT[i] = (T[i] + 0.2 * (T[wrap(i - 1)] + T[wrap(i + 1)] - 2 * T[i])) * 0.985
                for (i = 0; i < px; i++) {
                    T[i] = NT[i]
                    V[i] = 0.02 + T[i]
                    U[i] = f / frames + (T[i] > 1 ? 0.4 : T[i] * 0.4)
                }
                emit()
            }
        }

        function sim_crystal(    f, i, w, size, shatter, u, stuck) {
            for (i = 0; i < px; i++) { CL[i] = 0; ORD[i] = 0 }
            CL[12] = 1; size = 1; w = 0; shatter = 0
            for (f = 0; f < frames; f++) {
                u = f / frames
                clear(0.02, u)
                if (shatter > 0) {
                    shatter--
                    for (i = 0; i < px; i++) { V[i] = (shatter / 30) * (0.5 + 0.5 * lcg()); U[i] = u + lcg() }
                    if (shatter == 0) {
                        for (i = 0; i < px; i++) CL[i] = 0
                        i = int(lcg() * px); CL[i] = 1; size = 1; w = wrap(i + 12)
                    }
                    emit(); continue
                }
                if (f % 2 == 0) {
                    w = wrap(w + (lcg() < 0.5 ? 1 : -1))
                    stuck = CL[wrap(w - 1)] || CL[wrap(w + 1)]
                    if (stuck && !CL[w]) {
                        CL[w] = 1; ORD[w] = size; size++
                        if (size >= px) shatter = 30
                        else do { w = int(lcg() * px) } while (CL[w])
                    }
                }
                for (i = 0; i < px; i++) if (CL[i]) { V[i] = 0.45 + 0.25 * tri(f / 24 + i / 8); U[i] = u + ORD[i] / px }
                V[w] = 1; U[w] = u + 0.5
                emit()
            }
        }

        function sim_cradle(    f, c, t, amp, b, p, u, k) {
            for (f = 0; f < frames; f++) {
                u = f / frames
                clear(0.02, u)
                amp = 7 - 3 * f / frames
                c = f % 64; t = (c % 32) / 32
                for (b = 0; b < 5; b++) {
                    p = 10 + b
                    if (b == 0 && c < 32) p = 10 - amp * smooth(tri(t))
                    if (b == 4 && c >= 32) p = 14 + amp * smooth(tri(t))
                    k = (c < 32 ? c : c - 32)
                    dot(p, (b > 0 && b < 4 && k >= (b - 1) * 2 && k < b * 2) ? 1 : 0.7, u + b * 0.12, 1.1)
                }
                emit()
            }
        }

        BEGIN {
            init_palette()
            seed = 777
            POW[0] = 1
            for (b = 1; b < 8; b++) POW[b] = POW[b - 1] * 2
            if      (pattern == "bounce")    sim_bounce()
            else if (pattern == "snakegame") sim_snake()
            else if (pattern == "automata")  sim_automata()
            else if (pattern == "fireflies") sim_fireflies()
            else if (pattern == "sort")      sim_sort()
            else if (pattern == "pong")      sim_pong()
            else if (pattern == "hunt")      sim_hunt()
            else if (pattern == "hourglass") sim_hourglass()
            else if (pattern == "spring")    sim_spring()
            else if (pattern == "heat")      sim_heat()
            else if (pattern == "crystal")   sim_crystal()
            else if (pattern == "cradle")    sim_cradle()
        }
    '
}

# Music-reactive patterns: reactive_levels x 24 frames, indexed at playback
# by the current bass level and a rotation that the player advances.
gen_reactive() {
    awk -v pattern="$1" -v pal="$2" -v px=24 -v levels="$reactive_levels" "$awk_lib"'
        BEGIN {
            init_palette()
            top = levels - 1
            for (l = 0; l < levels; l++) for (r = 0; r < px; r++) {
                x = l / top
                for (i = 0; i < px; i++) {
                    if (pattern == "vu") {
                        # Meter rising from the bottom up both sides.
                        d = abs(i - 12)
                        n = x * 12.5
                        v = d < n ? (d > n - 1.5 ? 1 : 0.55) : 0.02
                        pcolor(r / px + d / 30, v)
                    } else if (pattern == "bassspin") {
                        # Comet whose length and brightness follow the bass.
                        d = behind(r, i)
                        len = 3 + x * 9
                        pcolor(r / px - d * 0.03, d < len ? (0.35 + 0.65 * x) * sq(1 - d / len) : 0.02)
                    } else if (pattern == "flash") {
                        # Whole ring brightness follows the bass.
                        pcolor(i / px + r / px, 0.03 + 0.97 * x * x)
                    } else if (pattern == "bloom") {
                        # Light blooming from top and bottom.
                        d = cdist(i, 0); d2 = cdist(i, 12); if (d2 < d) d = d2
                        w = 0.5 + x * 6
                        pcolor(r / px + d / 24, d < w ? 1 - d / (w + 0.5) : 0.02)
                    }
                }
            }
        }
    '
}

pattern_kind() {
    case " $sim_patterns " in *" $1 "*) echo sim; return ;; esac
    case " $reactive_patterns " in *" $1 "*) echo reactive; return ;; esac
    echo loop
}

# Frames for a pattern/palette pair are built the first time it is picked
# (well under a second, a few for simulations) and cached; there are too
# many pairs to build ahead.
ensure_frames() {
    ring_file="$state_dir/ring-$1-$2.frames"
    if [ ! -s "$ring_file" ]; then
        case $(pattern_kind "$1") in
            sim) printf '%b' "$(gen_sim "$1" "$2")" >"$ring_file.tmp" ;;
            reactive) printf '%b' "$(gen_reactive "$1" "$2")" >"$ring_file.tmp" ;;
            *) printf '%b' "$(gen_frames "$1" "$2" 24)" >"$ring_file.tmp" ;;
        esac
        mv "$ring_file.tmp" "$ring_file"
    fi
    logo_file="$state_dir/logo-$2.frames"
    if [ ! -s "$logo_file" ]; then
        printf '%b' "$(gen_frames logo "$2" 6)" >"$logo_file.tmp"
        mv "$logo_file.tmp" "$logo_file"
    fi
}

# Drops cached frames built by an older version of the patterns.
reset_stale_frames() {
    mkdir -p "$state_dir"
    if [ "$(cat "$state_dir/version" 2>/dev/null)" != "$frames_version" ]; then
        rm -f "$state_dir"/*.frames "$state_dir"/*.tmp
        echo "$frames_version" >"$state_dir/version"
    fi
}

# Builds every pair up front (optional; takes several minutes).
make_frames() {
    reset_stale_frames
    pal=0
    while [ "$pal" -lt "$palette_count" ]; do
        for pattern in $patterns; do
            ensure_frames "$pattern" "$pal"
        done
        pal=$((pal + 1))
    done
}

blank_clock() {
    for led in "$led_root"-*; do
        printf '0\n' >"$led/brightness" 2>/dev/null || true
    done
}

blank() {
    dd if=/dev/zero of=/dev/fb0 bs=72 count=1 conv=notrunc 2>/dev/null || true
    dd if=/dev/zero of=/dev/fb1 bs=18 count=1 conv=notrunc 2>/dev/null || true
    blank_clock
}

set_segment() {
    printf '%s\n' "$2" >"$led_root-$1/brightness"
}

# Lights digit $1 with the segments in $2.
write_digit() {
    for segment in a b c d e f g; do
        case "$2" in
            *"$segment"*) set_segment "$segment$1" "$brightness" ;;
            *) set_segment "$segment$1" 0 ;;
        esac
    done
}

# 7-segment glyph for one character of an upper-case ASCII string.
glyph() {
    case "$1" in
        0|O|D) lit=abcdef ;;  1|I) lit=bc ;;  2|Z) lit=abdeg ;;  3) lit=abcdg ;;
        4) lit=bcfg ;;  5|S) lit=acdfg ;;  6) lit=acdefg ;;  7) lit=abc ;;
        8|B) lit=abcdefg ;;  9) lit=abcdfg ;;  A) lit=abcefg ;;  C) lit=adef ;;
        E) lit=adefg ;;  F) lit=aefg ;;  G) lit=acdef ;;  H|X) lit=bcefg ;;
        J) lit=bcde ;;  K) lit=acefg ;;  L) lit=def ;;  M) lit=aceg ;;
        N) lit=ceg ;;  P) lit=abefg ;;  Q) lit=abcfg ;;  R) lit=eg ;;
        T) lit=defg ;;  U|W) lit=bcdef ;;  V) lit=cde ;;  Y) lit=bcdfg ;;
        -) lit=g ;;  _) lit=d ;;  *) lit= ;;
    esac
}

# Track title as upper-case ASCII: Cyrillic is transliterated, anything the
# display cannot draw becomes a space.
translit="Ш:SH Щ:SCH Ч:CH Ж:ZH Ц:TS Ю:YU Я:YA Ё:E Ь: Ъ: А:A Б:B В:V Г:G Д:D
Е:E З:Z И:I Й:Y К:K Л:L М:M Н:N О:O П:P Р:R С:S Т:T У:U Ф:F Х:H Ы:Y Э:E
ш:SH щ:SCH ч:CH ж:ZH ц:TS ю:YU я:YA ё:E ь: ъ: а:A б:B в:V г:G д:D е:E з:Z
и:I й:Y к:K л:L м:M н:N о:O п:P р:R с:S т:T у:U ф:F х:H ы:Y э:E"

display_text() {
    # Busybox sed works on bytes, so each Cyrillic letter is its own
    # substitution rather than a bracket class.
    script=
    for pair in $translit; do
        script="${script}s/${pair%%:*}/${pair#*:}/g;"
    done
    sed -e "$script" | tr 'a-z' 'A-Z' | tr -c 'A-Z0-9_\n-' ' ' | tr -s ' '
}

# Clock pattern 0: equalizer bars that drift toward random heights.
bar_segments() {
    case "$1" in
        1) lit=d ;;
        2) lit=cdeg ;;
        3) lit=abcdefg ;;
        *) lit= ;;
    esac
}

clock_eq() {
    for n in 1 2 3 4; do
        eval "h=\$h$n"
        target=$((RANDOM % 4))
        if [ "$target" -gt "$h" ]; then
            h=$((h + 1))
        elif [ "$target" -lt "$h" ]; then
            h=$((h - 1))
        fi
        eval "h$n=$h"
        bar_segments "$h"
        write_digit "$n" "$lit"
    done
}

# Clock pattern 1: a snake with a fading tail around the outer segments.
snake_path="a1 a2 a3 a4 b4 c4 d4 d3 d2 d1 e1 f1"

clock_snake() {
    k=0
    for segment in $snake_path; do
        case $(((tick - k + 120) % 12)) in
            0) value=$brightness ;;
            1) value=$((brightness / 2)) ;;
            2) value=$((brightness / 5)) ;;
            3) value=$((brightness / 15)) ;;
            *) value=0 ;;
        esac
        set_segment "$segment" "$value"
        k=$((k + 1))
    done
}

# Clock pattern 2: each digit spins a lit pair around its outer ring.
clock_spin() {
    for n in 1 2 3 4; do
        k=0
        for segment in a b c d e f; do
            case $(((tick + n * 2 - k + 60) % 6)) in
                0) value=$brightness ;;
                1) value=$((brightness / 4)) ;;
                *) value=0 ;;
            esac
            set_segment "$segment$n" "$value"
            k=$((k + 1))
        done
    done
}

# Clock pattern 3: random segments flash like rain.
clock_rain() {
    for segment in $rain_lit; do
        set_segment "$segment" 0
    done
    rain_lit=
    for _ in 1 2 3; do
        set -- a b c d e f g
        shift $((RANDOM % 7))
        segment="$1$((RANDOM % 4 + 1))"
        set_segment "$segment" "$brightness"
        rain_lit="$rain_lit $segment"
    done
}

# Clock pattern 4: a ball bouncing across the digits.
clock_bounce() {
    step=$((tick % 6))
    position=$((step < 4 ? step + 1 : 7 - step))
    for n in 1 2 3 4; do
        if [ "$n" -eq "$position" ]; then
            if [ $((tick % 2)) -eq 0 ]; then write_digit "$n" abfg; else write_digit "$n" cdeg; fi
        else
            write_digit "$n" ""
        fi
    done
}

# Clock pattern 5: bar heights rolling across the digits like a wave.
clock_wave() {
    for n in 1 2 3 4; do
        case $(((tick + n) % 6)) in
            0) h=0 ;; 1|5) h=1 ;; 2|4) h=2 ;; *) h=3 ;;
        esac
        bar_segments "$h"
        write_digit "$n" "$lit"
    done
}

# Clock pattern 6: a snake zigzagging through each digit in turn.
zigzag_path="a1 b1 g1 e1 d1 a2 b2 g2 e2 d2 a3 b3 g3 e3 d3 a4 b4 g4 e4 d4"

clock_zigzag() {
    k=0
    for segment in $zigzag_path; do
        case $(((tick - k + 200) % 20)) in
            0) value=$brightness ;;
            1) value=$((brightness / 2)) ;;
            2) value=$((brightness / 6)) ;;
            *) value=0 ;;
        esac
        set_segment "$segment" "$value"
        k=$((k + 1))
    done
}

# Clock pattern 7: a vertical bar sweeping left and right with a trail.
sweep_columns="e1f1 b1c1 e2f2 b2c2 e3f3 b3c3 e4f4 b4c4"

clock_sweep() {
    step=$((tick % 14))
    position=$((step < 8 ? step : 14 - step))
    previous=$((step < 8 ? position - 1 : position + 1))
    k=0
    for column in $sweep_columns; do
        if [ "$k" -eq "$position" ]; then
            value=$brightness
        elif [ "$k" -eq "$previous" ]; then
            value=$((brightness / 5))
        else
            value=0
        fi
        set_segment "${column%??}" "$value"
        set_segment "${column#??}" "$value"
        k=$((k + 1))
    done
}

# Clock pattern 8: a horizontal line rising and falling across all digits.
clock_lift() {
    case $((tick % 4)) in
        0) row=d ;; 1|3) row=g ;; *) row=a ;;
    esac
    for n in 1 2 3 4; do
        for segment in a g d; do
            if [ "$segment" = "$row" ]; then
                set_segment "$segment$n" "$brightness"
            else
                set_segment "$segment$n" 0
            fi
        done
    done
}

# Clock pattern 9: random digits flickering like a slot machine.
clock_slot() {
    for n in 1 2 3 4; do
        glyph $((RANDOM % 10))
        write_digit "$n" "$lit"
    done
}

# Clock pattern 10: bars closing in from the edges to the middle and back.
clock_converge() {
    case $((tick % 4)) in
        0) outer=adg; inner= ;;
        1) outer=g; inner=g ;;
        2) outer=; inner=adg ;;
        *) outer=g; inner=g ;;
    esac
    write_digit 1 "$outer"
    write_digit 4 "$outer"
    write_digit 2 "$inner"
    write_digit 3 "$inner"
}

# Clock pattern 11: the whole display breathing in and out.
clock_breathe() {
    step=$((tick % 16))
    level=$((step < 8 ? step : 16 - step))
    value=$((brightness * level * level / 64))
    for n in 1 2 3 4; do
        for segment in a b c d e f g; do
            set_segment "$segment$n" "$value"
        done
    done
}

# Clock pattern 12: a double heartbeat on the middle digits.
clock_heartbeat() {
    case $((tick % 12)) in
        0|2) value=$brightness ;;
        1) value=$((brightness / 4)) ;;
        3) value=$((brightness / 3)) ;;
        4) value=$((brightness / 10)) ;;
        *) value=0 ;;
    esac
    for n in 2 3; do
        for segment in a b c d e f g; do
            set_segment "$segment$n" "$value"
        done
    done
}

# Clock pattern 13: matrix rain, a drop falling down each digit at its own
# offset.
matrix_level() {
    case "$1" in
        0) lit=a ;; 1) lit=bf ;; 2) lit=g ;; 3) lit=ce ;; 4) lit=d ;; *) lit= ;;
    esac
}

clock_matrix() {
    for n in 1 2 3 4; do
        eval "off=\${matrix_off$n:-}"
        if [ -z "$off" ]; then
            off=$((RANDOM % 7))
            eval "matrix_off$n=$off"
        fi
        matrix_level $(((tick + off) % 7))
        write_digit "$n" "$lit"
    done
}

# Clock pattern 14: a dash bouncing between the digits with a trail.
clock_pingpong() {
    step=$((tick % 6))
    position=$((step < 4 ? step + 1 : 7 - step))
    previous=$((step < 4 ? position - 1 : position + 1))
    for n in 1 2 3 4; do
        if [ "$n" -eq "$position" ]; then
            set_segment "g$n" "$brightness"
        elif [ "$n" -eq "$previous" ]; then
            set_segment "g$n" $((brightness / 5))
        else
            set_segment "g$n" 0
        fi
    done
}

# Clock pattern 15: two snakes running around the edge in opposite directions.
clock_twosnakes() {
    head1=$((tick % 12))
    head2=$(((12 - tick % 12) % 12))
    k=0
    for segment in $snake_path; do
        d1=$(((head1 - k + 12) % 12))
        d2=$(((k - head2 + 12) % 12))
        if [ "$d1" -eq 0 ] || [ "$d2" -eq 0 ]; then
            value=$brightness
        elif [ "$d1" -eq 1 ] || [ "$d2" -eq 1 ]; then
            value=$((brightness / 4))
        else
            value=0
        fi
        set_segment "$segment" "$value"
        k=$((k + 1))
    done
}

# Clock pattern 16: segments light up one by one along the zigzag, then go
# out in the same order.
clock_fillup() {
    step=$((tick % 40))
    k=0
    for segment in $zigzag_path; do
        if [ "$step" -lt 20 ]; then
            if [ "$k" -le "$step" ]; then value=$brightness; else value=0; fi
        else
            if [ "$k" -gt $((step - 20)) ]; then value=$brightness; else value=0; fi
        fi
        set_segment "$segment" "$value"
        k=$((k + 1))
    done
}

# Clock pattern 17: short words flashing on and off.
clock_words="PLAY BASS DROP LOVE VIBE HYPE FIRE COOL YEAH LOUD"

clock_word() {
    case $((tick % 10)) in
        0)
            set -- $clock_words
            shift $((RANDOM % 10))
            word=$1
            ;;
    esac
    if [ $((tick % 10)) -lt 8 ]; then
        n=1
        while [ "$n" -le 4 ]; do
            glyph "${word:$((n - 1)):1}"
            write_digit "$n" "$lit"
            n=$((n + 1))
        done
    else
        for n in 1 2 3 4; do write_digit "$n" ""; done
    fi
}

# Clock pattern 18: a firefly wandering randomly along the zigzag.
clock_firefly() {
    fly_prev2=${fly_prev:-0}
    fly_prev=${fly:-0}
    fly=$(((${fly:-0} + RANDOM % 3 - 1 + 20) % 20))
    k=0
    for segment in $zigzag_path; do
        if [ "$k" -eq "$fly" ]; then
            value=$brightness
        elif [ "$k" -eq "$fly_prev" ]; then
            value=$((brightness / 3))
        elif [ "$k" -eq "$fly_prev2" ]; then
            value=$((brightness / 10))
        else
            value=0
        fi
        set_segment "$segment" "$value"
        k=$((k + 1))
    done
}

# Clock pattern 19: bars stacking up digit by digit, then clearing.
clock_stack() {
    step=$((tick % 16))
    for n in 1 2 3 4; do
        h=$((step - (n - 1) * 3))
        [ "$h" -ge 0 ] || h=0
        [ "$h" -le 3 ] || h=3
        [ "$step" -lt 14 ] || h=0
        bar_segments "$h"
        write_digit "$n" "$lit"
    done
}

# Clock pattern 20: the current time with a blinking colon.
clock_time() {
    if [ $((tick % 5)) -eq 0 ]; then
        stamp=$(TZ=MSK-3 date +%H%M)
        n=1
        while [ "$n" -le 4 ]; do
            glyph "${stamp:$((n - 1)):1}"
            write_digit "$n" "$lit"
            n=$((n + 1))
        done
        if [ $((tick % 10)) -eq 0 ]; then value=$brightness; else value=0; fi
        set_segment h1 "$value"
        set_segment h2 "$value"
    fi
}

# Clock pattern 21: police lights, halves flashing in turn.
clock_police() {
    if [ $((tick % 4)) -lt 2 ]; then
        left=abcdefg; right=
    else
        left=; right=abcdefg
    fi
    write_digit 1 "$left"
    write_digit 2 "$left"
    write_digit 3 "$right"
    write_digit 4 "$right"
}

# Clock pattern 22: sparks, single segments flashing and fading out.
clock_sparks() {
    for segment in $spark_dim; do
        set_segment "$segment" 0
    done
    spark_dim=$spark_lit
    for segment in $spark_dim; do
        set_segment "$segment" $((brightness / 5))
    done
    set -- a b c d e f g
    shift $((RANDOM % 7))
    spark_lit="$1$((RANDOM % 4 + 1))"
    set_segment "$spark_lit" "$brightness"
}

# Shows the next 4-character window of the scrolling title; returns 1 when
# the title has scrolled off.
title_step() {
    [ "$title_pos" -le $((${#title_text} - 4)) ] || return 1
    window=${title_text:$title_pos:4}
    n=1
    while [ "$n" -le 4 ]; do
        glyph "${window:$((n - 1)):1}"
        write_digit "$n" "$lit"
        n=$((n + 1))
    done
    title_pos=$((title_pos + 1))
}

# Random number below $1 that differs from $2.
pick_other() {
    while :; do
        picked=$((RANDOM % $1))
        [ "$picked" = "$2" ] || return 0
    done
}

# Switches to ring pattern $1, palette $2 and clock pattern $3 (indexes)
# and records them for the web interface and for locked mode.
set_mode() {
    pattern_index=$1
    palette=$2
    clock_pattern=$3
    set -- $patterns
    shift "$pattern_index"
    pattern_name=$1
    kind=$(pattern_kind "$pattern_name")
    ensure_frames "$pattern_name" "$palette"
    ring=$ring_file
    logo=$logo_file
    ring_frames=$(($(wc -c <"$ring") / 72))
    frame=0
    rot=0
    mode_elapsed=0
    if [ "$kind" = reactive ]; then start_analyzer; else stop_analyzer; fi
    echo "$pattern_index $palette $clock_pattern" >"$current_file"
}

# Bass follower for the reactive patterns: records the speaker monitor at
# 400 Hz (so only bass and low mids survive), and every ~80 ms writes
# "level beats" to level_file: level 0..12 with automatic gain, beats a
# counter bumped on each detected kick.
analyzer() {
    afifo=/run/soloist/audio.fifo
    rm -f "$afifo"
    mkfifo "$afifo"
    env HOME="$install_dir/pulse-home" PULSE_SERVER=unix:/run/soloist/pulse.sock \
        "$runtime/lib/ld-linux-aarch64.so.1" --library-path "$runtime/lib" "$runtime/bin/pacat" \
        --record --device=speakers.monitor --raw --format=s16le --rate=400 --channels=1 \
        --latency-msec=40 >"$afifo" 2>/dev/null &
    pacat_pid=$!
    trap 'kill $pacat_pid 2>/dev/null; rm -f "$afifo"; exit 0' TERM INT
    exec 3<"$afifo"
    # Soloist applies its volume before PulseAudio, so at low volume the
    # monitor is very quiet; the gain floor stays low to follow it anyway.
    peak=6 avg=0 cool=0 beats=0
    while :; do
        # One read returns whatever has arrived (up to 64 samples), so the
        # loop never falls behind the stream.
        s=$(dd bs=128 count=1 <&3 2>/dev/null | od -An -td2 -v |
            awk '{ for (i = 1; i <= NF; i++) { x = $i; t += x < 0 ? -x : x; n++ } } END { print n ? int(t / n) : -1 }')
        if [ "$s" -lt 0 ]; then
            # Nothing playing (or pacat gone): stay dark and do not spin.
            echo "0 $beats" >"$level_file"
            kill -0 "$pacat_pid" 2>/dev/null || exit 0
            usleep 200000
            continue
        fi
        peak=$((peak * 97 / 100))
        [ "$s" -le "$peak" ] || peak=$s
        [ "$peak" -ge 6 ] || peak=6
        avg=$(((avg * 7 + s) / 8))
        level=$((s * 12 / peak))
        if [ "$cool" -gt 0 ]; then
            cool=$((cool - 1))
        elif [ $((s * 10)) -gt $((avg * 14)) ] && [ $((s * 3)) -gt $((peak * 2)) ]; then
            beats=$((beats + 1))
            cool=3
        fi
        echo "$level $beats" >"$level_file"
        usleep 60000
    done
}

start_analyzer() {
    [ -z "${analyzer_pid:-}" ] || return 0
    # The player reads this every frame; a missing file would abort it.
    echo "0 0" >"$level_file"
    analyzer &
    analyzer_pid=$!
}

stop_analyzer() {
    [ -n "${analyzer_pid:-}" ] || return 0
    kill "$analyzer_pid" 2>/dev/null || true
    analyzer_pid=
}

is_reactive_index() {
    index=$1
    set -- $patterns
    shift "$index"
    [ "$(pattern_kind "$1")" = reactive ]
}

# Random ring pattern, palette and clock pattern, each different from the
# previous one.
pick_mode() {
    pick_other "$pattern_count" "${pattern_index:-}"
    # The reactive patterns listen to PulseAudio, which AirPlay bypasses.
    while [ -e /run/soloist/airplay.active ] && is_reactive_index "$picked"; do
        pick_other "$pattern_count" "${pattern_index:-}"
    done
    p=$picked
    pick_other "$palette_count" "${palette:-}"
    c=$picked
    pick_other "$clock_pattern_count" "${clock_pattern:-}"
    set_mode "$p" "$c" "$picked"
}

# True if "$1" is a whole number below $2.
valid_index() {
    case "$1" in ''|*[!0-9]*) return 1 ;; esac
    [ "$1" -lt "$2" ]
}

# Applies a mode requested by the web interface: "random", or three indexes
# where "-" keeps the current value.
apply_request() {
    request=$(cat "$request_file" 2>/dev/null || echo random)
    rm -f "$request_file"
    set -- $request
    if [ "${1:-random}" = random ]; then
        pick_mode
    else
        p=${1:-$pattern_index}; c=${2:-$palette}; k=${3:-$clock_pattern}
        [ "$p" != - ] || p=$pattern_index
        [ "$c" != - ] || c=$palette
        [ "$k" != - ] || k=$clock_pattern
        valid_index "$p" "$pattern_count" || p=$pattern_index
        valid_index "$c" "$palette_count" || c=$palette
        valid_index "$k" "$clock_pattern_count" || k=$clock_pattern
        set_mode "$p" "$c" "$k"
    fi
    if [ "$showing_title" -eq 0 ]; then
        blank_clock
    fi
}

# In locked mode the last mode is kept across tracks and restarts.
start_mode() {
    if [ -e "$lock_file" ] && [ -s "$current_file" ]; then
        set -- $(cat "$current_file")
        if valid_index "${1:-}" "$pattern_count" && valid_index "${2:-}" "$palette_count" &&
           valid_index "${3:-}" "$clock_pattern_count"; then
            set_mode "$1" "$2" "$3"
            return 0
        fi
    fi
    pick_mode
}

load_title() {
    title_text="   $(cat "$title_file" 2>/dev/null || true)    "
    title_pos=0
    showing_title=1
    blank_clock
}

animate() {
    switch=0
    apply=0
    trap 'stop_analyzer; blank; exit 0' TERM INT
    trap 'switch=1' USR1
    trap 'apply=1' USR2
    analyzer_pid=
    level=0
    last_beats=0

    h1=0 h2=0 h3=0 h4=0
    tick=0
    rain_lit=
    spark_lit=
    spark_dim=
    word=PLAY
    delay=$delay_max_us
    target_delay=$delay_min_us
    clock_elapsed=0
    start_mode
    load_title

    while :; do
        if [ "$kind" = reactive ]; then
            # Pick the frame for the current bass level; the rotation spins
            # with the bass (bassspin) or drifts and jumps on every kick.
            beats=$last_beats
            level=0
            if [ -r "$level_file" ]; then
                read -r level beats <"$level_file" || true
            fi
            case "$level" in ''|*[!0-9]*) level=0 ;; esac
            case "$beats" in ''|*[!0-9]*) beats=$last_beats ;; esac
            [ "$level" -lt "$reactive_levels" ] || level=$((reactive_levels - 1))
            if [ "$pattern_name" = bassspin ]; then
                rot=$(((rot + 1 + level / 3) % 24))
            elif [ $((frame % 4)) -eq 0 ]; then
                rot=$(((rot + 1) % 24))
            fi
            if [ "$beats" != "$last_beats" ]; then
                last_beats=$beats
                [ "$pattern_name" = bassspin ] || rot=$(((rot + 5) % 24))
            fi
            ring_index=$((level * 24 + rot))
        else
            ring_index=$frame
        fi
        dd if="$ring" of=/dev/fb0 bs=72 skip="$ring_index" count=1 conv=notrunc 2>/dev/null
        dd if="$logo" of=/dev/fb1 bs=18 skip=$((frame % frame_count)) count=1 conv=notrunc 2>/dev/null

        if [ "$kind" = loop ]; then
            # Ease the frame delay toward a target; pick a new one on arrival.
            step=$(((target_delay - delay) / 12))
            if [ "$step" -gt -300 ] && [ "$step" -lt 300 ]; then
                target_delay=$((delay_min_us + RANDOM % (delay_max_us - delay_min_us)))
            else
                delay=$((delay + step))
            fi
        else
            # Simulations run in real time; reactive patterns follow the music.
            if [ "$kind" = sim ]; then delay=50000; else delay=40000; fi
        fi

        # The clock keeps its own pace regardless of the ring speed; the
        # title scrolls one character every title_step_us.
        clock_elapsed=$((clock_elapsed + delay))
        if [ "$showing_title" -eq 1 ]; then
            if [ "$clock_elapsed" -ge "$title_step_us" ]; then
                clock_elapsed=0
                if ! title_step; then
                    showing_title=0
                    blank_clock
                fi
            fi
        elif [ "$clock_elapsed" -ge 110000 ]; then
            clock_elapsed=0
            tick=$((tick + 1))
            case "$clock_pattern" in
                0) if [ $((tick % 2)) -eq 0 ]; then clock_eq; fi ;;
                1) clock_snake ;;
                2) clock_spin ;;
                3) clock_rain ;;
                4) if [ $((tick % 2)) -eq 0 ]; then clock_bounce; fi ;;
                5) if [ $((tick % 2)) -eq 0 ]; then clock_wave; fi ;;
                6) clock_zigzag ;;
                7) clock_sweep ;;
                8) if [ $((tick % 2)) -eq 0 ]; then clock_lift; fi ;;
                9) if [ $((tick % 2)) -eq 0 ]; then clock_slot; fi ;;
                10) if [ $((tick % 3)) -eq 0 ]; then clock_converge; fi ;;
                11) clock_breathe ;;
                12) clock_heartbeat ;;
                13) if [ $((tick % 2)) -eq 0 ]; then clock_matrix; fi ;;
                14) clock_pingpong ;;
                15) clock_twosnakes ;;
                16) clock_fillup ;;
                17) clock_word ;;
                18) clock_firefly ;;
                19) if [ $((tick % 2)) -eq 0 ]; then clock_stack; fi ;;
                20) clock_time ;;
                21) clock_police ;;
                22) clock_sparks ;;
            esac
        fi

        mode_elapsed=$((mode_elapsed + delay))
        if [ "$apply" -eq 1 ]; then
            apply=0
            apply_request
        elif [ "$switch" -eq 1 ]; then
            # New track: its title, and a fresh animation unless locked.
            switch=0
            if [ ! -e "$lock_file" ]; then
                pick_mode
            fi
            load_title
        elif [ ! -e "$lock_file" ] && [ "$mode_elapsed" -ge "$switch_after_us" ]; then
            pick_mode
            if [ "$showing_title" -eq 0 ]; then
                blank_clock
            fi
        fi

        usleep "$delay"
        if [ "$kind" = reactive ]; then
            frame=$(((frame + 1) % frame_count))
        else
            frame=$(((frame + 1) % ring_frames))
        fi
    done
}

anim_pid=

start_anim() {
    [ -z "$anim_pid" ] || return 0
    [ ! -e "$disabled_file" ] || return 0
    animate &
    anim_pid=$!
    echo "$anim_pid" >"$anim_pid_file"
}

stop_anim() {
    [ -n "$anim_pid" ] || return 0
    kill "$anim_pid" 2>/dev/null || true
    wait "$anim_pid" 2>/dev/null || true
    anim_pid=
    rm -f "$anim_pid_file"
    blank
}

# A new track (Spotify or AirPlay): save its clock title and, if the
# animation is running, have it switch mode and scroll the title.
new_title() {
    printf '%s\n' "$1" | display_text >"$title_file"
    if [ -n "$anim_pid" ]; then
        kill -USR1 "$anim_pid" 2>/dev/null || true
    fi
}

# Spotify started playing: if an AirPlay stream is on, drop it by restarting
# shairport-sync (its respawn loop brings it straight back, without the
# session). airplay-hook.sh pauses Spotify the other way round.
end_airplay() {
    [ -e /run/soloist/airplay.active ] || return 0
    rm -f /run/soloist/airplay.active
    for pid in $(ps | awk '/runtime\/bin\/shairport-sync/ && !/awk/ { print $1 }'); do
        kill "$pid" 2>/dev/null || true
    done
}

# Lists and current state for the web interface, as JSON.
json_list() {
    printf '['
    sep=
    for item in $1; do
        printf '%s"%s"' "$sep" "$item"
        sep=,
    done
    printf ']'
}

info() {
    set -- $(cat "$current_file" 2>/dev/null || echo "0 0 0")
    printf '{"patterns":%s,"palettes":%s,"clock_patterns":%s,' \
        "$(json_list "$patterns")" "$(json_list "$palette_names")" "$(json_list "$clock_names")"
    printf '"current":[%s,%s,%s],"locked":%s,"enabled":%s,"running":%s}\n' \
        "${1:-0}" "${2:-0}" "${3:-0}" \
        "$([ -e "$lock_file" ] && echo true || echo false)" \
        "$([ -e "$disabled_file" ] && echo false || echo true)" \
        "$([ -s "$anim_pid_file" ] && kill -0 "$(cat "$anim_pid_file")" 2>/dev/null && echo true || echo false)"
}

run() {
    reset_stale_frames
    # Read events in this shell (not a pipeline subshell) so the trap
    # below can always stop the animation it started.
    events=/run/soloist/events.fifo
    rm -f "$events"
    mkfifo "$events"
    LD_LIBRARY_PATH="$runtime/lib" "$runtime/bin/soloist" ctl -w "$ws_addr" trace >"$events" 2>/dev/null &
    trace_pid=$!
    trap 'kill $trace_pid 2>/dev/null; stop_anim; rm -f "$events"; exit 0' TERM INT

    track=
    # The animation runs while Spotify or AirPlay plays; airplay-hook.sh adds
    # "airplay begin|end|title ..." lines to the same event stream.
    spotify_on=0
    airplay_on=0
    [ ! -e /run/soloist/airplay.active ] || airplay_on=1
    # trace exits when Soloist goes away; the respawn loop starts us again.
    while IFS= read -r line; do
        case "$line" in
            *'"type":"playback_state"'*'"status":"playing"'*)
                uri=${line#*'"item":{"uri":"'}
                uri=${uri%%'"'*}
                if [ "$uri" != "$track" ]; then
                    title=${line#*'"item":{"uri":"'}
                    title=${title#*'"identity":{"name":"'}
                    title=${title%%'"'*}
                    new_title "$title"
                fi
                track=$uri
                spotify_on=1
                airplay_on=0
                end_airplay
                start_anim
                ;;
            *'"type":"playback_state"'*|*'"type":"auth_state"'*'"logged_in":false'*)
                spotify_on=0
                [ "$airplay_on" = 1 ] || stop_anim
                ;;
            'airplay begin')
                airplay_on=1
                start_anim
                ;;
            'airplay end')
                airplay_on=0
                [ "$spotify_on" = 1 ] || stop_anim
                ;;
            'airplay title '*)
                new_title "${line#airplay title }"
                ;;
        esac
    done <"$events"
    stop_anim
    rm -f "$events"
}

case "${1:-}" in
    run) run ;;
    frames) make_frames ;;
    blank) blank ;;
    title) printf '%s\n' "${2:-}" | display_text ;;
    info) info ;;
    *) echo "Usage: $0 {run|frames|blank|info|title TEXT}" >&2; exit 2 ;;
esac
