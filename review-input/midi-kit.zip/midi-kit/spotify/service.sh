#!/bin/sh

set -eu

name=soloist
install_dir=/data/local/spotify
runtime="$install_dir/runtime"
name_file="$install_dir/device-name"
key_file="$install_dir/api-key"
proxy_file="$install_dir/proxy"
ws_addr=127.0.0.1:24879
indicator="$install_dir/indicator.sh"
voice="$install_dir/voice.sh"
voice_log="$install_dir/voice.log"
web_port=8088
airplay_dir="$install_dir/airplay"
airplay_log="$install_dir/airplay.log"
airplay_fifo=/run/soloist/airplay.fifo
# Set to -v (or -vv) to debug AirPlay sessions in airplay.log.
airplay_verbose=
data_dir="$install_dir/soloist-data"
pulse_home="$install_dir/pulse-home"
run_dir=/run/soloist
fifo="$run_dir/audio.fifo"
socket="$run_dir/pulse.sock"
log_file="$install_dir/soloist.log"
pulse_log="$install_dir/pulse.log"
pids="$run_dir/pids"

is_running() {
    [ -s "$pids" ] || return 1
    for pid in $(cat "$pids"); do
        kill -0 "$pid" 2>/dev/null || return 1
    done
}

# Run a command forever, restarting it two seconds after it exits.
respawn() {
    (
        trap 'kill $child 2>/dev/null; exit 0' TERM INT
        while :; do
            "$@" &
            child=$!
            wait "$child" || true
            sleep 2
        done
    ) &
    echo $! >>"$pids"
}

# At boot S98spotify runs before Wi-Fi has an address; Soloist then fails
# to restore its session once and never retries, so wait for the network.
wait_online() {
    tries=0
    while [ "$tries" -lt 120 ]; do
        if ip route 2>/dev/null | grep -q '^default' && [ "$(date +%Y)" -ge 2026 ]; then
            return 0
        fi
        sleep 1
        tries=$((tries + 1))
    done
}

run_soloist() {
    wait_online
    # Spotify refuses Russian IPs, so Soloist can go out through a proxy,
    # e.g. socks5h://192.168.1.248:10818. Re-read on every (re)start.
    proxy=
    [ ! -s "$proxy_file" ] || proxy=$(cat "$proxy_file")
    mark=$(wc -l <"$log_file")
    env HOME="$pulse_home" PULSE_SERVER="unix:$socket" LD_LIBRARY_PATH="$runtime/lib" \
        SSL_CERT_FILE="$runtime/ca-certificates.crt" \
        ALL_PROXY="$proxy" HTTPS_PROXY="$proxy" HTTP_PROXY="$proxy" NO_PROXY=localhost,127.0.0.1 \
        "$runtime/bin/soloist" \
        --device-name "$device_name" \
        --api-key "$(cat "$key_file")" \
        --data-dir "$data_dir" \
        --cache-size 256 \
        --initial-volume 35 \
        --ws "$ws_addr" \
        $verbose \
        >>"$log_file" 2>&1 &
    soloist_pid=$!
    trap 'kill $soloist_pid 2>/dev/null; exit 0' TERM INT

    # A failed session restore (proxy or network still down) is not retried
    # by Soloist itself; restart it after a pause instead.
    tries=0
    while [ "$tries" -lt 90 ] && kill -0 "$soloist_pid" 2>/dev/null; do
        if tail -n +"$((mark + 1))" "$log_file" | grep -q 'login failed'; then
            kill "$soloist_pid" 2>/dev/null
            sleep 15
            break
        fi
        sleep 1
        tries=$((tries + 1))
    done
    wait "$soloist_pid" 2>/dev/null || true
}

start_service() {
    if is_running; then
        echo "$name already running"
        return 0
    fi
    stop_service >/dev/null

    [ -x "$runtime/bin/soloist" ] || { echo "$runtime is missing" >&2; return 1; }
    [ -s "$name_file" ] || { echo "$name_file is missing or empty" >&2; return 1; }
    [ -s "$key_file" ] || { echo "$key_file is missing: put the Soloist API key there" >&2; return 1; }

    device_name=$(cat "$name_file")
    verbose=
    [ ! -e "$install_dir/verbose" ] || verbose=--verbose
    mkdir -p "$run_dir" /run/s "$data_dir" "$pulse_home"
    ln -sf "$runtime/lib/ld-linux-aarch64.so.1" /run/s/l
    rm -f "$fifo" "$socket" "$pids"
    mkfifo "$fifo"
    : >"$log_file"

    # PulseAudio renders into a FIFO; the stock aplay plays it on the
    # "speakers" softvol device, so it mixes with Alice and follows her volume.
    respawn /usr/bin/aplay -q -D speakers -f S16_LE -c 2 -r 44100 -t raw "$fifo"

    respawn env HOME="$pulse_home" PULSE_RUNTIME_PATH="$run_dir/pulse" \
        "$runtime/lib/ld-linux-aarch64.so.1" --library-path "$runtime/lib:$runtime/modules" \
        "$runtime/bin/pulseaudio" -n --daemonize=no --exit-idle-time=-1 --disallow-exit \
        --use-pid-file=no --dl-search-path="$runtime/modules" \
        --log-target=stderr --log-level=error \
        -L "module-pipe-sink file=$fifo format=s16le rate=44100 channels=2 sink_name=speakers" \
        -L "module-native-protocol-unix socket=$socket auth-anonymous=1" \
        2>"$pulse_log"

    tries=0
    while [ ! -S "$socket" ] && [ "$tries" -lt 50 ]; do
        usleep 100000
        tries=$((tries + 1))
    done

    respawn run_soloist

    # LED ring and clock animation while a track plays.
    if [ -x "$indicator" ]; then
        respawn "$indicator" run
    fi

    # Web remote for Spotify and the animations on http://<speaker>:8088/.
    if [ -x "$runtime/bin/busybox" ] && [ -d "$install_dir/web" ]; then
        respawn "$runtime/bin/busybox" httpd -f -p "$web_port" -h "$install_dir/web"
    fi

    # AirPlay receiver: avahi announces it, shairport-sync plays through its
    # own aplay on the "speakers" dmix. avahi takes Quasar's host name (with
    # the device serial) so the two mDNS responders do not fight over it.
    if [ -x "$runtime/bin/shairport-sync" ] && [ -f "$airplay_dir/shairport-sync.conf" ]; then
        serial=$(tr ' ' '\n' </proc/cmdline | sed -n 's/^androidboot.serialno=//p')
        sed "s/@SERIAL@/$serial/" "$airplay_dir/avahi-daemon.conf" >"$run_dir/avahi-daemon.conf"
        mkdir -p /run/avahi-daemon
        rm -f /run/avahi-daemon/pid "$run_dir/airplay.active"
        respawn "$runtime/lib/ld-linux-aarch64.so.1" --library-path "$runtime/lib" \
            "$runtime/bin/avahi-daemon" -f "$run_dir/avahi-daemon.conf" \
            --no-drop-root --no-chroot --no-rlimits --no-proc-title
        # shairport-sync writes 44.1 kHz stereo PCM here while a stream plays.
        rm -f "$airplay_fifo"
        mkfifo "$airplay_fifo"
        respawn /usr/bin/aplay -q -D speakers -f S16_LE -c 2 -r 44100 -t raw "$airplay_fifo"
        : >"$airplay_log"
        respawn sh -c "exec env HOME='$pulse_home' '$runtime/lib/ld-linux-aarch64.so.1' \
            --library-path '$runtime/lib' '$runtime/bin/shairport-sync' -c '$airplay_dir/shairport-sync.conf' \
            $airplay_verbose >>'$airplay_log' 2>&1"
        # Track titles from the AirPlay metadata pipe, for the clock.
        rm -f "$run_dir/airplay-meta"
        mkfifo "$run_dir/airplay-meta"
        respawn "$airplay_dir/airplay-meta.sh"
    fi

    # "дальше", "назад", "пауза", "продолжи" via Quasar's command spotter.
    if [ -x "$voice" ]; then
        : >"$voice_log"
        respawn sh -c "exec '$voice' run >>'$voice_log' 2>&1"
    fi

    # Soloist logs playback progress every few seconds; keep the log small.
    # It writes in append mode, so truncating the file in place is safe.
    (
        while :; do
            sleep 60
            if [ "$(wc -c <"$log_file")" -gt 1048576 ]; then
                tail -c 204800 "$log_file" >"$log_file.tmp"
                cat "$log_file.tmp" >"$log_file"
                rm -f "$log_file.tmp"
            fi
        done
    ) >/dev/null 2>&1 &
    echo $! >>"$pids"

    sleep 3
    if is_running; then
        echo "$name started (device: $device_name)"
    else
        echo "$name failed to start; see $log_file and $pulse_log" >&2
        return 1
    fi
}

stop_service() {
    if [ -s "$pids" ]; then
        for pid in $(cat "$pids"); do
            kill "$pid" 2>/dev/null || true
        done
    fi
    # Children of the respawn loops, and leftovers from older installs.
    for pid in $(ps -o pid,args | awk -v rt="$runtime" -v fifo="$fifo" -v old="$install_dir/librespot" \
        -v ind="$indicator" -v voice="$voice" \
        'index($0, rt) || index($0, fifo) || index($0, old) || index($0, ind) || index($0, voice) { print $1 }'); do
        [ "$pid" = "$$" ] || kill "$pid" 2>/dev/null || true
    done
    rm -f "$pids" "$fifo" "$socket" /run/librespot.pid "$run_dir/airplay.active" /run/avahi-daemon/pid \
        "$airplay_fifo"
    echo "$name stopped"
}

case "${1:-}" in
    start) start_service ;;
    stop) stop_service ;;
    restart) stop_service; start_service ;;
    status)
        if is_running; then
            echo "$name running (device: $(cat "$name_file"))"
        else
            echo "$name stopped"
            exit 1
        fi
        ;;
    log) cat "$log_file" ;;
    *) echo "Usage: $0 {start|stop|restart|status|log}" >&2; exit 2 ;;
esac
