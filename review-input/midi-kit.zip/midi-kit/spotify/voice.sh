#!/bin/sh

# Voice control for Soloist. Quasar's local command spotter recognises short
# phrases ("дальше", "пауза", ...) without the wake word and logs them to
# maind.log; forward them to Soloist while it is the active Spotify device.
# "играй"/"продолжи" also take over playback when the speaker is not the
# active device. Saying "хватит" three times in a row reboots the speaker.

set -eu

install_dir=/data/local/spotify
runtime="$install_dir/runtime"
ws_addr=127.0.0.1:24879
maind_log=/data/quasar/daemons_logs/maind.log

ctl() {
    LD_LIBRARY_PATH="$runtime/lib" "$runtime/bin/soloist" ctl -w "$ws_addr" "$@"
}

# Uptime in hundredths of a second, for timing phrases closer than 1 s.
uptime_cs() {
    read -r up _ </proc/uptime
    frac=${up#*.}
    # "08" would be read as a bad octal number.
    echo $((${up%.*} * 100 + ${frac#0}))
}

is_active() {
    ctl now --json 2>/dev/null | grep -q '"is_active":true'
}

# Take over Spotify playback on this speaker and resume what was last playing.
start_spotify() {
    ctl activate >/dev/null 2>&1 || return 0
    tries=0
    while ! is_active && [ "$tries" -lt 10 ]; do
        usleep 300000
        tries=$((tries + 1))
    done
    ctl play >/dev/null 2>&1 || true
}

action_for() {
    case "$1" in
        дальше|следующую|следующая|следующий) echo next ;;
        назад) echo prev ;;
        пауза|стоп|хватит) echo pause ;;
        продолжи|играй) echo play ;;
        *) echo "" ;;
    esac
}

run() {
    events=/run/soloist/voice.fifo
    rm -f "$events"
    mkfifo "$events"
    # -F follows maind.log across its frequent rotations.
    tail -n 0 -F "$maind_log" 2>/dev/null >"$events" &
    tail_pid=$!
    trap 'kill $tail_pid 2>/dev/null; rm -f "$events"; exit 0' TERM INT

    last=
    last_time=0
    stop_first=0
    stop_last=0
    stop_count=0
    while IFS= read -r line; do
        # Depending on Quasar's state a spotted phrase is either handled or
        # reported as disabled; both mean the user said it.
        case "$line" in
            *'Command phrase spotted: '*)
                phrase=${line##*Command phrase spotted: }
                ;;
            *'command_spotter_capability'*'Phrase '*' is disabled for current states'*)
                phrase=${line##*Phrase }
                ;;
            *) continue ;;
        esac
        phrase=${phrase%% *}

        # "хватит" three times within six seconds reboots the speaker.
        if [ "$phrase" = хватит ]; then
            now_cs=$(uptime_cs)
            # One utterance can be reported twice; count it once.
            if [ $((now_cs - stop_last)) -ge 60 ]; then
                if [ $((now_cs - stop_first)) -gt 600 ]; then
                    stop_first=$now_cs
                    stop_count=0
                fi
                stop_count=$((stop_count + 1))
                stop_last=$now_cs
                if [ "$stop_count" -ge 3 ]; then
                    echo "$(date '+%F %T') хватит x3 -> reboot"
                    sync
                    reboot
                fi
            fi
        fi

        action=$(action_for "$phrase")
        [ -n "$action" ] || continue

        # The spotter can report one utterance twice; ignore quick repeats.
        now=$(date +%s)
        if [ "$action" = "$last" ] && [ $((now - last_time)) -lt 2 ]; then
            continue
        fi
        last=$action
        last_time=$now

        if is_active; then
            ctl "$action" >/dev/null 2>&1 || true
            echo "$(date '+%F %T') $phrase -> $action"
        elif [ "$action" = play ]; then
            start_spotify
            echo "$(date '+%F %T') $phrase -> activate + play"
        fi
    done <"$events"
    kill "$tail_pid" 2>/dev/null || true
    rm -f "$events"
}

case "${1:-}" in
    run) run ;;
    *) echo "Usage: $0 run" >&2; exit 2 ;;
esac
