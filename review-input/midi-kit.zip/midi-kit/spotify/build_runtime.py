#!/usr/bin/env python3
"""Build a self-contained Soloist + PulseAudio runtime for the Station (glibc 2.30).

Downloads the official Spotify Soloist arm64 build and the Debian trixie arm64
libraries it needs (glibc 2.41, libpulse, pulseaudio daemon) into build/runtime.
Soloist is not redistributed: it is always fetched from Spotify's CDN.
"""

import lzma
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request

here = os.path.dirname(os.path.abspath(__file__))
build = os.path.join(here, "build")
runtime = os.path.join(build, "runtime")

soloist_url = "https://soloist-builds.spotifycdn.com/soloist_release_arm64.tar.gz"
debian = "https://deb.debian.org/debian"
index_url = debian + "/dists/trixie/main/binary-arm64/Packages.xz"

packages = """
libc6 libgcc-s1 libatomic1 libstdc++6 libgomp1 pulseaudio libpulse0
libasyncns0 libdbus-1-3 libsystemd0 libcap2 libsndfile1 libflac14 libogg0
libvorbis0a libvorbisenc2 libopus0 libmpg123-0t64 libmp3lame0 libx11-6
libx11-xcb1 libxcb1 libxau6 libxdmcp6 libltdl7 libsoxr0 libspeexdsp1 libtdb1
liborc-0.4-0t64 libwrap0 ca-certificates busybox-static pulseaudio-utils
shairport-sync avahi-daemon libavahi-client3 libavahi-common3 libavahi-core7
libdaemon0 libexpat1 libconfig11 libpopt0 libssl3t64 libglib2.0-0t64
libffi8 libpcre2-8-0 libmount1 libblkid1 libselinux1 libjack-jackd2-0
libdb5.3t64 libsamplerate0 libmosquitto1 libcjson1 libasound2t64 zlib1g libzstd1
""".split()

# Binaries copied from the Debian packages into runtime/bin; all of them run
# through the bundled loader, so their libraries join the closure below.
extra_binaries = {
    "pacat": "usr/bin/pacat",
    "shairport-sync": "usr/bin/shairport-sync",
    "avahi-daemon": "usr/sbin/avahi-daemon",
}

pulse_modules = [
    "module-pipe-sink.so",
    "module-native-protocol-unix.so",
    "libprotocol-native.so",
]

# Soloist's PT_INTERP is rewritten to this path; service.sh symlinks it to
# the bundled loader. It must not be longer than the original interpreter.
interp = b"/run/s/l"


def fetch(url, path):
    if not os.path.exists(path):
        print("fetch", url)
        with urllib.request.urlopen(url) as r, open(path + ".part", "wb") as f:
            shutil.copyfileobj(r, f)
        os.rename(path + ".part", path)
    return path


def read_index(path):
    files = {}
    with lzma.open(path, "rt", encoding="utf-8", errors="replace") as f:
        name = None
        for line in f:
            if line.startswith("Package: "):
                name = line.split()[1]
            elif line.startswith("Filename: ") and name:
                files.setdefault(name, line.split()[1])
    return files


def extract_deb(deb, dest):
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.run(["ar", "x", deb], cwd=tmp, check=True)
        data = next(n for n in os.listdir(tmp) if n.startswith("data.tar"))
        subprocess.run(["tar", "-xf", os.path.join(tmp, data), "-C", dest], check=True)


def needed(path):
    out = subprocess.run(["objdump", "-p", path], capture_output=True, text=True, check=True).stdout
    return [l.split()[-1] for l in out.splitlines() if "NEEDED" in l]


def main():
    cache = os.path.join(build, "cache")
    root = os.path.join(build, "root")
    os.makedirs(cache, exist_ok=True)
    shutil.rmtree(root, ignore_errors=True)
    shutil.rmtree(runtime, ignore_errors=True)
    os.makedirs(root)

    index = read_index(fetch(index_url, os.path.join(cache, "Packages.xz")))
    for name in packages:
        filename = index[name]
        extract_deb(fetch(debian + "/" + filename, os.path.join(cache, os.path.basename(filename))), root)

    soloist_tgz = os.path.join(cache, "soloist.tar.gz")
    if os.path.exists(soloist_tgz) and "--refresh" in sys.argv:
        os.remove(soloist_tgz)
    with tarfile.open(fetch(soloist_url, soloist_tgz)) as t:
        t.extract("soloist", root, filter="data")

    lib_dirs = [
        os.path.join(root, "usr/lib/aarch64-linux-gnu"),
        os.path.join(root, "usr/lib/aarch64-linux-gnu/pulseaudio"),
    ]
    mod_dir = next(
        os.path.join(root, "usr/lib", d, "modules")
        for d in os.listdir(os.path.join(root, "usr/lib"))
        if d.startswith("pulse-")
    )

    def find(name):
        for d in lib_dirs:
            p = os.path.join(d, name)
            if os.path.exists(p):
                return os.path.realpath(p)

    for d in ("bin", "lib", "modules"):
        os.makedirs(os.path.join(runtime, d))
    shutil.copy(os.path.join(root, "soloist"), os.path.join(runtime, "bin/soloist"))
    shutil.copy(os.path.join(root, "usr/bin/pulseaudio"), os.path.join(runtime, "bin/pulseaudio"))
    # Static busybox for its httpd: the Station's own busybox has none.
    shutil.copy(os.path.join(root, "usr/bin/busybox"), os.path.join(runtime, "bin/busybox"))
    # pacat records the speaker monitor for the music-reactive animations;
    # shairport-sync and avahi-daemon make the speaker an AirPlay receiver.
    for name, src in extra_binaries.items():
        shutil.copy(os.path.join(root, src), os.path.join(runtime, "bin", name))
    os.makedirs(os.path.join(runtime, "share"))
    # Lets avahi-daemon own its name on the Station's system bus.
    shutil.copy(os.path.join(root, "usr/share/dbus-1/system.d/avahi-dbus.conf"),
                os.path.join(runtime, "share/avahi-dbus.conf"))
    for m in pulse_modules:
        shutil.copy(os.path.join(mod_dir, m), os.path.join(runtime, "modules", m))

    todo = [os.path.join(runtime, "bin", b) for b in ["soloist", "pulseaudio"] + list(extra_binaries)]
    todo += [os.path.join(runtime, "modules", m) for m in pulse_modules]
    todo.append(find("libpulse.so.0"))
    seen, missing = {"ld-linux-aarch64.so.1"}, set(pulse_modules)
    shutil.copy(find("ld-linux-aarch64.so.1"), os.path.join(runtime, "lib/ld-linux-aarch64.so.1"))
    unresolved = set()
    while todo:
        for name in needed(todo.pop()):
            if name in seen or name in missing or name in unresolved:
                continue
            path = find(name)
            if not path:
                unresolved.add(name)
                continue
            seen.add(name)
            shutil.copy(path, os.path.join(runtime, "lib", name))
            todo.append(path)
    if unresolved:
        sys.exit("missing libraries: " + " ".join(sorted(unresolved)))

    soloist = os.path.join(runtime, "bin/soloist")
    with open(soloist, "rb") as f:
        data = f.read()
    old = b"/lib/ld-linux-aarch64.so.1\0"
    if data.count(old) != 1:
        sys.exit("unexpected soloist interpreter")
    data = data.replace(old, interp.ljust(len(old), b"\0"))
    with open(soloist, "wb") as f:
        f.write(data)

    # Advertise the AirPlay receiver as a HomePod (model AudioAccessory1,1)
    # instead of ShairportSync, so Apple devices show it with a HomePod icon.
    # The TXT string is followed by 8 alignment NULs before the next one, so
    # the longer model still fits in place.
    shairport = os.path.join(runtime, "bin/shairport-sync")
    with open(shairport, "rb") as f:
        data = f.read()
    old = b"am=ShairportSync" + b"\0" * 8
    new = b"am=AudioAccessory1,1"
    if data.count(old) != 1:
        sys.exit("unexpected shairport-sync TXT layout")
    data = data.replace(old, new.ljust(len(old), b"\0"))
    with open(shairport, "wb") as f:
        f.write(data)

    # The Station's /etc/ssl/certs is empty; service.sh points SSL_CERT_FILE here.
    mozilla = os.path.join(root, "usr/share/ca-certificates/mozilla")
    with open(os.path.join(runtime, "ca-certificates.crt"), "wb") as bundle:
        for name in sorted(os.listdir(mozilla)):
            with open(os.path.join(mozilla, name), "rb") as f:
                bundle.write(f.read().rstrip(b"\n") + b"\n")

    for p in ["bin/soloist", "bin/pulseaudio", "bin/busybox", "lib/ld-linux-aarch64.so.1"] + \
             ["bin/" + b for b in extra_binaries]:
        os.chmod(os.path.join(runtime, p), 0o755)
    shutil.rmtree(root)
    print("runtime ready:", runtime, "(%d libraries)" % (len(seen)))


if __name__ == "__main__":
    main()
