#!/bin/sh

# One-shot installer for the Yandex Station Midi kit: Spotify (Soloist) with
# LED animations, voice control and a web remote, an AirPlay receiver that
# shows up as a HomePod, an SSH welcome screen and an optional boot chime.
#
# Usage:
#   sh install.sh                      # asks for everything it needs
#   MIDI_HOST=root@192.168.1.50 SOLOIST_API_KEY=spak_... SOLOIST_PROXY=socks5h://host:port sh install.sh
#
# Variables (all optional, asked for interactively when missing):
#   MIDI_HOST        ssh target of the speaker, e.g. root@192.168.1.50
#   SOLOIST_API_KEY  your own key from https://developer.spotify.com/dashboard/soloist
#   SOLOIST_PROXY    SOCKS5 proxy for Spotify, e.g. socks5h://192.168.1.10:1080
#                    ("none" to skip; Spotify refuses Russian IP addresses)
#   DEVICE_NAME      name in the Spotify app (default: Yandex Station Midi Spotify)
#   CHIME_WAV        a .wav to play after boot (skipped when not given)

set -eu

kit_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
# --check: run every check of this computer and the speaker, install nothing.
check_only=0
[ "${1:-}" != --check ] || check_only=1

say() { printf '\033[38;2;170;120;255m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[38;2;255;170;60m!!\033[0m %s\n' "$*" >&2; }
die() { printf '\033[38;2;255;80;80mxx\033[0m %s\n' "$*" >&2; exit 1; }

ask() {
    # ask VAR "question" [default] [secret]
    eval "current=\${$1:-}"
    [ -z "$current" ] || return 0
    if [ -n "${3:-}" ]; then
        printf '%s [%s]: ' "$2" "$3"
    else
        printf '%s: ' "$2"
    fi
    if [ -n "${4:-}" ]; then
        stty -echo 2>/dev/null || true
        read -r answer
        stty echo 2>/dev/null || true
        echo
    else
        read -r answer
    fi
    [ -n "$answer" ] || answer=${3:-}
    eval "$1=\$answer"
}

# 1. Tools on this computer.
say "Проверяю этот компьютер"
for tool in ssh tar python3 ar objdump; do
    command -v "$tool" >/dev/null 2>&1 ||
        die "Не найден '$tool'. macOS: xcode-select --install; Debian/Ubuntu: sudo apt install openssh-client python3 binutils"
done
python3 -c 'import lzma, tarfile, urllib.request' 2>/dev/null || die "В python3 нет модулей lzma/tarfile"

# 2. Parameters.
ask MIDI_HOST "Адрес колонки для ssh (например root@192.168.1.50)"
[ -n "$MIDI_HOST" ] || die "Нужен адрес колонки"
if [ "$check_only" = 0 ]; then
    ask SOLOIST_API_KEY "Ключ Soloist (spak_..., на экране не видно)" "" secret
    case "$SOLOIST_API_KEY" in
        spak_*) ;;
        *) die "Ключ Soloist начинается с spak_ (бери на https://developer.spotify.com/dashboard/soloist, а не Client ID приложения)" ;;
    esac
fi
SOLOIST_API_KEY=${SOLOIST_API_KEY:-}
[ "$check_only" = 0 ] || SOLOIST_PROXY=${SOLOIST_PROXY:-none}
ask SOLOIST_PROXY "SOCKS5-прокси для Spotify или 'none'" "none"
[ "$SOLOIST_PROXY" != none ] || SOLOIST_PROXY=
case "$SOLOIST_PROXY" in
    ''|socks5://*|socks5h://*|http://*) ;;
    *) die "Прокси должен выглядеть как socks5h://host:port" ;;
esac
DEVICE_NAME=${DEVICE_NAME:-Yandex Station Midi Spotify}
CHIME_WAV=${CHIME_WAV:-}

# 3. The speaker: reachable with a key, and really a Station Midi.
say "Проверяю колонку $MIDI_HOST"
ssh -o BatchMode=yes -o ConnectTimeout=10 "$MIDI_HOST" true 2>/dev/null ||
    die "Не получается зайти на $MIDI_HOST по ssh-ключу. Смотри INSTALL.md, шаг 2."
info=$(ssh -o BatchMode=yes "$MIDI_HOST" '
    tr "\0" " " </proc/device-tree/compatible 2>/dev/null; echo
    df -m /data | awk "NR == 2 { print \$4 }"
    [ -x /usr/bin/aplay ] && echo aplay-ok
    [ -S /run/dbus/system_bus_socket ] && echo dbus-ok
')
case "$info" in *yandex,cucumber*) ;; *) die "Это не похоже на Яндекс Станцию Миди (cucumber)." ;; esac
free_mb=$(printf '%s\n' "$info" | sed -n 2p)
[ "${free_mb:-0}" -ge 300 ] || die "Нужно хотя бы 300 МБ свободно на /data, а есть ${free_mb:-?} МБ"
case "$info" in *aplay-ok*) ;; *) die "На колонке нет /usr/bin/aplay" ;; esac
case "$info" in *dbus-ok*) ;; *) warn "На колонке нет системного D-Bus: AirPlay не будет виден в сети" ;; esac

if [ "$check_only" = 1 ]; then
    say "Проверка пройдена: компьютер и колонка готовы (свободно ${free_mb} МБ). Ничего не установлено."
    exit 0
fi

# 4. Spotify, animations, voice, web remote and AirPlay. The first run
#    downloads Soloist from Spotify and ~50 Debian packages (a few minutes).
say "Ставлю Spotify, анимации, голосовое управление, веб-пульт и AirPlay"
SPOTIFY_HOST=$MIDI_HOST SOLOIST_API_KEY=$SOLOIST_API_KEY SOLOIST_PROXY=$SOLOIST_PROXY \
    sh "$kit_dir/spotify/setup.sh" "$DEVICE_NAME"

# 5. SSH welcome screen.
say "Ставлю приветствие для ssh"
SPOTIFY_HOST=$MIDI_HOST sh "$kit_dir/welcome/setup.sh"

# 6. Boot chime, only with a sound of your own.
if [ -n "$CHIME_WAV" ]; then
    [ -f "$CHIME_WAV" ] || die "Не найден CHIME_WAV: $CHIME_WAV"
    say "Ставлю звук при включении"
    cp "$CHIME_WAV" "$kit_dir/boot-chime/chime.wav"
    SPOTIFY_HOST=$MIDI_HOST sh "$kit_dir/boot-chime/setup.sh"
elif [ -f "$kit_dir/boot-chime/chime.wav" ]; then
    say "Ставлю звук при включении"
    SPOTIFY_HOST=$MIDI_HOST sh "$kit_dir/boot-chime/setup.sh"
else
    say "Звук при включении пропускаю (добавь CHIME_WAV=/путь/к/звуку.wav)"
fi

ip=${MIDI_HOST#*@}
cat <<EOF

$(printf '\033[38;2;80;220;140m')Готово.$(printf '\033[0m')

  Spotify   в приложении Spotify: устройства, выбери "$DEVICE_NAME"
  AirPlay   на iPhone или Маке выбери "HomePod" в списке AirPlay
  Пульт     http://$ip:8088/
  Голос     без "Алиса": дальше, назад, пауза, стоп, играй
            "хватит" три раза подряд перезагружает колонку
  SSH       ssh $MIDI_HOST покажет приветствие

EOF
