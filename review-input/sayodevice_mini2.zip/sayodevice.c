#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#ifndef KEY_VOLUMEDOWN
#define KEY_VOLUMEDOWN 114U
#endif
#ifndef KEY_VOLUMEUP
#define KEY_VOLUMEUP 115U
#endif
#ifndef KEY_VOICECOMMAND
#define KEY_VOICECOMMAND 582U
#endif

#ifndef EV_SYN
#define EV_SYN 0x00U
#endif
#ifndef EV_KEY
#define EV_KEY 0x01U
#endif
#ifndef SYN_REPORT
#define SYN_REPORT 0U
#endif
#ifndef SYN_DROPPED
#define SYN_DROPPED 3U
#endif
#ifndef KEY_MAX
#define KEY_MAX 0x2FFU
#endif

#if defined(__LP64__) || defined(_LP64)
typedef struct {
    uint64_t tv_sec;
    uint64_t tv_usec;
    uint16_t type;
    uint16_t code;
    int32_t value;
} raw_input_event_t;
_Static_assert(sizeof(raw_input_event_t) == 24, "Invalid 64-bit raw_input_event_t size");
#else
typedef struct {
    uint32_t tv_sec;
    uint32_t tv_usec;
    uint16_t type;
    uint16_t code;
    int32_t value;
} raw_input_event_t;
_Static_assert(sizeof(raw_input_event_t) == 16, "Invalid 32-bit raw_input_event_t size");
#endif

#ifndef EVIOCSMASK
struct local_input_mask {
    uint32_t type;
    uint32_t codes_size;
    uint64_t codes_ptr;
};
#define LOCAL_EVIOCSMASK _IOW('E', 0x93, struct local_input_mask)
#endif

#ifndef AF_BLUETOOTH
#define AF_BLUETOOTH 31
#endif
#ifndef PF_BLUETOOTH
#define PF_BLUETOOTH AF_BLUETOOTH
#endif
#ifndef BTPROTO_L2CAP
#define BTPROTO_L2CAP 0
#endif
#ifndef BTPROTO_HCI
#define BTPROTO_HCI 1
#endif
#ifndef HCIDEVUP
#define HCIDEVUP _IOW('H', 201, int)
#endif
#ifndef HCISETSCAN
#define HCISETSCAN _IOW('H', 221, int)
#endif
#ifndef HCIGETCONNLIST
#define HCIGETCONNLIST _IOR('H', 212, int)
#endif
#define HCI_SCAN_INQUIRY 0x01U
#define HCI_SCAN_PAGE 0x02U

struct local_hci_dev_req {
    uint16_t dev_id;
    uint32_t dev_opt;
};

typedef struct {
    uint8_t b[6];
} __attribute__((packed)) bdaddr_t;

struct local_hci_conn_info {
    uint16_t handle;
    bdaddr_t bdaddr;
    uint8_t type;
    uint8_t out;
    uint16_t state;
    uint32_t link_mode;
};

struct local_hci_conn_list_req {
    uint16_t dev_id;
    uint16_t conn_num;
    struct local_hci_conn_info conn_info[8];
};

struct sockaddr_l2 {
    sa_family_t l2_family;
    unsigned short l2_psm;
    bdaddr_t l2_bdaddr;
    unsigned short l2_cid;
    uint8_t l2_bdaddr_type;
};

#define L2CAP_PSM_HIDP_CTRL 0x0011U
#define L2CAP_PSM_HIDP_INTR 0x0013U

#define HALF_OPEN_CTRL_TIMEOUT_MS 5000ULL
#define SEARCH_ANIM_INTERVAL_MS 60ULL
#define EFFECT_ANIM_INTERVAL_MS 35ULL
#define REOPEN_RETRY_INTERVAL_MS 250ULL
#define PISCAN_REFRESH_INTERVAL_MS 15000ULL
#define MACRO_DEFAULT_STEP_MS 6ULL

#define MAX_INPUT_DEVS 16
#define SAYO_KEY_COUNT 3
#define SAYO_FN_LAYERS 5
#define RING_LED_COUNT 6
#define MACRO_QUEUE_CAP (56U * 5U + 1U)
#define MACOS_UNICODE_START_MS 10U

#define TX_QUEUE_CAP 256U
#define TX_PACKET_MAX 65U
#define TX_INPUT_MAX_AGE_MS 5000ULL
#define TX_CONTROL_MAX_AGE_MS 5000ULL
#define TX_RETRY_MS 1ULL
#define INPUT_READ_BUDGET 4U

enum { TX_KEYBOARD, TX_CONSUMER, TX_MOUSE, TX_SYSTEM, TX_OTHER, TX_PROTOCOL };
enum { MACRO_TX_NONE, MACRO_TX_DOWN, MACRO_TX_UP };
enum {
    HOST_OS_UNKNOWN = 0,
    HOST_OS_WINDOWS = 1,
    HOST_OS_APPLE = 2,
    HOST_OS_LINUX = 3,
    HOST_OS_ANDROID = 4
};
#define BUILTIN_TX_BASE 16U

enum sayo_key_mode {
    SAYO_KEY_DEFAULT = 0,
    SAYO_KEY_CHORD = 1,
    SAYO_KEY_MEDIA = 3,
    SAYO_KEY_SHORT_LONG = 4,
    SAYO_MEDIA_SHORT_LONG = 5,
    SAYO_KEY_PRESS_RELEASE = 6,
    SAYO_KEY_LED_LOCK = 7,
    SAYO_KEY_FOUR = 9,
    SAYO_KEY_LOOP = 10,
    SAYO_KEY_NUMLOCK = 11,
    SAYO_KEY_LATCH = 12,
    SAYO_KEY_SHORTCUT = 13
};

typedef struct {
    const uint8_t *code;
    size_t code_len, pc;
    uint32_t reg[21];
    uint64_t deadline_ms;
    uint32_t delay_ms;
    uint8_t modifiers, keys[4], mode, wait_for, led_toggle_mask;
    uint16_t consumer;
    bool active, pending;
    bool latch_released, latch_repressed;
} builtin_key_t;

typedef struct {
    uint8_t data[TX_PACKET_MAX];
    uint8_t len, kind, macro_action;
    uint64_t queued_ms;
    uint64_t save_generation;
} tx_record_t;

typedef struct {
    tx_record_t records[TX_QUEUE_CAP];
    size_t head, count;
    uint64_t retry_ms;
} tx_queue_t;

#define SAYO_VID 0x8089U
#define SAYO_PID 0x0009U
#define SAYO_MODEL_CODE 0x0004U
#define SAYO_FW_VER 0x2104U
#define SAYO_BATTERY_PCT 44U
#define SAYO_DEFAULT_NAME "Yandex SayoDevice Mini 2"

#define SAYO_CFG_MAGIC 0x53415938U
#ifndef SAYO_CFG_PATH
#define SAYO_CFG_PATH "/data/sayodevice_config.bin"
#endif
#ifndef SAYO_BT_CONF_PATH
#define SAYO_BT_CONF_PATH "/data/sayodevice_bt_main.conf"
#endif

static inline uint16_t u16_to_le(uint16_t v) {
#if defined(__BYTE_ORDER__) && (__BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
    return (uint16_t)((v >> 8) | (v << 8));
#else
    return v;
#endif
}

static inline uint16_t get_u16_le(const uint8_t *p) {
    return (uint16_t)((uint16_t)p[0] | ((uint16_t)p[1] << 8U));
}

static inline uint32_t get_u32_le(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8U) | ((uint32_t)p[2] << 16U) |
           ((uint32_t)p[3] << 24U);
}

static inline void put_u16_le(uint8_t *p, uint16_t v) {
    p[0] = (uint8_t)(v & 0xFFU);
    p[1] = (uint8_t)((v >> 8U) & 0xFFU);
}

static inline void put_u32_le(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)(v & 0xFFU);
    p[1] = (uint8_t)((v >> 8U) & 0xFFU);
    p[2] = (uint8_t)((v >> 16U) & 0xFFU);
    p[3] = (uint8_t)((v >> 24U) & 0xFFU);
}

static inline void put_u16_be(uint8_t *p, uint16_t v) {
    p[0] = (uint8_t)((v >> 8U) & 0xFFU);
    p[1] = (uint8_t)(v & 0xFFU);
}

#define HIDP_TRANS_HANDSHAKE 0x00U
#define HIDP_TRANS_HID_CONTROL 0x10U
#define HIDP_TRANS_GET_REPORT 0x40U
#define HIDP_TRANS_SET_REPORT 0x50U
#define HIDP_TRANS_GET_PROTOCOL 0x60U
#define HIDP_TRANS_SET_PROTOCOL 0x70U
#define HIDP_TRANS_GET_IDLE 0x80U
#define HIDP_TRANS_SET_IDLE 0x90U
#define HIDP_TRANS_DATA 0xA0U

#define HIDP_HSHK_SUCCESSFUL 0x00U
#define HIDP_HSHK_NOT_READY 0x01U
#define HIDP_HSHK_ERR_INVALID_REPORT 0x02U
#define HIDP_HSHK_ERR_UNSUPPORTED 0x03U
#define HIDP_HSHK_ERR_INVALID_PARAM 0x04U
#define HIDP_HSHK_ERR_UNKNOWN 0x0EU

#define HIDP_CTRL_NOP 0x00U
#define HIDP_CTRL_HARD_RESET 0x01U
#define HIDP_CTRL_SOFT_RESET 0x02U
#define HIDP_CTRL_SUSPEND 0x03U
#define HIDP_CTRL_EXIT_SUSPEND 0x04U
#define HIDP_CTRL_VIRTUAL_CABLE_UNPLUG 0x05U

#define HIDP_DATA_RTYPE_MASK 0x03U
#define HIDP_DATA_RTYPE_INPUT 0x01U
#define HIDP_DATA_RTYPE_OUTPUT 0x02U
#define HIDP_DATA_RTYPE_FEATURE 0x03U

#define BTN_BIT_MINUS (1U << 0)
#define BTN_BIT_CENTER (1U << 1)
#define BTN_BIT_PLUS (1U << 2)

static const uint16_t k_sayo_consumer_table[32] = {
    0x0000U, 0x006FU, 0x0070U, 0x0078U, 0x00D1U, 0x00D2U, 0x00D3U, 0x00D7U,
    0x00E2U, 0x00E5U, 0x00E9U, 0x00EAU, 0x00CDU, 0x00B7U, 0x00B6U, 0x00B5U,
    0x0152U, 0x0153U, 0x0154U, 0x0155U, 0x0183U, 0x018AU, 0x0192U, 0x0194U,
    0x0221U, 0x0223U, 0x0224U, 0x0225U, 0x0226U, 0x0227U, 0x022AU, 0x0000U};

static const uint8_t k_composite_hid_report_desc[] = {
    0x05U, 0x01U, 0x09U, 0x06U, 0xA1U, 0x01U, 0x85U, 0x01U, 0x05U, 0x07U, 0x19U, 0xE0U, 0x29U,
    0xE7U, 0x15U, 0x00U, 0x25U, 0x01U, 0x75U, 0x01U, 0x95U, 0x08U, 0x81U, 0x02U, 0x95U, 0x01U,
    0x75U, 0x08U, 0x81U, 0x01U, 0x95U, 0x05U, 0x75U, 0x01U, 0x05U, 0x08U, 0x19U, 0x01U, 0x29U,
    0x05U, 0x91U, 0x02U, 0x95U, 0x01U, 0x75U, 0x03U, 0x91U, 0x01U, 0x95U, 0x06U, 0x75U, 0x08U,
    0x15U, 0x00U, 0x26U, 0xFFU, 0x00U, 0x05U, 0x07U, 0x19U, 0x00U, 0x29U, 0xFFU, 0x81U, 0x00U,
    0xC0U,

    0x05U, 0x01U, 0x09U, 0x02U, 0xA1U, 0x01U, 0x85U, 0x03U, 0x09U, 0x01U, 0xA1U, 0x00U, 0x05U,
    0x09U, 0x19U, 0x01U, 0x29U, 0x05U, 0x15U, 0x00U, 0x25U, 0x01U, 0x95U, 0x05U, 0x75U, 0x01U,
    0x81U, 0x02U, 0x95U, 0x01U, 0x75U, 0x03U, 0x81U, 0x01U, 0x05U, 0x01U, 0x09U, 0x30U, 0x09U,
    0x31U, 0x09U, 0x38U, 0x15U, 0x81U, 0x25U, 0x7FU, 0x75U, 0x08U, 0x95U, 0x03U, 0x81U, 0x06U,
    0xC0U, 0xC0U,

    0x05U, 0x0CU, 0x09U, 0x01U, 0xA1U, 0x01U, 0x85U, 0x04U, 0x19U, 0x00U, 0x2AU, 0xFFU, 0x03U,
    0x15U, 0x00U, 0x26U, 0xFFU, 0x03U, 0x95U, 0x01U, 0x75U, 0x10U, 0x81U, 0x00U, 0xC0U,

    0x05U, 0x01U, 0x09U, 0x80U, 0xA1U, 0x01U, 0x85U, 0x05U, 0x19U, 0x81U, 0x29U, 0x83U, 0x15U,
    0x00U, 0x25U, 0x01U, 0x95U, 0x03U, 0x75U, 0x01U, 0x81U, 0x02U, 0x95U, 0x01U, 0x75U, 0x05U,
    0x81U, 0x01U, 0xC0U,

    0x06U, 0x00U, 0xFFU, 0x09U, 0x01U, 0xA1U, 0x01U, 0x85U, 0x02U, 0x15U, 0x00U, 0x26U, 0xFFU,
    0x00U, 0x75U, 0x08U, 0x95U, 0x3FU, 0x09U, 0x01U, 0x81U, 0x00U, 0x09U, 0x01U, 0x91U, 0x00U,
    0xC0U,

    0x06U, 0x11U, 0xFFU, 0x09U, 0x02U, 0xA1U, 0x01U, 0x85U, 0x21U, 0x15U, 0x00U, 0x26U, 0xFFU,
    0x00U, 0x75U, 0x08U, 0x95U, 0x3FU, 0x09U, 0x02U, 0x81U, 0x00U, 0x09U, 0x02U, 0x91U, 0x00U,
    0xC0U};

static volatile sig_atomic_t g_stop = 0;

static void handle_signal(int sig) {
    (void)sig;
    g_stop = 1;
}

static void write_sysfs_str(const char *path, const char *val) {
    int fd = open(path, O_WRONLY | O_CLOEXEC);
    if (fd < 0) return;
    (void)write(fd, val, strlen(val));
    (void)close(fd);
}

static void optimize_realtime_priority(bool verbose) {
    static const char *const k_aw96103_init[] = {
        "0x0010 0x040560fd\n", "0x0024 0x0405f0f7\n", "0x0038 0x040560df\n",
        "0x00a4 0x00000000\n", "0x00e0 0x00000000\n", "0x011c 0x00000000\n",
        "0x00a8 0x0204a8ca\n", "0x00e4 0x0204a8ca\n", "0x0120 0x0204a8ca\n",
        "0x00b0 0x00000000\n", "0x00ec 0x00000000\n", "0x0128 0x00000000\n",
        "0x00b8 0x0000ea60\n", "0x00f4 0x000186a0\n", "0x0130 0x0000ea60\n"};
    write_sysfs_str("/proc/sys/debug/exception-trace", "0\n");
    write_sysfs_str("/proc/sys/kernel/printk", "1 4 1 7\n");
    for (size_t i = 0U; i < sizeof(k_aw96103_init) / sizeof(k_aw96103_init[0]); ++i)
        write_sysfs_str("/sys/bus/i2c/devices/1-0012/reg", k_aw96103_init[i]);
    write_sysfs_str("/sys/bus/i2c/devices/1-0012/aot_cali", "1\n");
    if (mlockall(MCL_CURRENT | MCL_FUTURE) == 0 && verbose) printf("[RT] mlockall OK\n");
    if (setpriority(PRIO_PROCESS, 0U, -5) == 0 && verbose)
        printf("[RT] nice=-5 (normal scheduler)\n");
}

static int daemonize_process(const char *log_path, const char *pid_path) {
    int log_fd = -1;
    if (log_path != NULL && *log_path != '\0') {
        log_fd = open(log_path, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0644);
        if (log_fd < 0) {
            perror("open(log_path)");
            return -1;
        }
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        if (log_fd >= 0) (void)close(log_fd);
        return -1;
    }
    if (pid > 0) _exit(0);

    (void)setsid();

    int null_fd = open("/dev/null", O_RDWR);
    if (null_fd >= 0) {
        (void)dup2(null_fd, STDIN_FILENO);
        if (log_fd < 0) {
            (void)dup2(null_fd, STDOUT_FILENO);
            (void)dup2(null_fd, STDERR_FILENO);
        }
        if (null_fd > STDERR_FILENO) (void)close(null_fd);
    }

    if (log_fd >= 0) {
        (void)dup2(log_fd, STDOUT_FILENO);
        (void)dup2(log_fd, STDERR_FILENO);
        if (log_fd > STDERR_FILENO) (void)close(log_fd);
    }

    if (pid_path != NULL && *pid_path != '\0') {
        int pfd = open(pid_path, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0644);
        if (pfd >= 0) {
            char pbuf[32];
            int plen = snprintf(pbuf, sizeof(pbuf), "%ld\n", (long)getpid());
            if (plen > 0) (void)write(pfd, pbuf, (size_t)plen);
            (void)close(pfd);
        }
    }

    return 0;
}

static void set_hci0_scan(uint32_t dev_opt) {
    int hci_fd = socket(PF_BLUETOOTH, SOCK_RAW | SOCK_CLOEXEC, BTPROTO_HCI);
    if (hci_fd < 0) return;
    (void)ioctl(hci_fd, HCIDEVUP, 0);
    struct local_hci_dev_req dr = {.dev_id = 0U, .dev_opt = dev_opt};
    (void)ioctl(hci_fd, HCISETSCAN, &dr);
    (void)close(hci_fd);
}

static void ensure_hci0_piscan(void) {
    set_hci0_scan(HCI_SCAN_PAGE | HCI_SCAN_INQUIRY);
}

typedef struct {
    int fd_r[RING_LED_COUNT];
    int fd_g[RING_LED_COUNT];
    int fd_b[RING_LED_COUNT];
    uint8_t saved_r[RING_LED_COUNT];
    uint8_t saved_g[RING_LED_COUNT];
    uint8_t saved_b[RING_LED_COUNT];
    uint8_t cur_r[RING_LED_COUNT];
    uint8_t cur_g[RING_LED_COUNT];
    uint8_t cur_b[RING_LED_COUNT];
    uint32_t anim_step;
    uint32_t effect_phase;
    bool dirty;
} led_ring_t;

static int open_and_save_led_channel(const char *path, uint8_t *saved_val, uint8_t *cur_val) {
    *saved_val = *cur_val = 0U;
    int rfd = open(path, O_RDONLY | O_CLOEXEC);
    if (rfd >= 0) {
        char rbuf[32];
        ssize_t n = pread(rfd, rbuf, sizeof(rbuf) - 1U, 0);
        if (n < 0) n = read(rfd, rbuf, sizeof(rbuf) - 1U);
        if (n > 0) {
            rbuf[(size_t)n] = '\0';
            char *endptr = NULL;
            errno = 0;
            long val = strtol(rbuf, &endptr, 10);
            if (errno == 0 && endptr != rbuf) {
                if (val < 0L) val = 0L;
                if (val > 255L) val = 255L;
                *saved_val = *cur_val = (uint8_t)val;
            }
        }
        (void)close(rfd);
    }
    return open(path, O_WRONLY | O_CLOEXEC);
}

static void write_led_fd(int fd, uint8_t *cache, uint8_t val, bool force) {
    if (fd < 0 || (!force && *cache == val)) return;
    char buf[8];
    int len = snprintf(buf, sizeof(buf), "%u\n", (unsigned int)val);
    if (len <= 0 || (size_t)len >= sizeof(buf)) return;
    if (pwrite(fd, buf, (size_t)len, 0) < 0) {
        (void)lseek(fd, 0, SEEK_SET);
        (void)write(fd, buf, (size_t)len);
    }
    *cache = val;
}

static void led_ring_init(led_ring_t *ring) {
    memset(ring, 0, sizeof(*ring));
    for (int i = 0; i < RING_LED_COUNT; ++i) {
        char path[128];
        (void)snprintf(path, sizeof(path), "/sys/class/leds/mini2:red:ring%d/brightness", i + 1);
        ring->fd_r[i] = open_and_save_led_channel(path, &ring->saved_r[i], &ring->cur_r[i]);
        (void)snprintf(path, sizeof(path), "/sys/class/leds/mini2:green:ring%d/brightness", i + 1);
        ring->fd_g[i] = open_and_save_led_channel(path, &ring->saved_g[i], &ring->cur_g[i]);
        (void)snprintf(path, sizeof(path), "/sys/class/leds/mini2:blue:ring%d/brightness", i + 1);
        ring->fd_b[i] = open_and_save_led_channel(path, &ring->saved_b[i], &ring->cur_b[i]);
    }
}

static void led_ring_log_saved(const led_ring_t *ring) {
    for (int i = 0; i < RING_LED_COUNT; ++i) {
        printf("[LED Save] ring%d: R=%u G=%u B=%u\n", i + 1, (unsigned int)ring->saved_r[i],
               (unsigned int)ring->saved_g[i], (unsigned int)ring->saved_b[i]);
    }
}

static void led_ring_restore_saved(led_ring_t *ring) {
    for (int i = 0; i < RING_LED_COUNT; ++i) {
        write_led_fd(ring->fd_r[i], &ring->cur_r[i], ring->saved_r[i], true);
        write_led_fd(ring->fd_g[i], &ring->cur_g[i], ring->saved_g[i], true);
        write_led_fd(ring->fd_b[i], &ring->cur_b[i], ring->saved_b[i], true);
    }
}

static void led_ring_off(led_ring_t *ring) {
    for (int i = 0; i < RING_LED_COUNT; ++i) {
        write_led_fd(ring->fd_r[i], &ring->cur_r[i], 0U, true);
        write_led_fd(ring->fd_g[i], &ring->cur_g[i], 0U, true);
        write_led_fd(ring->fd_b[i], &ring->cur_b[i], 0U, true);
    }
}

static void led_ring_step_searching_blue(led_ring_t *ring) {
    static const uint8_t k_tail[RING_LED_COUNT] = {255U, 95U, 25U, 0U, 0U, 0U};
    uint32_t head = ring->anim_step % (uint32_t)RING_LED_COUNT;
    for (uint32_t i = 0U; i < (uint32_t)RING_LED_COUNT; ++i) {
        uint32_t dist = (head + (uint32_t)RING_LED_COUNT - i) % (uint32_t)RING_LED_COUNT;
        write_led_fd(ring->fd_r[i], &ring->cur_r[i], 0U, false);
        write_led_fd(ring->fd_g[i], &ring->cur_g[i], 0U, false);
        write_led_fd(ring->fd_b[i], &ring->cur_b[i], k_tail[dist], false);
    }
    ring->anim_step = (ring->anim_step + 1U) % (uint32_t)RING_LED_COUNT;
}

static void close_fd_if_open(int *fd) {
    if (*fd >= 0) {
        (void)close(*fd);
        *fd = -1;
    }
}

static void led_ring_restore_and_close(led_ring_t *ring, bool force_zero_on_exit) {
    if (force_zero_on_exit)
        led_ring_off(ring);
    else
        led_ring_restore_saved(ring);
    for (int i = 0; i < RING_LED_COUNT; ++i) {
        close_fd_if_open(&ring->fd_r[i]);
        close_fd_if_open(&ring->fd_g[i]);
        close_fd_if_open(&ring->fd_b[i]);
    }
}

typedef struct {
    uint32_t magic;
    uint8_t cli_usages[SAYO_KEY_COUNT];
    uint8_t key_fn;
    uint8_t cfg_selection;
    uint8_t active_mode;
    uint8_t device_locked;
    uint8_t dev_name_enc;
    uint8_t dev_name_utf16[48];
    uint8_t opt_bytes[40];
    uint8_t rf_cfg[16];
    uint8_t key_info[SAYO_KEY_COUNT][56];
    uint8_t led_info[SAYO_KEY_COUNT][56];
    uint8_t palette[SAYO_KEY_COUNT][32];
    uint8_t touch_sens[SAYO_KEY_COUNT][8];
    uint8_t password_enc[4];
    uint8_t passwords[4][56];
    uint8_t string_enc[8];
    uint8_t strings[8][56];
    uint8_t script_name_enc[8];
    uint8_t script_names[8][56];
    uint8_t script_mem[512];
    uint8_t adv_key[SAYO_KEY_COUNT][44];
    uint8_t led_effect[48];
    uint8_t led_status[SAYO_KEY_COUNT];
    uint8_t gamepad_cfg[48];
    uint8_t ambient_led[28];
    uint8_t cmd1f_data[16][32];
} sayo_persistent_cfg_t;

typedef struct {
    uint8_t mod, usage, release_mod;
    uint16_t down_ms, up_ms;
    uint8_t caps_invert;
} text_keystroke_t;

typedef struct {
    uint8_t usage_minus;
    uint8_t usage_center;
    uint8_t usage_plus;

    bool pressed_minus;
    bool pressed_center;
    bool pressed_plus;
    uint8_t tgl_latch_mask;
    bool leds_master_off;

    uint64_t key_press_ms[SAYO_KEY_COUNT];
    uint64_t key_release_ms[SAYO_KEY_COUNT];
    uint32_t key_color_step[SAYO_KEY_COUNT];
    builtin_key_t builtin_keys[SAYO_KEY_COUNT];

    text_keystroke_t macro_q[MACRO_QUEUE_CAP];
    size_t macro_q_head;
    size_t macro_q_tail;
    bool macro_key_down;
    bool macro_tx_pending;
    uint16_t macro_step_ms;
    uint8_t macro_held_mod;
    uint8_t macro_wait_key;
    uint8_t macro_enqueued_leds;
    bool text_macos_hex;
    uint64_t last_macro_ms;

    bool report_dirty;
    bool tx_fault;
    bool protocol_barrier;
    tx_queue_t tx_input, tx_control, tx_vendor;
    uint16_t queued_consumer_usage;
    uint8_t queued_mouse_btns, queued_sysctrl_bits;
    uint64_t tx_retries, telemetry_dropped, input_overruns;
    uint64_t max_input_age_ms, max_loop_gap_ms;
    size_t tx_high_water;
    bool save_pending;
    pid_t save_pid;
    uint64_t save_requested, save_running, save_completed, save_reply_generation;
    uint64_t last_tx_ms;
    uint64_t last_input_edge_ms;
    uint8_t last_kb_pkt[10];
    uint8_t last_kb_len;

    uint8_t protocol_mode;
    uint8_t idle_rate;
    uint8_t host_leds;
    uint8_t peer_os;
    bool has_peer_addr;
    bdaddr_t local_addr, peer_addr;

    uint16_t active_consumer_usage;
    uint8_t active_mouse_btns;
    uint8_t active_sysctrl_bits;

    uint8_t enum_last_cmd;
    uint8_t enum_next_idx;

    uint8_t last_v1_resp[64];
    uint8_t last_v21_resp[64];

    sayo_persistent_cfg_t cfg;
    sayo_persistent_cfg_t save_snapshot;
} keypad_state_t;

typedef struct {
    int fd;
    bool grabbed;
    int pad_role;
    bool desynchronized;
    bool monotonic_clock;
    uint32_t buttons;
    uint8_t key_bits[(KEY_MAX / 8U) + 1U];
    char path[128];
    char name[128];
} input_slot_t;

typedef struct {
    input_slot_t slots[MAX_INPUT_DEVS];
    size_t count;
    bool auto_scan;
} input_set_t;

static uint64_t monotonic_ms(void) {
#if defined(__linux__) && defined(__arm__) && !defined(clock_gettime)
    int32_t ts32[2];
    register long r7 __asm__("r7") = 263;
    register long r0 __asm__("r0") = CLOCK_MONOTONIC;
    register long r1 __asm__("r1") = (long)ts32;
    __asm__ __volatile__("svc 0" : "+r"(r0) : "r"(r1), "r"(r7) : "memory", "cc");
    if (r0 != 0 || ts32[0] < 0) return 0ULL;
    return (uint64_t)(uint32_t)ts32[0] * 1000ULL + (uint64_t)(uint32_t)ts32[1] / 1000000ULL;
#else
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0 || ts.tv_sec < 0) return 0ULL;
    return (uint64_t)ts.tv_sec * 1000ULL + (uint64_t)ts.tv_nsec / 1000000ULL;
#endif
}

static void set_utf16le_from_ascii(uint8_t out_utf16[48], const char *ascii) {
    memset(out_utf16, 0, 48U);
    if (ascii == NULL) return;
    for (size_t i = 0U; i < 24U && ascii[i] != '\0'; ++i) {
        out_utf16[i * 2U] = (uint8_t)ascii[i];
        out_utf16[i * 2U + 1U] = 0U;
    }
}

static void init_string_content_ascii(uint8_t out_sc[56], const char *ascii) {
    memset(out_sc, 0, 56U);
    if (ascii == NULL || *ascii == '\0') return;
    size_t len = strlen(ascii);
    if (len > 54U) len = 54U;
    memcpy(out_sc, ascii, len);
}

static void normalize_sayo_geometry_headers(sayo_persistent_cfg_t *cfg) {
    for (uint8_t i = 0U; i < SAYO_KEY_COUNT; ++i) {
        uint8_t *ki = cfg->key_info[i];
        memset(ki, 0, 16U);
        ki[0] = 1U;
        put_u16_le(&ki[4], (uint16_t)(1000U + (uint16_t)i * 2000U));
        put_u16_le(&ki[6], 3000U);
        put_u16_le(&ki[8], 1800U);
        put_u16_le(&ki[10], 1800U);
        put_u16_le(&ki[12], 100U);
        memcpy(cfg->led_info[i], ki, 16U);
    }
}

static void sync_legacy_usages_from_cfg(keypad_state_t *st) {
    uint8_t fn = st->cfg.key_fn;
    if (fn >= SAYO_FN_LAYERS) fn = 0U;
    size_t off = 16U + (size_t)fn * 8U;
    st->usage_minus = st->cfg.key_info[0][off + 5U];
    st->usage_center = st->cfg.key_info[1][off + 5U];
    st->usage_plus = st->cfg.key_info[2][off + 5U];
}

static void init_default_sayo_cfg(keypad_state_t *st) {
    static const uint8_t k_opt_defaults[38] = {
        0x00, 0x00, 0x00, 0x00, 0x0F, 0xFF, 0x00, 0x00, 0x02, 0x32, 0x00, 0x00, 0x0F,
        0xFF, 0x00, 0xFF, 0x00, 0x04, 0x00, 0x0F, 0x00, 0xFF, 0x01, 0x07, 0x02, 0x00,
        0x32, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0xFF, 0x00, 0xFF};
    static const uint8_t k_rf_defaults[16] = {0xC0, 0x1E, 0x31, 0x9D, 0x02, 0x07, 0x00, 0x50,
                                              0x01, 0x0A, 0x00, 0xFF, 0x00, 0xFF, 0x1E, 0xFF};
    static const uint8_t k_default_palette[9][3] = {
        {0U, 255U, 0U},   {0U, 180U, 255U}, {255U, 0U, 128U},   {255U, 180U, 0U}, {160U, 0U, 255U},
        {255U, 40U, 40U}, {0U, 255U, 180U}, {255U, 255U, 255U}, {40U, 80U, 255U}};
    static const uint8_t k_led_eff_defaults[48] = {
        0,   180, 255, 1,   1,   0,   5,   100, 0,   255, 0,   255, 0,   180, 255, 255,
        255, 0,   128, 255, 255, 180, 0,   255, 255, 255, 255, 0,   255, 0,   0,   0,
        0,   0,   255, 0,   0,   255, 255, 0,   255, 0,   255, 0,   255, 255, 0,   255};
    static const uint8_t k_amb_defaults[26] = {100, 5, 6, 0, 1, 0, 180, 255, 0, 0, 0, 0, 0,
                                               0,   0, 0, 0, 0, 0, 0,   0,   1, 2, 3, 4, 5};
    static const uint8_t initial_usages[SAYO_KEY_COUNT] = {0x1DU, 0x1BU, 0x06U};

    memset(&st->cfg, 0, sizeof(st->cfg));
    st->cfg.magic = SAYO_CFG_MAGIC;
    memcpy(st->cfg.cli_usages, initial_usages, sizeof(initial_usages));
    st->cfg.cfg_selection = 1U;
    st->text_macos_hex = false;

    const char *bt_name = getenv("SAYODEVICE_DEV_NAME");
    if (bt_name == NULL || *bt_name == '\0') bt_name = SAYO_DEFAULT_NAME;
    st->cfg.dev_name_enc = 3U;
    set_utf16le_from_ascii(st->cfg.dev_name_utf16, bt_name);

    memcpy(st->cfg.opt_bytes, k_opt_defaults, sizeof(k_opt_defaults));
    memcpy(st->cfg.rf_cfg, k_rf_defaults, sizeof(k_rf_defaults));
    normalize_sayo_geometry_headers(&st->cfg);

    for (uint8_t i = 0U; i < SAYO_KEY_COUNT; ++i) {
        for (uint8_t fn = 0U; fn < SAYO_FN_LAYERS; ++fn) {
            uint8_t *kd = &st->cfg.key_info[i][16U + (size_t)fn * 8U];
            kd[0] = 1U;
            kd[4] = (initial_usages[i] >= 0xE0U && initial_usages[i] <= 0xE7U)
                        ? (uint8_t)(1U << (initial_usages[i] - 0xE0U))
                        : 0U;
            kd[5] = initial_usages[i];

            uint8_t *ld = &st->cfg.led_info[i][16U + (size_t)fn * 8U];
            ld[0] = 0x80U;
            ld[2] = 4U;
            ld[3] = 4U;
            ld[4] = k_default_palette[i][0];
            ld[5] = k_default_palette[i][1];
            ld[6] = k_default_palette[i][2];
            ld[7] = i;
        }
        uint8_t *pal = st->cfg.palette[i];
        pal[0] = 8U;
        for (size_t c = 0U; c < 8U; ++c) memcpy(&pal[2U + c * 3U], k_default_palette[c], 3U);
        put_u16_le(&st->cfg.touch_sens[i][0], 80U);
        put_u16_le(&st->cfg.touch_sens[i][2], 500U);
        put_u16_le(&st->cfg.touch_sens[i][4], 100U);
        put_u16_le(&st->cfg.touch_sens[i][6], 100U);
        st->cfg.led_status[i] = 1U;
    }

    for (uint8_t i = 0U; i < 4U; ++i) st->cfg.password_enc[i] = 2U;
    for (uint8_t i = 0U; i < 8U; ++i) {
        st->cfg.string_enc[i] = 3U;
        st->cfg.script_name_enc[i] = 2U;
        char sname[16];
        (void)snprintf(sname, sizeof(sname), "Macro %u", (unsigned int)(i + 1U));
        init_string_content_ascii(st->cfg.script_names[i], sname);
    }

    memcpy(st->cfg.led_effect, k_led_eff_defaults, sizeof(k_led_eff_defaults));
    memcpy(st->cfg.ambient_led, k_amb_defaults, sizeof(k_amb_defaults));
    sync_legacy_usages_from_cfg(st);
}

static bool load_sayo_cfg_from_disk(keypad_state_t *st) {
    int fd = open(SAYO_CFG_PATH, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return false;
    sayo_persistent_cfg_t tmp;
    ssize_t n = read(fd, &tmp, sizeof(tmp));
    (void)close(fd);
    if (n != (ssize_t)sizeof(tmp) || tmp.magic != SAYO_CFG_MAGIC) return false;
    memcpy(&st->cfg, &tmp, sizeof(tmp));
    st->cfg.active_mode = 0U;
    st->cfg.opt_bytes[17] = 0x04U;
    st->text_macos_hex = (st->cfg.opt_bytes[16] == 4U);
    normalize_sayo_geometry_headers(&st->cfg);
    if (st->cfg.cfg_selection == 0U || st->cfg.cfg_selection > 5U) st->cfg.cfg_selection = 1U;
    sync_legacy_usages_from_cfg(st);
    return true;
}

static bool write_sayo_cfg_snapshot(const sayo_persistent_cfg_t *cfg) {
    char temporary[128];
    int length = snprintf(temporary, sizeof(temporary), "%s.tmp.XXXXXX", SAYO_CFG_PATH);
    if (length < 0 || (size_t)length >= sizeof(temporary)) return false;
    int fd = mkstemp(temporary);
    if (fd < 0) return false;
    (void)fcntl(fd, F_SETFD, FD_CLOEXEC);
    size_t offset = 0U;
    while (offset < sizeof(*cfg)) {
        ssize_t n = write(fd, (const uint8_t *)cfg + offset, sizeof(*cfg) - offset);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) break;
        offset += (size_t)n;
    }
    bool ok = offset == sizeof(*cfg) && fsync(fd) == 0;
    if (close(fd) != 0) ok = false;
    if (ok && rename(temporary, SAYO_CFG_PATH) == 0) {
        char parent[128];
        (void)snprintf(parent, sizeof(parent), "%s", SAYO_CFG_PATH);
        char *slash = strrchr(parent, '/');
        if (slash == parent)
            slash[1] = '\0';
        else if (slash != NULL)
            *slash = '\0';
        else
            (void)snprintf(parent, sizeof(parent), ".");
        int dir = open(parent, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
        bool durable = dir >= 0 && fsync(dir) == 0;
        if (dir >= 0) (void)close(dir);
        return durable;
    }
    (void)unlink(temporary);
    return false;
}

static bool save_sayo_cfg_to_disk(keypad_state_t *st) {
    st->save_pending = true;
    st->save_snapshot = st->cfg;
    st->save_snapshot.active_mode = 0U;
    st->save_reply_generation = ++st->save_requested;
    return true;
}

static void service_config_save(keypad_state_t *st) {
    if (st->save_pid > 0) {
        int status = 0;
        pid_t result = waitpid(st->save_pid, &status, WNOHANG);
        if (result == 0 || (result < 0 && errno == EINTR)) return;
        if (result > 0 && WIFEXITED(status) && WEXITSTATUS(status) == 0) {
            st->save_completed = st->save_running;
        } else {
            fprintf(stderr, "[Config] Save could not be confirmed\n");
            st->tx_fault = true;
        }
        st->save_pid = 0;
    }
    if (!st->save_pending || st->tx_input.count != 0U) return;
    pid_t child = fork();
    if (child < 0) return;
    if (child == 0) {
        (void)signal(SIGINT, SIG_DFL);
        (void)signal(SIGTERM, SIG_DFL);
        (void)signal(SIGQUIT, SIG_DFL);
        (void)setpriority(PRIO_PROCESS, 0U, 10);
        long max_fd = sysconf(_SC_OPEN_MAX);
        int lim = (max_fd > 0 && max_fd < 4096) ? (int)max_fd : 1024;
        for (int fd = 3; fd < lim; ++fd) (void)close(fd);
        _exit(write_sayo_cfg_snapshot(&st->save_snapshot) ? 0 : 1);
    }
    st->save_pid = child;
    st->save_running = st->save_requested;
    st->save_pending = false;
}

static void hsv_wheel_rgb(uint8_t pos, uint8_t *out_r, uint8_t *out_g, uint8_t *out_b) {
    if (pos < 85U) {
        *out_r = (uint8_t)(255U - pos * 3U);
        *out_g = (uint8_t)(pos * 3U);
        *out_b = 0U;
    } else if (pos < 170U) {
        uint8_t p = (uint8_t)(pos - 85U);
        *out_r = 0U;
        *out_g = (uint8_t)(255U - p * 3U);
        *out_b = (uint8_t)(p * 3U);
    } else {
        uint8_t p = (uint8_t)(pos - 170U);
        *out_r = (uint8_t)(p * 3U);
        *out_g = 0U;
        *out_b = (uint8_t)(255U - p * 3U);
    }
}

static uint8_t triangle_wave_u8(uint32_t phase) {
    uint32_t p = phase & 0xFFU;
    if (p < 128U) return (uint8_t)(p * 2U);
    return (uint8_t)((255U - p) * 2U);
}

static void compute_effective_button_states(const keypad_state_t *st,
                                            bool out_pressed[SAYO_KEY_COUNT]);

static uint8_t resolve_effective_fn_layer(const keypad_state_t *st) {
    uint8_t base_fn = st->cfg.key_fn;
    if (base_fn >= SAYO_FN_LAYERS) base_fn = 0U;
    size_t off = 16U + (size_t)base_fn * 8U;
    bool pressed[SAYO_KEY_COUNT] = {st->pressed_minus, st->pressed_center, st->pressed_plus};
    for (uint8_t i = 0U; i < SAYO_KEY_COUNT; ++i) {
        if (!pressed[i]) continue;
        const uint8_t *kd = &st->cfg.key_info[i][off];
        if (kd[0] == 128U || (kd[0] == 7U && kd[3] == 0U && kd[6] == 0U && kd[7] == 0U &&
                              kd[4] > 0U && kd[4] < SAYO_FN_LAYERS)) {
            uint8_t target = (kd[0] == 128U) ? kd[4] : ((kd[5] != 0U) ? kd[5] : kd[4]);
            if (target < SAYO_FN_LAYERS) return target;
        }
    }
    return base_fn;
}

static bool sayo_leds_need_animation(const keypad_state_t *st) {
    if (st->leds_master_off || st->cfg.led_effect[7] == 0U) return false;
    if (st->cfg.led_effect[3] != 0U) {
        uint8_t g_mode = st->cfg.led_effect[4];
        if (g_mode <= 4U) return true;
        if (g_mode == 5U && st->cfg.led_effect[5] == 3U) return true;
        return false;
    }
    uint8_t fn = resolve_effective_fn_layer(st);
    size_t off = 16U + (size_t)fn * 8U;
    for (uint8_t k = 0U; k < SAYO_KEY_COUNT; ++k) {
        const uint8_t *ld = &st->cfg.led_info[k][off];
        uint8_t led_mode = (uint8_t)(ld[0] & 0x0FU);
        uint8_t color_mode = (uint8_t)((ld[0] >> 4U) & 0x03U);
        uint8_t event_mode = ld[1];
        if (led_mode >= 2U || color_mode >= 1U || event_mode != 0U) return true;
    }
    return false;
}

static void pick_per_key_color(const keypad_state_t *st, const led_ring_t *ring, uint8_t k,
                               const uint8_t *ld, uint32_t spd_mul, uint8_t *out_r, uint8_t *out_g,
                               uint8_t *out_b) {
    uint8_t led_mode = (uint8_t)(ld[0] & 0x0FU);
    uint8_t color_mode = (uint8_t)((ld[0] >> 4U) & 0x03U);
    uint8_t event_mode = ld[1];
    uint8_t pal_idx = ld[7];
    const uint8_t *pal = st->cfg.palette[k];
    uint8_t num_colors = (pal[0] == 0U || pal[0] > 9U) ? 8U : pal[0];
    bool step_only = (led_mode == 7U || event_mode == 5U || event_mode == 6U);

    if (color_mode >= 3U) {
        uint8_t wheel_pos = (uint8_t)((ring->effect_phase * spd_mul * 2U +
                                       st->key_color_step[k] * 43U + (uint32_t)k * 85U) &
                                      0xFFU);
        hsv_wheel_rgb(wheel_pos, out_r, out_g, out_b);
        return;
    }

    uint32_t cyc = 0U;
    if (color_mode == 0U) {
        if (led_mode == 6U) {
            cyc = (ring->effect_phase * spd_mul) / 24U + k;
        } else if (step_only) {
            cyc = pal_idx + st->key_color_step[k];
        } else {
            *out_r = ld[4];
            *out_g = ld[5];
            *out_b = ld[6];
            return;
        }
    } else if (color_mode == 1U) {
        cyc = pal_idx + st->key_color_step[k] + (step_only ? 0U : (ring->effect_phase * spd_mul) / 20U);
    } else {
        cyc = st->key_color_step[k] * 7U + (uint32_t)k * 3U +
              (step_only ? pal_idx : ((ring->effect_phase * spd_mul) / 20U) * 5U);
    }

    size_t poff = 2U + (size_t)(cyc % num_colors) * 3U;
    *out_r = pal[poff];
    *out_g = pal[poff + 1U];
    *out_b = pal[poff + 2U];
}

static void mark_leds_dirty(led_ring_t *ring) {
    if (ring != NULL) ring->dirty = true;
}

static void render_global_leds(const keypad_state_t *st, const led_ring_t *ring, uint64_t now_ms,
                               uint8_t fn, size_t off, const bool raw_pressed[SAYO_KEY_COUNT],
                               const bool eff_pressed[SAYO_KEY_COUNT],
                               uint8_t out_r[RING_LED_COUNT], uint8_t out_g[RING_LED_COUNT],
                               uint8_t out_b[RING_LED_COUNT]) {
    uint8_t global_mode = st->cfg.led_effect[4];
    uint8_t global_sub = st->cfg.led_effect[5];
    uint8_t global_speed = st->cfg.led_effect[6];
    uint8_t base_r = st->cfg.led_effect[0], base_g = st->cfg.led_effect[1],
            base_b = st->cfg.led_effect[2];
    if (base_r == 0U && base_g == 0U && base_b == 0U) {
        uint8_t prof_idx = (st->cfg.cfg_selection >= 1U && st->cfg.cfg_selection <= 4U)
                               ? (uint8_t)(st->cfg.cfg_selection - 1U)
                               : 0U;
        base_r = st->cfg.led_effect[8U + prof_idx * 4U];
        base_g = st->cfg.led_effect[8U + prof_idx * 4U + 1U];
        base_b = st->cfg.led_effect[8U + prof_idx * 4U + 2U];
        if (base_r == 0U && base_g == 0U && base_b == 0U) {
            base_g = 180U;
            base_b = 255U;
        }
    }

    uint32_t ph = ring->effect_phase * (((uint32_t)global_speed / 12U) + 1U);
    for (int i = 0; i < RING_LED_COUNT; ++i) {
        uint8_t k = (uint8_t)(i / 2);
        if (st->cfg.led_status[k] == 0U) continue;
        uint8_t r = base_r, g = base_g, b = base_b;

        if (global_mode == 0U) {
            if (global_sub <= 1U) {
                bool with_bg = (global_sub == 0U);
                uint8_t wave = triangle_wave_u8(ph * 3U + (uint32_t)i * 42U);
                uint8_t bg_r = with_bg ? (uint8_t)(base_r / 5U) : 0U;
                uint8_t bg_g = with_bg ? (uint8_t)(base_g / 5U) : 0U;
                uint8_t bg_b = with_bg ? (uint8_t)(base_b / 5U) : 0U;
                r = (uint8_t)(bg_r + (((uint32_t)(base_r - bg_r) * wave) / 255U));
                g = (uint8_t)(bg_g + (((uint32_t)(base_g - bg_g) * wave) / 255U));
                b = (uint8_t)(bg_b + (((uint32_t)(base_b - bg_b) * wave) / 255U));
            } else if (global_sub <= 3U) {
                uint8_t blade = triangle_wave_u8(ph * 4U + (uint32_t)(i % 3) * 85U);
                uint8_t wr = 0U, wg = 0U, wb = 0U;
                if (global_sub == 2U) {
                    hsv_wheel_rgb((uint8_t)((ph + (uint32_t)i * 42U) & 0xFFU), &wr, &wg, &wb);
                    wr /= 4U;
                    wg /= 4U;
                    wb /= 4U;
                }
                r = (uint8_t)(wr + (((uint32_t)(base_r > wr ? (base_r - wr) : 0U) * blade) / 255U));
                g = (uint8_t)(wg + (((uint32_t)(base_g > wg ? (base_g - wg) : 0U) * blade) / 255U));
                b = (uint8_t)(wb + (((uint32_t)(base_b > wb ? (base_b - wb) : 0U) * blade) / 255U));
            } else if (global_sub <= 5U) {
                static const uint8_t k_spiral_tail[6] = {255U, 150U, 65U, 20U, 0U, 0U};
                uint32_t head = (ph / 6U) % (uint32_t)RING_LED_COUNT;
                uint32_t dist =
                    (head + (uint32_t)RING_LED_COUNT - (uint32_t)i) % (uint32_t)RING_LED_COUNT;
                uint8_t bg_scale = (global_sub == 4U) ? 45U : 0U;
                uint8_t lvl = (k_spiral_tail[dist] > bg_scale) ? k_spiral_tail[dist] : bg_scale;
                r = (uint8_t)(((uint32_t)base_r * lvl) / 255U);
                g = (uint8_t)(((uint32_t)base_g * lvl) / 255U);
                b = (uint8_t)(((uint32_t)base_b * lvl) / 255U);
            } else if (global_sub == 6U) {
                uint8_t swing = triangle_wave_u8(ph * 2U);
                hsv_wheel_rgb((uint8_t)(((uint32_t)swing / 2U + (uint32_t)i * 28U) & 0xFFU), &r, &g,
                              &b);
            } else if (global_sub == 7U) {
                hsv_wheel_rgb((uint8_t)((ph * 2U + (uint32_t)i * 42U) & 0xFFU), &r, &g, &b);
            } else {
                hsv_wheel_rgb((uint8_t)((256U - ((ph * 3U) & 0xFFU) + (uint32_t)i * 85U) & 0xFFU),
                              &r, &g, &b);
            }
        } else if (global_mode == 1U) {
            uint32_t step_dir =
                (global_sub & 1U) ? (256U - ((ph * 2U) & 0xFFU)) : ((ph * 2U) & 0xFFU);
            uint32_t spread = 24U + (uint32_t)(global_sub % 5U) * 14U;
            hsv_wheel_rgb((uint8_t)((step_dir + (uint32_t)i * spread) & 0xFFU), &r, &g, &b);
        } else if (global_mode == 2U) {
            uint8_t tr = base_r, tg = base_g, tb = base_b;
            if (st->cfg.led_effect[47] != 0U &&
                (st->cfg.led_effect[44] | st->cfg.led_effect[45] | st->cfg.led_effect[46]) != 0U) {
                tr = st->cfg.led_effect[44];
                tg = st->cfg.led_effect[45];
                tb = st->cfg.led_effect[46];
            }
            if (global_sub >= 6U)
                hsv_wheel_rgb((uint8_t)((ph * 2U + (uint32_t)i * 42U) & 0xFFU), &tr, &tg, &tb);
            uint32_t fade_dur = (uint32_t)(900U - (global_speed > 80U ? 80U : global_speed) * 8U);
            if (fade_dur < 120U) fade_dur = 120U;
            uint8_t lvl = 0U;
            if (raw_pressed[k]) {
                lvl = 255U;
            } else if (st->key_release_ms[k] > 0ULL && now_ms >= st->key_release_ms[k]) {
                uint64_t dt = now_ms - st->key_release_ms[k];
                if (dt < (uint64_t)fade_dur)
                    lvl = (uint8_t)(255ULL - (dt * 255ULL) / (uint64_t)fade_dur);
            }
            if (global_sub == 2U || global_sub == 3U || global_sub == 8U || global_sub == 9U) {
                for (uint8_t ok = 0U; ok < SAYO_KEY_COUNT; ++ok) {
                    if (ok == k) continue;
                    if (raw_pressed[ok]) {
                        if (lvl < 140U) lvl = 140U;
                    } else if (st->key_release_ms[ok] > 0ULL && now_ms >= st->key_release_ms[ok]) {
                        uint64_t dt = now_ms - st->key_release_ms[ok];
                        if (dt < (uint64_t)fade_dur) {
                            uint8_t nl = (uint8_t)(140ULL - (dt * 140ULL) / (uint64_t)fade_dur);
                            if (nl > lvl) lvl = nl;
                        }
                    }
                }
            }
            if (global_sub == 4U || global_sub == 5U || global_sub == 10U || global_sub == 11U)
                lvl = (uint8_t)(255U - lvl);
            else if ((global_sub & 1U) == 0U && lvl < 35U)
                lvl = 35U;
            r = (uint8_t)(((uint32_t)tr * lvl) / 255U);
            g = (uint8_t)(((uint32_t)tg * lvl) / 255U);
            b = (uint8_t)(((uint32_t)tb * lvl) / 255U);
        } else if (global_mode == 3U) {
            if (global_sub == 1U)
                hsv_wheel_rgb((uint8_t)((ph + (uint32_t)i * 20U) & 0xFFU), &r, &g, &b);
            uint8_t breath = triangle_wave_u8(ph * 2U + ((global_sub == 2U) ? (k * 64U) : 0U));
            r = (uint8_t)(((uint32_t)r * breath) / 255U);
            g = (uint8_t)(((uint32_t)g * breath) / 255U);
            b = (uint8_t)(((uint32_t)b * breath) / 255U);
        } else if (global_mode == 4U) {
            uint32_t slot = (ph / 16U) + (uint32_t)i * 3U + (uint32_t)global_sub * 11U;
            hsv_wheel_rgb((uint8_t)((slot * 97U + (uint32_t)i * 53U + (ph & 0x1FU)) & 0xFFU), &r,
                          &g, &b);
        } else if (global_sub == 1U) {
            uint8_t prof_idx = (st->cfg.cfg_selection >= 1U && st->cfg.cfg_selection <= 4U)
                                   ? (uint8_t)(st->cfg.cfg_selection - 1U)
                                   : 0U;
            r = st->cfg.led_effect[8U + prof_idx * 4U];
            g = st->cfg.led_effect[8U + prof_idx * 4U + 1U];
            b = st->cfg.led_effect[8U + prof_idx * 4U + 2U];
        } else if (global_sub == 2U) {
            const uint8_t *ld = &st->cfg.led_info[k][off];
            r = ld[4];
            g = ld[5];
            b = ld[6];
        } else if (global_sub == 3U && raw_pressed[k]) {
            r = st->cfg.led_effect[44] ? st->cfg.led_effect[44] : 255U;
            g = st->cfg.led_effect[45] ? st->cfg.led_effect[45] : 255U;
            b = st->cfg.led_effect[46] ? st->cfg.led_effect[46] : 255U;
        }

        if (fn > 0U && st->cfg.led_effect[43] != 0U) {
            r = st->cfg.led_effect[40];
            g = st->cfg.led_effect[41];
            b = st->cfg.led_effect[42];
        }
        if (st->cfg.adv_key[k][0] == 4U && raw_pressed[k] && !eff_pressed[k] &&
            st->cfg.led_effect[39] != 0U) {
            r = st->cfg.led_effect[36];
            g = st->cfg.led_effect[37];
            b = st->cfg.led_effect[38];
        }
        out_r[i] = r;
        out_g[i] = g;
        out_b[i] = b;
    }

    for (uint8_t bit = 0U; bit < 3U; ++bit) {
        size_t base = 24U + (size_t)bit * 4U;
        if ((st->host_leds & (1U << bit)) != 0U && st->cfg.led_effect[base + 3U] != 0U) {
            out_r[bit * 2U] = st->cfg.led_effect[base];
            out_g[bit * 2U] = st->cfg.led_effect[base + 1U];
            out_b[bit * 2U] = st->cfg.led_effect[base + 2U];
        }
    }
}

static void render_per_key_leds(const keypad_state_t *st, const led_ring_t *ring, uint64_t now_ms,
                                size_t off, const bool raw_pressed[SAYO_KEY_COUNT],
                                uint8_t out_r[RING_LED_COUNT], uint8_t out_g[RING_LED_COUNT],
                                uint8_t out_b[RING_LED_COUNT]) {
    for (uint8_t k = 0U; k < SAYO_KEY_COUNT; ++k) {
        if (st->cfg.led_status[k] == 0U || st->cfg.led_info[k][0] == 0U) continue;
        const uint8_t *ld = &st->cfg.led_info[k][off];
        uint8_t led_mode = (uint8_t)(ld[0] & 0x0FU);
        uint32_t spd_mul = 1U << (3U - ((ld[0] >> 6U) & 0x03U));
        uint8_t event_mode = ld[1];
        uint32_t light_ms = (uint32_t)(ld[2] ? ld[2] : 4U) * 60U;
        uint32_t dark_ms = (uint32_t)(ld[3] ? ld[3] : 4U) * 60U;
        if (light_ms < 80U) light_ms = 80U;
        if (dark_ms < 80U) dark_ms = 80U;

        if (led_mode == 4U) {
            uint8_t base_pos =
                (uint8_t)((ring->effect_phase * spd_mul * 3U + (uint32_t)k * 85U) & 0xFFU);
            hsv_wheel_rgb(base_pos, &out_r[k * 2U], &out_g[k * 2U], &out_b[k * 2U]);
            hsv_wheel_rgb((uint8_t)(base_pos + 36U), &out_r[k * 2U + 1U], &out_g[k * 2U + 1U],
                          &out_b[k * 2U + 1U]);
            continue;
        }

        uint8_t r = 0U, g = 0U, b = 0U;
        pick_per_key_color(st, ring, k, ld, spd_mul, &r, &g, &b);

        uint64_t trig_ms = (event_mode == 2U || event_mode == 4U || event_mode == 6U)
                               ? st->key_release_ms[k]
                               : ((st->key_press_ms[k] >= st->key_release_ms[k])
                                      ? st->key_press_ms[k]
                                      : st->key_release_ms[k]);
        uint64_t age_ms = (trig_ms > 0ULL && now_ms >= trig_ms) ? (now_ms - trig_ms) : 999999ULL;
        uint8_t scale = 255U;

        switch (led_mode) {
        case 0U:
            if (event_mode == 1U)
                scale = raw_pressed[k] ? 255U : 0U;
            else if (event_mode == 2U)
                scale = (!raw_pressed[k]) ? 255U : 0U;
            else if ((event_mode == 3U || event_mode == 4U) && age_ms < (uint64_t)light_ms)
                scale = (uint8_t)((age_ms * 255ULL) / (uint64_t)light_ms);
            break;
        case 1U:
            scale = ((event_mode != 0U) ? ((st->host_leds & event_mode) != 0U) : raw_pressed[k])
                        ? 255U
                        : 0U;
            break;
        case 2U:
            scale = triangle_wave_u8(ring->effect_phase * spd_mul * 2U + (uint32_t)k * 42U);
            break;
        case 3U: {
            uint32_t cyc_ms = light_ms + dark_ms;
            scale = (raw_pressed[k] || age_ms < (uint64_t)cyc_ms)
                        ? triangle_wave_u8((uint32_t)(((age_ms % (uint64_t)cyc_ms) * 255ULL) /
                                                      (uint64_t)cyc_ms))
                        : 0U;
            break;
        }
        case 8U: {
            uint32_t period = (light_ms + dark_ms) / spd_mul;
            if (period < 80U) period = 80U;
            uint32_t on_part = light_ms / spd_mul;
            if (on_part < 40U) on_part = 40U;
            scale = ((now_ms % (uint64_t)period) < (uint64_t)on_part) ? 255U : 0U;
            break;
        }
        case 9U: scale = (raw_pressed[k] || age_ms < (uint64_t)light_ms) ? 255U : 0U; break;
        case 14U:
            if (raw_pressed[k] && event_mode != 2U)
                scale = 255U;
            else if (age_ms < (uint64_t)light_ms)
                scale = (uint8_t)(255ULL - (age_ms * 255ULL) / (uint64_t)light_ms);
            else
                scale = 0U;
            break;
        case 15U:
            if (raw_pressed[k] || age_ms < (uint64_t)light_ms)
                scale = (age_ms < (uint64_t)light_ms)
                            ? (uint8_t)((age_ms * 255ULL) / (uint64_t)light_ms)
                            : 255U;
            else
                scale = 0U;
            break;
        default: break;
        }

        out_r[k * 2U] = out_r[k * 2U + 1U] = (uint8_t)(((uint32_t)r * scale) / 255U);
        out_g[k * 2U] = out_g[k * 2U + 1U] = (uint8_t)(((uint32_t)g * scale) / 255U);
        out_b[k * 2U] = out_b[k * 2U + 1U] = (uint8_t)(((uint32_t)b * scale) / 255U);
    }
}

static void render_sayo_led_config(led_ring_t *ring, const keypad_state_t *st, bool is_connected) {
    if (!is_connected || ring == NULL || st == NULL) return;
    uint8_t global_bright = st->cfg.led_effect[7] > 100U ? 100U : st->cfg.led_effect[7];
    if (st->leds_master_off || global_bright == 0U) {
        for (int i = 0; i < RING_LED_COUNT; ++i) {
            write_led_fd(ring->fd_r[i], &ring->cur_r[i], 0U, false);
            write_led_fd(ring->fd_g[i], &ring->cur_g[i], 0U, false);
            write_led_fd(ring->fd_b[i], &ring->cur_b[i], 0U, false);
        }
        return;
    }

    uint64_t now_ms = monotonic_ms();
    uint8_t fn = resolve_effective_fn_layer(st);
    size_t off = 16U + (size_t)fn * 8U;
    bool raw_pressed[SAYO_KEY_COUNT] = {st->pressed_minus, st->pressed_center, st->pressed_plus};
    bool eff_pressed[SAYO_KEY_COUNT];
    compute_effective_button_states(st, eff_pressed);

    uint8_t out_r[RING_LED_COUNT] = {0}, out_g[RING_LED_COUNT] = {0}, out_b[RING_LED_COUNT] = {0};
    if (st->cfg.led_effect[3] != 0U)
        render_global_leds(st, ring, now_ms, fn, off, raw_pressed, eff_pressed, out_r, out_g,
                           out_b);
    else
        render_per_key_leds(st, ring, now_ms, off, raw_pressed, out_r, out_g, out_b);

    for (int i = 0; i < RING_LED_COUNT; ++i) {
        write_led_fd(ring->fd_r[i], &ring->cur_r[i],
                     (uint8_t)(((uint32_t)out_r[i] * global_bright) / 100U), false);
        write_led_fd(ring->fd_g[i], &ring->cur_g[i],
                     (uint8_t)(((uint32_t)out_g[i] * global_bright) / 100U), false);
        write_led_fd(ring->fd_b[i], &ring->cur_b[i],
                     (uint8_t)(((uint32_t)out_b[i] * global_bright) / 100U), false);
    }
}

static void append_unique_key(uint8_t keys[6], uint8_t *mods, size_t *count, uint8_t usage) {
    if (usage == 0U) return;
    if (usage >= 0xE0U && usage <= 0xE7U && mods != NULL) {
        *mods |= (uint8_t)(1U << (usage - 0xE0U));
        return;
    }
    if (*count > 6U) return;
    for (size_t i = 0U; i < *count; ++i)
        if (keys[i] == usage) return;
    if (*count == 6U) {

        memset(keys, 0x01, 6U);
        *count = 7U;
        return;
    }
    keys[*count] = usage;
    (*count)++;
}

static void compute_effective_button_states(const keypad_state_t *st,
                                            bool out_pressed[SAYO_KEY_COUNT]) {
    out_pressed[0] =
        st->cfg.adv_key[0][0] == 3U ? (st->tgl_latch_mask & (1U << 0)) != 0U : st->pressed_minus;
    out_pressed[1] =
        st->cfg.adv_key[1][0] == 3U ? (st->tgl_latch_mask & (1U << 1)) != 0U : st->pressed_center;
    out_pressed[2] =
        st->cfg.adv_key[2][0] == 3U ? (st->tgl_latch_mask & (1U << 2)) != 0U : st->pressed_plus;

    for (uint8_t i = 0U; i < SAYO_KEY_COUNT; ++i) {
        const uint8_t *ak = st->cfg.adv_key[i];
        if (ak[0] == 4U) {
            uint8_t mate = ak[1];
            if (mate < SAYO_KEY_COUNT && mate != i && out_pressed[i] && out_pressed[mate])
                out_pressed[mate] = false;
        }
    }
}

static size_t collect_keyboard_keys(const keypad_state_t *st, uint8_t keys[6], uint8_t *out_mods) {
    memset(keys, 0, 6U);
    uint8_t mods = 0U;
    size_t k = 0U;

    uint8_t fn = resolve_effective_fn_layer(st);
    size_t off = 16U + (size_t)fn * 8U;

    bool pressed[SAYO_KEY_COUNT];
    compute_effective_button_states(st, pressed);

    for (uint8_t i = 0U; i < SAYO_KEY_COUNT; ++i) {
        const builtin_key_t *builtin = &st->builtin_keys[i];
        mods |= builtin->modifiers;
        for (size_t j = 0U; j < sizeof(builtin->keys); ++j)
            append_unique_key(keys, &mods, &k, builtin->keys[j]);
        if (!pressed[i]) continue;
        const uint8_t *kd = &st->cfg.key_info[i][off];
        uint8_t kmode = kd[0];
        if (kmode == SAYO_KEY_CHORD) {
            mods |= kd[4];
            append_unique_key(keys, &mods, &k, kd[5]);
            append_unique_key(keys, &mods, &k, kd[6]);
            append_unique_key(keys, &mods, &k, kd[7]);
        }
    }

    *out_mods = mods;
    return k;
}

static size_t build_hid_input_packet(const keypad_state_t *st, uint8_t out_pkt[16]) {
    uint8_t keys[6], mods;
    size_t k = collect_keyboard_keys(st, keys, &mods);
    mods |= st->macro_held_mod;
    if (st->macro_key_down && st->macro_q_head < st->macro_q_tail) {
        uint8_t mmod = st->macro_q[st->macro_q_head].mod;
        if (st->macro_q[st->macro_q_head].caps_invert != 0U &&
            ((st->host_leds ^ st->macro_enqueued_leds) & 2U) != 0U)
            mmod ^= 0x02U;
        mods |= mmod;
        append_unique_key(keys, &mods, &k, st->macro_q[st->macro_q_head].usage);
    }

    if (st->protocol_mode == 0U) {
        out_pkt[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
        out_pkt[1] = mods;
        out_pkt[2] = 0x00U;
        memcpy(&out_pkt[3], keys, 6U);
        return 9U;
    } else {
        out_pkt[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
        out_pkt[1] = 0x01U;
        out_pkt[2] = mods;
        out_pkt[3] = 0x00U;
        memcpy(&out_pkt[4], keys, 6U);
        return 10U;
    }
}

static int send_hid_packet_nonblock(int fd, const uint8_t *pkt, size_t len) {
    if (fd < 0 || pkt == NULL || len == 0U) {
        errno = EINVAL;
        return -1;
    }
    for (unsigned attempt = 0; attempt < 4U; ++attempt) {
        ssize_t sent = send(fd, pkt, len, MSG_NOSIGNAL | MSG_DONTWAIT);
        if (sent >= 0) {
            if ((size_t)sent == len) return 1;
            errno = EIO;
            return -1;
        }
        if (errno == EINTR && !g_stop) continue;
        if (errno == EAGAIN || errno == EWOULDBLOCK || errno == ENOBUFS || errno == EINTR) return 0;
        return -1;
    }
    return 0;
}

static int queue_tx_packet(keypad_state_t *st, tx_queue_t *q, const uint8_t *packet, size_t len,
                           uint8_t kind, uint8_t macro_action, bool optional) {
    if (st->tx_fault) return -1;
    if (len == 0U || len > TX_PACKET_MAX || q->count == TX_QUEUE_CAP) {
        if (optional) {
            st->telemetry_dropped++;
            return 0;
        }
        st->tx_fault = true;
        errno = ENOBUFS;
        return -1;
    }
    tx_record_t *r = &q->records[(q->head + q->count) % TX_QUEUE_CAP];
    memcpy(r->data, packet, len);
    r->len = (uint8_t)len;
    r->kind = kind;
    r->macro_action = macro_action;
    r->queued_ms = monotonic_ms();
    r->save_generation = 0U;
    q->count++;
    if (q == &st->tx_input && q->count > st->tx_high_water) st->tx_high_water = q->count;
    return 0;
}

static int flush_tx_queue(int fd, keypad_state_t *st, tx_queue_t *q, uint64_t max_age_ms,
                          unsigned budget) {
    if (st->tx_fault) return -1;
    uint64_t now = monotonic_ms();
    if (q == &st->tx_input && st->protocol_barrier) budget = 0U;
    while (q->count > 0U) {
        tx_record_t *r = &q->records[q->head];
        if (now - r->queued_ms >= max_age_ms) {
            st->tx_fault = true;
            errno = ETIMEDOUT;
            return -1;
        }
        if (now < q->retry_ms || budget == 0U) break;
        if (r->save_generation > st->save_completed) {
            q->retry_ms = now + 5ULL;
            break;
        }
        int result = send_hid_packet_nonblock(fd, r->data, r->len);
        int send_errno = errno;
        now = monotonic_ms();
        errno = send_errno;
        if (result < 0) {
            st->tx_fault = true;
            return -1;
        }
        if (result == 0) {
            st->tx_retries++;
            q->retry_ms = now + TX_RETRY_MS;
            break;
        }
        q->retry_ms = 0;
        if (r->kind == TX_PROTOCOL) st->protocol_barrier = false;
        if (r->kind == TX_CONSUMER)
            st->active_consumer_usage = (uint16_t)(r->data[2] | ((uint16_t)r->data[3] << 8));
        else if (r->kind == TX_MOUSE)
            st->active_mouse_btns = r->data[2];
        else if (r->kind == TX_SYSTEM)
            st->active_sysctrl_bits = r->data[2];
        if (q == &st->tx_input) st->last_tx_ms = now;
        if (r->macro_action >= BUILTIN_TX_BASE &&
            r->macro_action < BUILTIN_TX_BASE + SAYO_KEY_COUNT) {
            builtin_key_t *builtin = &st->builtin_keys[r->macro_action - BUILTIN_TX_BASE];
            builtin->pending = false;
            builtin->deadline_ms = now + builtin->delay_ms;
        } else if (r->macro_action != MACRO_TX_NONE) {
            st->macro_tx_pending = false;
            st->last_macro_ms = now;
            if (r->macro_action == MACRO_TX_UP) {
                st->macro_q_head++;
                if (st->macro_q_head == st->macro_q_tail) st->macro_q_head = st->macro_q_tail = 0U;
            }
        }
        q->head = (q->head + 1U) % TX_QUEUE_CAP;
        q->count--;
        budget--;
        now = monotonic_ms();
    }
    return 0;
}

static int send_control_packet(int fd, keypad_state_t *st, const uint8_t *pkt, size_t len) {
    if (queue_tx_packet(st, &st->tx_control, pkt, len, TX_OTHER, MACRO_TX_NONE, false) < 0)
        return -1;
    return flush_tx_queue(fd, st, &st->tx_control, TX_CONTROL_MAX_AGE_MS, 4U);
}

static void queue_vendor_response(int intr_fd, int fallback_fd, keypad_state_t *st,
                                  const uint8_t *packet, size_t len) {
    if (intr_fd < 0 && fallback_fd < 0) return;
    tx_queue_t *q = intr_fd >= 0 ? &st->tx_vendor : &st->tx_control;
    if (intr_fd >= 0 && st->save_reply_generation == 0U && q->count > 0U && len > 0U &&
        len <= TX_PACKET_MAX &&
        (st->pressed_minus || st->pressed_center || st->pressed_plus ||
         (st->last_input_edge_ms != 0U && monotonic_ms() - st->last_input_edge_ms < 250ULL))) {
        size_t prev = (q->head + q->count - 1U) % TX_QUEUE_CAP;
        if (q->records[prev].save_generation == 0U) {
            memcpy(q->records[prev].data, packet, len);
            q->records[prev].len = (uint8_t)len;
            q->records[prev].queued_ms = monotonic_ms();
            return;
        }
    }
    size_t tail = (q->head + q->count) % TX_QUEUE_CAP;
    if (queue_tx_packet(st, q, packet, len, TX_OTHER, MACRO_TX_NONE, false) < 0) return;
    q->records[tail].save_generation = st->save_reply_generation;
    st->save_reply_generation = 0U;
    if (intr_fd < 0) (void)flush_tx_queue(fallback_fd, st, q, TX_CONTROL_MAX_AGE_MS, 4U);
}

static bool tx_queue_ready(const tx_queue_t *q, uint64_t now) {
    return q->count > 0U && now >= q->retry_ms;
}

static int tx_poll_timeout(const tx_queue_t *q, uint64_t now, int timeout, uint64_t max_age) {
    if (q->count == 0U) return timeout;
    uint64_t deadline = q->records[q->head].queued_ms + max_age;
    if (q->retry_ms > now && q->retry_ms < deadline) deadline = q->retry_ms;
    int remaining = deadline > now ? (int)(deadline - now) : 0;
    return remaining < timeout ? remaining : timeout;
}

static int deadline_poll_timeout(uint64_t now, uint64_t last, uint64_t period, int timeout) {
    uint64_t elapsed = now >= last ? now - last : 0U;
    uint64_t remaining = elapsed < period ? period - elapsed : 0U;
    return remaining < (uint64_t)timeout ? (int)remaining : timeout;
}

static int send_extra_hid_reports_if_needed(int intr_fd, keypad_state_t *st) {
    if (intr_fd < 0 || st->protocol_mode == 0U) return 0;

    uint8_t fn = resolve_effective_fn_layer(st);
    size_t off = 16U + (size_t)fn * 8U;

    bool pressed[SAYO_KEY_COUNT];
    compute_effective_button_states(st, pressed);

    uint16_t want_consumer = 0U;
    uint8_t want_mouse_b = 0U;
    int8_t want_mouse_x = 0;
    int8_t want_mouse_y = 0;
    int8_t want_mouse_w = 0;
    uint8_t want_sysctrl = 0U;

    for (uint8_t i = 0U; i < SAYO_KEY_COUNT; ++i) {
        if (st->builtin_keys[i].consumer != 0U) want_consumer = st->builtin_keys[i].consumer;
        if (!pressed[i]) continue;
        const uint8_t *kd = &st->cfg.key_info[i][off];
        if (kd[0] == 2U) {
            want_mouse_b |= kd[4];
            want_mouse_x = (int8_t)(want_mouse_x + (int8_t)kd[5]);
            want_mouse_y = (int8_t)(want_mouse_y + (int8_t)kd[6]);
            want_mouse_w = (int8_t)(want_mouse_w + (int8_t)kd[7]);
        }
    }

    if (want_consumer != st->queued_consumer_usage) {
        uint8_t cpkt[4];
        cpkt[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
        cpkt[1] = 0x04U;
        cpkt[2] = (uint8_t)(want_consumer & 0xFFU);
        cpkt[3] = (uint8_t)((want_consumer >> 8U) & 0xFFU);
        st->cfg.cmd1f_data[4][0] = cpkt[2];
        st->cfg.cmd1f_data[4][1] = cpkt[3];
        if (queue_tx_packet(st, &st->tx_input, cpkt, sizeof(cpkt), TX_CONSUMER, MACRO_TX_NONE,
                            false) < 0) {
            return -1;
        }
        st->queued_consumer_usage = want_consumer;
    }

    if (want_mouse_b != st->queued_mouse_btns || want_mouse_x != 0 || want_mouse_y != 0 ||
        want_mouse_w != 0) {
        uint8_t mpkt[6];
        mpkt[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
        mpkt[1] = 0x03U;
        mpkt[2] = want_mouse_b;
        mpkt[3] = (uint8_t)want_mouse_x;
        mpkt[4] = (uint8_t)want_mouse_y;
        mpkt[5] = (uint8_t)want_mouse_w;
        memcpy(st->cfg.cmd1f_data[3], &mpkt[2], 4U);
        if (queue_tx_packet(st, &st->tx_input, mpkt, sizeof(mpkt), TX_MOUSE, MACRO_TX_NONE, false) <
            0) {
            return -1;
        }
        st->queued_mouse_btns = want_mouse_b;
    }

    if (want_sysctrl != st->queued_sysctrl_bits) {
        uint8_t spkt[3];
        spkt[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
        spkt[1] = 0x05U;
        spkt[2] = want_sysctrl;
        if (queue_tx_packet(st, &st->tx_input, spkt, sizeof(spkt), TX_SYSTEM, MACRO_TX_NONE,
                            false) < 0) {
            return -1;
        }
        st->queued_sysctrl_bits = want_sysctrl;
    }

    return 0;
}

static bool extra_hid_reports_needed(const keypad_state_t *st) {
    if (st->protocol_mode == 0U) return false;
    uint8_t fn = resolve_effective_fn_layer(st);
    size_t off = 16U + (size_t)fn * 8U;
    bool pressed[SAYO_KEY_COUNT];
    compute_effective_button_states(st, pressed);
    uint16_t want_consumer = 0U;
    uint8_t want_mouse_b = 0U;
    int8_t want_mouse_x = 0, want_mouse_y = 0, want_mouse_w = 0;
    for (uint8_t i = 0U; i < SAYO_KEY_COUNT; ++i) {
        if (st->builtin_keys[i].consumer != 0U) want_consumer = st->builtin_keys[i].consumer;
        if (!pressed[i]) continue;
        const uint8_t *kd = &st->cfg.key_info[i][off];
        if (kd[0] == 2U) {
            want_mouse_b |= kd[4];
            want_mouse_x = (int8_t)(want_mouse_x + (int8_t)kd[5]);
            want_mouse_y = (int8_t)(want_mouse_y + (int8_t)kd[6]);
            want_mouse_w = (int8_t)(want_mouse_w + (int8_t)kd[7]);
        }
    }
    return want_consumer != st->queued_consumer_usage || want_mouse_b != st->queued_mouse_btns ||
           want_mouse_x != 0 || want_mouse_y != 0 || want_mouse_w != 0 ||
           st->queued_sysctrl_bits != 0U;
}

static int submit_hid_input_report(int intr_fd, keypad_state_t *st, uint8_t macro_action) {
    if (intr_fd < 0) return -1;
    uint8_t pkt[16];
    size_t len = build_hid_input_packet(st, pkt);
    memcpy(st->last_kb_pkt, pkt, len);
    st->last_kb_len = (uint8_t)len;
    memcpy(st->cfg.cmd1f_data[1], &pkt[st->protocol_mode == 0U ? 1U : 2U], 8U);
    bool builtin_stage = macro_action >= BUILTIN_TX_BASE;
    if (queue_tx_packet(st, &st->tx_input, pkt, len, TX_KEYBOARD,
                        builtin_stage ? MACRO_TX_NONE : macro_action, false) < 0 ||
        send_extra_hid_reports_if_needed(intr_fd, st) < 0)
        return -1;
    if (builtin_stage) {
        size_t last = (st->tx_input.head + st->tx_input.count - 1U) % TX_QUEUE_CAP;
        st->tx_input.records[last].macro_action = macro_action;
    }
    st->report_dirty = false;
    return flush_tx_queue(intr_fd, st, &st->tx_input, TX_INPUT_MAX_AGE_MS, 16U);
}

static int cancel_macro_for_ordinary_keys(int intr_fd, keypad_state_t *st);

static int send_hid_input_report(int intr_fd, keypad_state_t *st) {
    if (cancel_macro_for_ordinary_keys(intr_fd, st) < 0) return -1;
    return submit_hid_input_report(intr_fd, st, MACRO_TX_NONE);
}

static uint16_t calc_sayo_v2_checksum(const uint8_t *pkt, size_t pkt_len) {
    uint32_t sum = 0U;
    for (size_t i = 0U; i + 1U < pkt_len; i += 2U) {
        if (i == 2U) continue;
        sum += (uint32_t)get_u16_le(&pkt[i]);
    }
    return (uint16_t)(sum & 0xFFFFU);
}

static void send_sayo_v2_broadcast_event(int intr_fd, keypad_state_t *st, uint8_t ev_type,
                                         uint8_t ev_val) {
    if (intr_fd < 0 || st == NULL || st->protocol_mode == 0U || st->cfg.active_mode == 0U) return;
    uint8_t tx_frame[65];
    memset(tx_frame, 0, sizeof(tx_frame));
    tx_frame[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
    uint8_t *pkt = &tx_frame[1];
    pkt[0] = 0x21U;
    pkt[1] = 0x03U;
    put_u16_le(&pkt[4], 8U);
    pkt[6] = 0xFFU;
    pkt[7] = 0x02U;
    pkt[8] = ev_type;
    pkt[9] = ev_val;
    uint16_t cksum = calc_sayo_v2_checksum(pkt, 64U);
    put_u16_le(&pkt[2], cksum);

    if (st->tx_input.count > 0U || st->tx_vendor.count > 32U) {
        st->telemetry_dropped++;
        return;
    }
    (void)queue_tx_packet(st, &st->tx_vendor, tx_frame, sizeof(tx_frame), TX_OTHER, MACRO_TX_NONE,
                          true);
}

static bool resolve_v2_enum_index(keypad_state_t *st, uint8_t req_idx, uint8_t max_count,
                                  uint16_t base_hdr, uint8_t *resp_cmd, uint8_t *out_idx,
                                  bool *out_enum_continue) {
    if (req_idx == 0xFFU) {
        uint8_t idx = st->enum_next_idx++;
        resp_cmd[3] = idx;
        if (idx >= max_count) {
            st->enum_last_cmd = 0xFFU;
            st->enum_next_idx = 0U;
            put_u16_le(&resp_cmd[0], 0x4004U);
            return false;
        }
        if (base_hdr != 0U) put_u16_le(&resp_cmd[0], (uint16_t)(0x0800U | base_hdr));
        *out_enum_continue = true;
        *out_idx = idx;
        return true;
    }
    if (req_idx >= max_count) {
        put_u16_le(&resp_cmd[0], 0x4004U);
        return false;
    }
    if (base_hdr != 0U) put_u16_le(&resp_cmd[0], base_hdr);
    *out_idx = req_idx;
    return true;
}

static size_t handle_v2_text_slot_cmd(keypad_state_t *st, const uint8_t *req_cmd,
                                      uint16_t req_sta_len, uint16_t req_len, uint8_t req_idx,
                                      uint8_t max_slots, uint8_t default_enc, bool strict_enc,
                                      uint8_t *enc_arr, uint8_t (*slots)[56], uint8_t *resp_cmd,
                                      bool *out_enum_continue) {
    uint8_t idx = 0U;
    if (!resolve_v2_enum_index(st, req_idx, max_slots, 0U, resp_cmd, &idx, out_enum_continue))
        return 4U;
    if (req_len > 4U && req_idx != 0xFFU) {
        uint8_t req_enc = (uint8_t)((req_sta_len >> 10U) & 0x3FU);
        size_t copy_len = (size_t)(req_len - 4U);
        if (strict_enc) {
            if ((req_enc != 2U && req_enc != 3U) || copy_len > 56U ||
                (req_enc == 3U && (copy_len & 1U) != 0U)) {
                put_u16_le(&resp_cmd[0], 0x4004U);
                return 4U;
            }
            enc_arr[idx] = req_enc;
        } else {
            if (req_enc == 2U || req_enc == 3U) enc_arr[idx] = req_enc;
            if (copy_len > 56U) copy_len = 56U;
        }
        memset(slots[idx], 0, 56U);
        memcpy(slots[idx], &req_cmd[4], copy_len);
    }
    uint8_t enc = (enc_arr[idx] == 2U || enc_arr[idx] == 3U) ? enc_arr[idx] : default_enc;
    put_u16_le(&resp_cmd[0], (uint16_t)(((uint16_t)enc << 10U) | 60U));
    memcpy(&resp_cmd[4], slots[idx], 56U);
    return 60U;
}

static size_t handle_v2_blob_cmd(const uint8_t *req_cmd, uint16_t req_len, uint8_t req_idx,
                                 uint8_t *blob, size_t blob_len, uint16_t min_write_len,
                                 uint8_t *resp_cmd, led_ring_t *ring) {
    if (req_idx != 0U) {
        put_u16_le(&resp_cmd[0], 0x4004U);
        return 4U;
    }
    if (req_len >= min_write_len) {
        size_t copy_len = (size_t)(req_len - 4U);
        if (copy_len > blob_len) copy_len = blob_len;
        memcpy(blob, &req_cmd[4], copy_len);
        mark_leds_dirty(ring);
    }
    put_u16_le(&resp_cmd[0], (uint16_t)(4U + blob_len));
    memcpy(&resp_cmd[4], blob, blob_len);
    return 4U + blob_len;
}

static size_t handle_v2_layer_slot_cmd(keypad_state_t *st, const uint8_t *req_cmd, uint16_t req_len,
                                       uint8_t req_idx, uint8_t (*slots)[56], bool is_key_info,
                                       uint8_t *resp_cmd, led_ring_t *ring,
                                       bool *out_enum_continue) {
    uint8_t idx = 0U;
    if (!resolve_v2_enum_index(st, req_idx, SAYO_KEY_COUNT, 60U, resp_cmd, &idx, out_enum_continue))
        return 4U;
    if (req_len >= 60U && req_idx != 0xFFU) {
        memcpy(&slots[idx][16], &req_cmd[20], 40U);
        normalize_sayo_geometry_headers(&st->cfg);
        if (is_key_info) {
            sync_legacy_usages_from_cfg(st);
            st->report_dirty = true;
        } else {
            mark_leds_dirty(ring);
        }
    }
    memcpy(&resp_cmd[4], slots[idx], 56U);
    return 60U;
}

static size_t handle_single_sayo_v2_cmd(const uint8_t *req_cmd, size_t req_avail, uint8_t *resp_cmd,
                                        size_t resp_max, keypad_state_t *st, led_ring_t *ring,
                                        bool *out_enum_continue) {
#define FAIL_V2()                                                                                  \
    do {                                                                                           \
        put_u16_le(&resp_cmd[0], 0x4004U);                                                         \
        return 4U;                                                                                 \
    } while (0)
    *out_enum_continue = false;
    if (req_avail < 4U || resp_max < 60U) return 0U;

    uint16_t req_sta_len = get_u16_le(&req_cmd[0]);
    uint16_t req_len = (uint16_t)(req_sta_len & 0x03FFU);
    if (req_len < 4U) req_len = 4U;
    if ((size_t)req_len > req_avail) req_len = (uint16_t)req_avail;

    uint8_t cmd_id = req_cmd[2];
    uint8_t req_idx = req_cmd[3];

    if (req_idx == 0xFFU && cmd_id != 0x1AU && cmd_id != 0xFFU) {
        if (st->enum_last_cmd != cmd_id) {
            st->enum_last_cmd = cmd_id;
            st->enum_next_idx = 0U;
        }
    } else if (req_idx != 0xFFU) {
        st->enum_last_cmd = 0xFFU;
        st->enum_next_idx = 0U;
    }

    memset(resp_cmd, 0, 60U);
    resp_cmd[2] = cmd_id;
    resp_cmd[3] = req_idx;

    switch (cmd_id) {
    case 0x00U: {
        if (req_idx != 0U) FAIL_V2();
        if (req_len > 13U && req_cmd[13] < SAYO_FN_LAYERS) {
            st->cfg.key_fn = req_cmd[13];
            sync_legacy_usages_from_cfg(st);
            mark_leds_dirty(ring);
        }
        put_u16_le(&resp_cmd[0], 40U);
        put_u16_le(&resp_cmd[4], SAYO_MODEL_CODE);
        put_u16_le(&resp_cmd[6], SAYO_FW_VER);
        resp_cmd[11] = 0x55U;
        resp_cmd[12] = SAYO_BATTERY_PCT;
        resp_cmd[13] = st->cfg.key_fn;
        resp_cmd[14] = 4U;
        resp_cmd[15] = 4U;
        static const uint8_t k_api_list[] = {0x01U, 0x02U, 0x03U, 0x04U, 0x05U, 0x06U, 0x0DU, 0x0EU,
                                             0x10U, 0x11U, 0x12U, 0x13U, 0x16U, 0x17U, 0x19U, 0x1AU,
                                             0x1DU, 0x1EU, 0x1FU, 0x26U, 0x27U, 0x28U, 0x2AU};
        memcpy(&resp_cmd[16], k_api_list, sizeof(k_api_list));
        return 40U;
    }
    case 0x01U: {
        if (req_idx > 3U) FAIL_V2();
        if (req_len > 4U) {
            uint8_t req_enc = (uint8_t)((req_sta_len >> 10U) & 0x3FU);
            if (req_enc == 2U || req_enc == 3U)
                st->cfg.dev_name_enc = req_enc;
            else if (req_idx == 2U || req_idx == 3U)
                st->cfg.dev_name_enc = req_idx;
            size_t copy_len = (size_t)(req_len - 4U);
            if (copy_len > 48U) copy_len = 48U;
            memset(st->cfg.dev_name_utf16, 0, sizeof(st->cfg.dev_name_utf16));
            memcpy(st->cfg.dev_name_utf16, &req_cmd[4], copy_len);
            if (st->cfg.dev_name_utf16[0] == 0U && st->cfg.dev_name_utf16[1] == 0U) {
                st->cfg.dev_name_enc = 3U;
                set_utf16le_from_ascii(st->cfg.dev_name_utf16, SAYO_DEFAULT_NAME);
            }
        }
        uint8_t enc =
            (st->cfg.dev_name_enc == 2U || st->cfg.dev_name_enc == 3U) ? st->cfg.dev_name_enc : 3U;
        put_u16_le(&resp_cmd[0], (uint16_t)(((uint16_t)enc << 10U) | 52U));
        resp_cmd[3] = req_idx;
        memcpy(&resp_cmd[4], st->cfg.dev_name_utf16, 48U);
        return 52U;
    }
    case 0x02U: {
        if (req_idx != 0U) FAIL_V2();
        if (req_len >= 10U) {
            uint8_t sel = (uint8_t)(req_cmd[9] & 0x0FU);
            if (sel >= 1U && sel <= 4U) st->cfg.cfg_selection = sel;
        }
        uint64_t ms = monotonic_ms();
        put_u16_le(&resp_cmd[0], 48U);
        resp_cmd[8] = 60U;
        resp_cmd[9] = (uint8_t)((st->cfg.cfg_selection & 0x0FU) | (4U << 4U));
        put_u16_le(&resp_cmd[10], (uint16_t)(ms % 1000ULL));
        put_u32_le(&resp_cmd[12], (uint32_t)(ms / 1000ULL));
        put_u16_le(&resp_cmd[16], SAYO_VID);
        put_u16_le(&resp_cmd[18], SAYO_PID);
        resp_cmd[20] = 5U;
        resp_cmd[21] = 5U;
        put_u32_le(&resp_cmd[22], 144000000U);
        put_u32_le(&resp_cmd[26], 144000000U);
        put_u32_le(&resp_cmd[30], 72000000U);
        put_u32_le(&resp_cmd[34], 144000000U);
        put_u32_le(&resp_cmd[38], 14000000U);
        put_u32_le(&resp_cmd[42], 14000000U);
        return 48U;
    }
    case 0x03U: {
        if (req_idx != 0U) FAIL_V2();
        if (req_len >= 42U)
            memcpy(st->cfg.opt_bytes, &req_cmd[4], 38U);
        else if (req_len >= 36U)
            memcpy(st->cfg.opt_bytes, &req_cmd[4], 32U);
        st->cfg.opt_bytes[17] = 0x04U;
        st->text_macos_hex = (st->cfg.opt_bytes[16] == 4U);
        put_u16_le(&resp_cmd[0], 44U);
        memcpy(&resp_cmd[4], st->cfg.opt_bytes, 38U);
        return 44U;
    }
    case 0x04U:
        return handle_v2_blob_cmd(req_cmd, req_len, req_idx, st->cfg.rf_cfg, 16U, 20U, resp_cmd,
                                  NULL);
    case 0x05U:
    case 0x06U:
        st->cfg.device_locked = (cmd_id == 0x05U) ? 1U : 0U;
        put_u16_le(&resp_cmd[0], 4U);
        return 4U;
    case 0x0DU:
        (void)save_sayo_cfg_to_disk(st);
        put_u16_le(&resp_cmd[0], 4U);
        return 4U;
    case 0x0EU:
        if (req_idx == 1U || req_idx == 2U) {
            init_default_sayo_cfg(st);
            (void)save_sayo_cfg_to_disk(st);
            mark_leds_dirty(ring);
        }
        put_u16_le(&resp_cmd[0], 4U);
        return 4U;
    case 0x10U:
        return handle_v2_layer_slot_cmd(st, req_cmd, req_len, req_idx, st->cfg.key_info, true,
                                        resp_cmd, ring, out_enum_continue);
    case 0x11U:
        return handle_v2_layer_slot_cmd(st, req_cmd, req_len, req_idx, st->cfg.led_info, false,
                                        resp_cmd, ring, out_enum_continue);
    case 0x12U: {
        uint8_t idx = 0U;
        if (!resolve_v2_enum_index(st, req_idx, SAYO_KEY_COUNT, 36U, resp_cmd, &idx,
                                   out_enum_continue))
            return 4U;
        if (req_len >= 10U && req_idx != 0xFFU) {
            size_t copy_len = (size_t)(req_len - 4U);
            if (copy_len > 32U) copy_len = 32U;
            memcpy(st->cfg.palette[idx], &req_cmd[4], copy_len);
            mark_leds_dirty(ring);
        }
        memcpy(&resp_cmd[4], st->cfg.palette[idx], 32U);
        return 36U;
    }
    case 0x13U: {
        uint8_t idx = 0U;
        if (!resolve_v2_enum_index(st, req_idx, SAYO_KEY_COUNT, 12U, resp_cmd, &idx,
                                   out_enum_continue))
            return 4U;
        if (req_len >= 6U && req_idx != 0xFFU) {
            st->cfg.touch_sens[idx][0] = req_cmd[4];
            st->cfg.touch_sens[idx][1] = req_cmd[5];
        }
        bool pressed[SAYO_KEY_COUNT] = {st->pressed_minus, st->pressed_center, st->pressed_plus};
        put_u16_le(&st->cfg.touch_sens[idx][4], pressed[idx] ? 320U : 100U);
        memcpy(&resp_cmd[4], st->cfg.touch_sens[idx], 8U);
        return 12U;
    }
    case 0x16U:
        return handle_v2_text_slot_cmd(st, req_cmd, req_sta_len, req_len, req_idx, 4U, 2U, true,
                                       st->cfg.password_enc, st->cfg.passwords, resp_cmd,
                                       out_enum_continue);
    case 0x17U:
        return handle_v2_text_slot_cmd(st, req_cmd, req_sta_len, req_len, req_idx, 8U, 3U, true,
                                       st->cfg.string_enc, st->cfg.strings, resp_cmd,
                                       out_enum_continue);
    case 0x19U:
        return handle_v2_text_slot_cmd(st, req_cmd, req_sta_len, req_len, req_idx, 8U, 2U, false,
                                       st->cfg.script_name_enc, st->cfg.script_names, resp_cmd,
                                       out_enum_continue);
    case 0x1AU: {
        if (req_idx == 0xFFU) {
            put_u16_le(&resp_cmd[0], 12U);
            put_u32_le(&resp_cmd[4], 0U);
            put_u32_le(&resp_cmd[8], (uint32_t)sizeof(st->cfg.script_mem));
            return 12U;
        }
        uint32_t addr = (req_len >= 8U) ? get_u32_le(&req_cmd[4]) : 0U;
        if (addr >= sizeof(st->cfg.script_mem)) FAIL_V2();
        size_t avail_mem = sizeof(st->cfg.script_mem) - (size_t)addr;
        if (req_len > 8U) {
            size_t write_len = (size_t)(req_len - 8U);
            if (write_len > avail_mem) write_len = avail_mem;
            memcpy(&st->cfg.script_mem[addr], &req_cmd[8], write_len);
        }
        size_t chunk = (avail_mem > 52U) ? 52U : avail_mem;
        put_u16_le(&resp_cmd[0], 60U);
        put_u32_le(&resp_cmd[4], addr);
        memcpy(&resp_cmd[8], &st->cfg.script_mem[addr], chunk);
        return 60U;
    }
    case 0x1DU: {
        uint8_t idx = 0U;
        if (!resolve_v2_enum_index(st, req_idx, SAYO_KEY_COUNT, 48U, resp_cmd, &idx,
                                   out_enum_continue))
            return 4U;
        if (req_len >= 48U && req_idx != 0xFFU) {
            memcpy(st->cfg.adv_key[idx], &req_cmd[4], 44U);
            st->report_dirty = true;
        }
        memcpy(&resp_cmd[4], st->cfg.adv_key[idx], 44U);
        return 48U;
    }
    case 0x1EU: {
        if (req_idx != 0U) FAIL_V2();
        put_u16_le(&resp_cmd[0], 8U);
        resp_cmd[4] = (st->pressed_minus ? 1U : 0U) | (st->pressed_center ? 2U : 0U) |
                      (st->pressed_plus ? 4U : 0U);
        return 8U;
    }
    case 0x1FU: {
        if (req_idx == 0U && req_len <= 4U) {
            put_u16_le(&resp_cmd[0], 8U);
            resp_cmd[4] = st->cfg.active_mode;
            return 8U;
        }
        if (req_idx >= 16U) FAIL_V2();
        if (req_idx == 7U) st->cfg.cmd1f_data[7][0] = st->host_leds;
        if (req_len > 4U) {
            size_t copy_len = (size_t)(req_len - 4U);
            if (copy_len > 32U) copy_len = 32U;
            memcpy(st->cfg.cmd1f_data[req_idx], &req_cmd[4], copy_len);
            if (req_idx == 7U) st->host_leds = st->cfg.cmd1f_data[7][0];
        }
        put_u16_le(&resp_cmd[0], 36U);
        memcpy(&resp_cmd[4], st->cfg.cmd1f_data[req_idx], 32U);
        return 36U;
    }
    case 0x26U:
        return handle_v2_blob_cmd(req_cmd, req_len, req_idx, st->cfg.led_effect, 48U, 12U, resp_cmd,
                                  ring);
    case 0x27U: {
        if (req_len >= 5U) {
            uint8_t val = (req_cmd[4] != 0U) ? 1U : 0U;
            if (req_idx < SAYO_KEY_COUNT)
                st->cfg.led_status[req_idx] = val;
            else
                memset(st->cfg.led_status, val, SAYO_KEY_COUNT);
            mark_leds_dirty(ring);
            put_u16_le(&resp_cmd[0], 8U);
            resp_cmd[4] = val;
            return 8U;
        }
        if (req_idx >= SAYO_KEY_COUNT) FAIL_V2();
        put_u16_le(&resp_cmd[0], 8U);
        resp_cmd[4] = st->cfg.led_status[req_idx];
        return 8U;
    }
    case 0x28U:
        return handle_v2_blob_cmd(req_cmd, req_len, req_idx, st->cfg.gamepad_cfg, 48U, 52U,
                                  resp_cmd, NULL);
    case 0x2AU: {
        uint8_t idx = 0U;
        if (!resolve_v2_enum_index(st, req_idx, 1U, 32U, resp_cmd, &idx, out_enum_continue))
            return 4U;
        if (req_len >= 12U && req_idx != 0xFFU) {
            size_t copy_len = (size_t)(req_len - 4U);
            if (copy_len > 28U) copy_len = 28U;
            memcpy(st->cfg.ambient_led, &req_cmd[4], copy_len);
            st->cfg.led_effect[0] = st->cfg.ambient_led[5];
            st->cfg.led_effect[1] = st->cfg.ambient_led[6];
            st->cfg.led_effect[2] = st->cfg.ambient_led[7];
            st->cfg.led_effect[7] = st->cfg.ambient_led[0];
            mark_leds_dirty(ring);
        }
        memcpy(&resp_cmd[4], st->cfg.ambient_led, 28U);
        return 32U;
    }
    case 0xFFU:
        if (req_idx <= 1U) st->cfg.active_mode = req_idx;
        put_u16_le(&resp_cmd[0], 4U);
        return 4U;
    default:
        if (req_idx == 0xFFU) {
            st->enum_last_cmd = 0xFFU;
            st->enum_next_idx = 0U;
            resp_cmd[3] = 0U;
        }
        FAIL_V2();
    }
#undef FAIL_V2
}

static size_t process_sayo_v2_single_cmd(uint8_t report_id, uint8_t echo, const uint8_t *cmd_ptr,
                                         size_t avail_rx, uint8_t *tx_pkt, keypad_state_t *st,
                                         led_ring_t *ring, bool *out_enum_continue) {
    if (report_id != 0x21U) return 0U;
    const size_t pkt_size = 64U;
    size_t max_payload = pkt_size - 4U;

    memset(tx_pkt, 0, pkt_size);
    tx_pkt[0] = report_id;
    tx_pkt[1] = echo;

    bool enum_continue = false;
    (void)handle_single_sayo_v2_cmd(cmd_ptr, avail_rx, &tx_pkt[4], max_payload, st, ring,
                                    &enum_continue);
    if (out_enum_continue != NULL) *out_enum_continue = enum_continue;

    uint16_t cksum = calc_sayo_v2_checksum(tx_pkt, pkt_size);
    put_u16_le(&tx_pkt[2], cksum);

    memcpy(st->last_v21_resp, tx_pkt, 64U);
    return pkt_size;
}

static size_t process_sayo_v1_packet(const uint8_t *rx_pkt, size_t rx_len, uint8_t tx_pkt[64],
                                     keypad_state_t *st, led_ring_t *ring) {
    memset(tx_pkt, 0, 64U);
    tx_pkt[0] = 0x02U;
    if (rx_len < 4U) return 64U;

    uint8_t cmd_id = rx_pkt[1];
    tx_pkt[1] = cmd_id;

    switch (cmd_id) {
    case 0x00U: {
        tx_pkt[2] = 9U;
        tx_pkt[3] = 0U;
        tx_pkt[4] = (uint8_t)(SAYO_FW_VER & 0xFFU);
        tx_pkt[5] = (uint8_t)((SAYO_FW_VER >> 8U) & 0xFFU);
        tx_pkt[6] = (uint8_t)(SAYO_MODEL_CODE & 0xFFU);
        tx_pkt[7] = 0U;
        tx_pkt[11] = 0x59U;
        break;
    }
    case 0x04U: {
        (void)save_sayo_cfg_to_disk(st);
        tx_pkt[2] = 1U;
        tx_pkt[3] = 0U;
        break;
    }
    case 0x06U:
    case 0x16U: {
        if (rx_len >= 7U) {
            uint8_t idx = rx_pkt[3];
            if (idx < SAYO_KEY_COUNT) {
                st->cfg.key_info[idx][16U] = 1U;
                st->cfg.key_info[idx][20U] = rx_pkt[4];
                st->cfg.key_info[idx][21U] = rx_pkt[5];
                sync_legacy_usages_from_cfg(st);
                mark_leds_dirty(ring);
            }
        }
        tx_pkt[2] = 4U;
        tx_pkt[3] = st->usage_minus;
        tx_pkt[4] = st->usage_center;
        tx_pkt[5] = st->usage_plus;
        break;
    }
    case 0x08U: {
        tx_pkt[2] = 48U;
        memcpy(&tx_pkt[3], st->cfg.dev_name_utf16, 48U);
        break;
    }
    case 0x10U: {
        if (rx_len >= 8U) {
            uint8_t idx = rx_pkt[3];
            if (idx < SAYO_KEY_COUNT) {
                uint8_t *ld = &st->cfg.led_info[idx][16U];
                ld[0] = (rx_pkt[4] != 0U) ? (uint8_t)(rx_pkt[4] & 0x0FU) : 1U;
                ld[1] = 0U;
                ld[2] = 100U;
                ld[3] = 100U;
                ld[4] = rx_pkt[5];
                ld[5] = rx_pkt[6];
                ld[6] = rx_pkt[7];
                mark_leds_dirty(ring);
            }
        }
        tx_pkt[2] = 4U;
        tx_pkt[3] = st->cfg.led_info[0][20U];
        tx_pkt[4] = st->cfg.led_info[0][21U];
        tx_pkt[5] = st->cfg.led_info[0][22U];
        break;
    }
    default: {
        tx_pkt[2] = 1U;
        tx_pkt[3] = 0U;
        break;
    }
    }

    uint8_t dlen = tx_pkt[2];
    if (dlen > 60U) {
        dlen = 60U;
        tx_pkt[2] = dlen;
    }
    uint32_t sum = 0U;
    for (size_t i = 0U; i < (size_t)dlen + 3U; ++i) sum += tx_pkt[i];
    tx_pkt[(size_t)dlen + 3U] = (uint8_t)(sum & 0xFFU);
    memcpy(st->last_v1_resp, tx_pkt, 64U);
    return 64U;
}

static void update_host_leds(keypad_state_t *st, led_ring_t *ring, uint8_t leds) {
    st->host_leds = leds;
    st->cfg.cmd1f_data[7][0] = leds;
    mark_leds_dirty(ring);
}

static void dispatch_incoming_output_report(const uint8_t *report_buf, size_t report_len,
                                            int intr_fd, int fallback_fd, keypad_state_t *st,
                                            led_ring_t *ring) {
    if (report_buf == NULL || report_len == 0U) return;
    if (st->protocol_mode == 0U) {
        update_host_leds(st, ring, report_buf[report_len - 1U]);
        return;
    }
    uint8_t report_id = report_buf[0];
    if (report_id == 0x22U) return;

    if (report_len == 1U) {
        update_host_leds(st, ring, report_buf[0]);
        return;
    }

    if (report_id == 0x01U) {
        update_host_leds(st, ring, report_buf[1]);
        return;
    }

    if (report_id == 0x21U && report_len >= 4U) {
        const size_t pkt_size = 64U;
        uint8_t aligned_rx[64];
        memset(aligned_rx, 0, pkt_size);
        size_t copy_len = (report_len < pkt_size) ? report_len : pkt_size;
        memcpy(aligned_rx, report_buf, copy_len);

        uint8_t echo = aligned_rx[1] ? aligned_rx[1] : 0x03U;
        size_t rx_off = 4U;
        int cmds_sent = 0;

        while (rx_off + 4U <= copy_len) {
            uint16_t req_sta_len = get_u16_le(&aligned_rx[rx_off]);
            uint16_t req_cmd_len = (uint16_t)(req_sta_len & 0x03FFU);
            if (req_cmd_len < 4U || rx_off + (size_t)req_cmd_len > copy_len) break;
            for (int iter = 0; iter < 12; ++iter) {
                uint8_t tx_frame[65];
                tx_frame[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
                bool enum_continue = false;
                size_t resp_len = process_sayo_v2_single_cmd(report_id, echo, &aligned_rx[rx_off],
                                                             copy_len - rx_off, &tx_frame[1], st,
                                                             ring, &enum_continue);
                queue_vendor_response(intr_fd, fallback_fd, st, tx_frame, resp_len + 1U);
                if (st->tx_fault) return;
                cmds_sent++;
                if (!enum_continue || st->enum_last_cmd == 0xFFU) break;
            }
            size_t req_step = ((size_t)req_cmd_len + 3U) & ~3U;
            if (req_step == 0U) break;
            rx_off += req_step;
        }

        if (cmds_sent == 0 && copy_len >= 8U) {
            uint8_t fallback_cmd[4] = {0x04U, 0x00U, aligned_rx[6], aligned_rx[7]};
            uint8_t tx_frame[65];
            tx_frame[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
            size_t resp_len = process_sayo_v2_single_cmd(report_id, echo, fallback_cmd, 4U,
                                                         &tx_frame[1], st, ring, NULL);
            queue_vendor_response(intr_fd, fallback_fd, st, tx_frame, resp_len + 1U);
        }
        return;
    }

    if (report_id == 0x02U && report_len >= 4U) {
        uint8_t tx_frame[65];
        tx_frame[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
        size_t resp_len = process_sayo_v1_packet(report_buf, report_len, &tx_frame[1], st, ring);
        queue_vendor_response(intr_fd, fallback_fd, st, tx_frame, resp_len + 1U);
        return;
    }

    update_host_leds(st, ring, report_buf[report_len - 1U]);
}

static size_t build_pnp_sdp_record(uint8_t *out, size_t max_len) {
    static const uint8_t k_pnp_body[] = {
        0x09U, 0x00U, 0x00U, 0x0AU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0x09U, 0x00U, 0x01U, 0x35U, 0x03U,
        0x19U, 0x12U, 0x00U, 0x09U, 0x00U, 0x04U, 0x35U, 0x0DU, 0x35U, 0x06U, 0x19U, 0x01U, 0x00U,
        0x09U, 0x00U, 0x01U, 0x35U, 0x03U, 0x19U, 0x00U, 0x01U, 0x09U, 0x00U, 0x05U, 0x35U, 0x03U,
        0x19U, 0x10U, 0x02U, 0x09U, 0x00U, 0x09U, 0x35U, 0x08U, 0x35U, 0x06U, 0x19U, 0x12U, 0x00U,
        0x09U, 0x01U, 0x03U, 0x09U, 0x02U, 0x00U, 0x09U, 0x01U, 0x03U, 0x09U, 0x02U, 0x01U, 0x09U,
        0x80U, 0x89U, 0x09U, 0x02U, 0x02U, 0x09U, 0x00U, 0x09U, 0x09U, 0x02U, 0x03U, 0x09U, 0x01U,
        0x00U, 0x09U, 0x02U, 0x04U, 0x28U, 0x01U, 0x09U, 0x02U, 0x05U, 0x09U, 0x00U, 0x02U};
    if (max_len < sizeof(k_pnp_body) + 2U) return 0U;
    out[0] = 0x35U;
    out[1] = (uint8_t)sizeof(k_pnp_body);
    memcpy(&out[2], k_pnp_body, sizeof(k_pnp_body));
    return sizeof(k_pnp_body) + 2U;
}

static size_t build_hid_sdp_record(uint8_t *out, size_t max_len) {
    static const uint8_t k_hid_prefix[] = {
        0x09U, 0x00U, 0x00U, 0x0AU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0x09U, 0x00U, 0x01U, 0x35U, 0x03U,
        0x19U, 0x11U, 0x24U, 0x09U, 0x00U, 0x04U, 0x35U, 0x0DU, 0x35U, 0x06U, 0x19U, 0x01U, 0x00U,
        0x09U, 0x00U, 0x11U, 0x35U, 0x03U, 0x19U, 0x00U, 0x11U, 0x09U, 0x00U, 0x05U, 0x35U, 0x03U,
        0x19U, 0x10U, 0x02U, 0x09U, 0x00U, 0x06U, 0x35U, 0x09U, 0x09U, 0x65U, 0x6EU, 0x09U, 0x00U,
        0x6AU, 0x09U, 0x01U, 0x00U, 0x09U, 0x00U, 0x09U, 0x35U, 0x08U, 0x35U, 0x06U, 0x19U, 0x11U,
        0x24U, 0x09U, 0x01U, 0x00U, 0x09U, 0x00U, 0x0DU, 0x35U, 0x0FU, 0x35U, 0x0DU, 0x35U, 0x06U,
        0x19U, 0x01U, 0x00U, 0x09U, 0x00U, 0x13U, 0x35U, 0x03U, 0x19U, 0x00U, 0x11U, 0x09U, 0x01U,
        0x00U, 0x25U, 0x19U, 'Y',   'a',   'n',   'd',   'e',   'x',   ' ',   'S',   'a',   'y',
        'o',   'D',   'e',   'v',   'i',   'c',   'e',   ' ',   'M',   'i',   'n',   'i',   ' ',
        '2',   0x00U, 0x09U, 0x02U, 0x00U, 0x09U, 0x01U, 0x00U, 0x09U, 0x02U, 0x01U, 0x09U, 0x01U,
        0x11U, 0x09U, 0x02U, 0x02U, 0x08U, 0x40U, 0x09U, 0x02U, 0x03U, 0x08U, 0x0DU, 0x09U, 0x02U,
        0x04U, 0x28U, 0x01U, 0x09U, 0x02U, 0x05U, 0x28U, 0x00U, 0x09U, 0x02U, 0x06U};

    static const uint8_t k_hid_suffix[] = {0x09U, 0x02U, 0x07U, 0x35U, 0x08U, 0x35U, 0x06U, 0x09U,
                                           0x04U, 0x09U, 0x09U, 0x01U, 0x00U, 0x09U, 0x02U, 0x0AU,
                                           0x28U, 0x01U, 0x09U, 0x02U, 0x0BU, 0x09U, 0x01U, 0x00U,
                                           0x09U, 0x02U, 0x0CU, 0x09U, 0x1FU, 0x40U, 0x09U, 0x02U,
                                           0x0DU, 0x28U, 0x01U, 0x09U, 0x02U, 0x0EU, 0x28U, 0x01U};

    size_t rdesc_len = sizeof(k_composite_hid_report_desc);
    size_t inner_seq_len = 2U + 2U + rdesc_len;
    size_t outer_seq_len = 2U + inner_seq_len;
    size_t body_len = sizeof(k_hid_prefix) + 2U + outer_seq_len + sizeof(k_hid_suffix);

    if (max_len < body_len + 3U) return 0U;

    size_t p = 0U;
    out[p++] = 0x36U;
    put_u16_be(&out[p], (uint16_t)body_len);
    p += 2U;

    memcpy(&out[p], k_hid_prefix, sizeof(k_hid_prefix));
    p += sizeof(k_hid_prefix);

    out[p++] = 0x35U;
    out[p++] = (uint8_t)outer_seq_len;
    out[p++] = 0x35U;
    out[p++] = (uint8_t)inner_seq_len;
    out[p++] = 0x08U;
    out[p++] = 0x22U;
    out[p++] = 0x25U;
    out[p++] = (uint8_t)rdesc_len;
    memcpy(&out[p], k_composite_hid_report_desc, rdesc_len);
    p += rdesc_len;

    memcpy(&out[p], k_hid_suffix, sizeof(k_hid_suffix));
    p += sizeof(k_hid_suffix);

    return p;
}

static bool sdp_transfer(int fd, uint8_t *data, size_t length, bool writing, uint64_t deadline_ms) {
    size_t done = 0U;
    while (done < length && !g_stop) {
        uint64_t now = monotonic_ms();
        if (now >= deadline_ms) return false;
        ssize_t n = writing ? send(fd, data + done, length - done, MSG_NOSIGNAL | MSG_DONTWAIT)
                            : recv(fd, data + done, length - done, MSG_DONTWAIT);
        if (n > 0) {
            done += (size_t)n;
            continue;
        }
        if (n == 0) return false;
        if (errno == EINTR) continue;
        if (errno != EAGAIN && errno != EWOULDBLOCK) return false;
        struct pollfd pfd = {fd, writing ? POLLOUT : POLLIN, 0};
        int ready = poll(&pfd, 1U, (int)(deadline_ms - now));
        if (ready < 0 && errno == EINTR) continue;
        if (ready <= 0 || !(pfd.revents & pfd.events)) return false;
    }
    return done == length;
}

static bool sdp_register_record_on_fd(int sdp_fd, uint16_t tid, const uint8_t *rec_pdu,
                                      size_t rec_len) {
    if (sdp_fd < 0 || rec_pdu == NULL || rec_len == 0U || rec_len > 900U) return false;
    uint8_t pkt[1024];
    uint16_t plen = (uint16_t)(1U + rec_len);
    pkt[0] = 0x75U;
    put_u16_be(&pkt[1], tid);
    put_u16_be(&pkt[3], plen);
    pkt[5] = 0x00U;
    memcpy(&pkt[6], rec_pdu, rec_len);

    uint64_t deadline = monotonic_ms() + 500ULL;
    uint8_t rsp[9];
    if (!sdp_transfer(sdp_fd, pkt, 6U + rec_len, true, deadline) ||
        !sdp_transfer(sdp_fd, rsp, 5U, false, deadline))
        return false;
    if (rsp[0] != 0x76U || rsp[1] != (uint8_t)(tid >> 8U) || rsp[2] != (uint8_t)tid ||
        rsp[3] != 0U || rsp[4] != 4U)
        return false;
    return sdp_transfer(sdp_fd, &rsp[5], 4U, false, deadline);
}

static int register_sayodevice_sdp_records(bool verbose) {
    int sdp_fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (sdp_fd < 0) return -1;

    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 500000;
    (void)setsockopt(sdp_fd, SOL_SOCKET, SO_RCVTIMEO, &tv, (socklen_t)sizeof(tv));
    (void)setsockopt(sdp_fd, SOL_SOCKET, SO_SNDTIMEO, &tv, (socklen_t)sizeof(tv));

    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    (void)snprintf(addr.sun_path, sizeof(addr.sun_path), "/var/run/sdp");

    if (connect(sdp_fd, (const struct sockaddr *)&addr, (socklen_t)sizeof(addr)) < 0) {
        (void)close(sdp_fd);
        return -1;
    }

    bool pnp_ok = (access(SAYO_BT_CONF_PATH, F_OK) == 0);
    if (!pnp_ok) {
        uint8_t pnp_rec[256];
        size_t pnp_len = build_pnp_sdp_record(pnp_rec, sizeof(pnp_rec));
        pnp_ok = (pnp_len > 0U) && sdp_register_record_on_fd(sdp_fd, 1U, pnp_rec, pnp_len);
        if (!pnp_ok) {
            (void)close(sdp_fd);
            return -1;
        }
    }

    uint8_t hid_rec[768];
    size_t hid_len = build_hid_sdp_record(hid_rec, sizeof(hid_rec));
    bool hid_ok = (hid_len > 0U) && sdp_register_record_on_fd(sdp_fd, 2U, hid_rec, hid_len);

    if (!hid_ok) {
        (void)close(sdp_fd);
        return -1;
    }

    if (verbose) {
        printf("[SDP] Registered SayoDevice Composite HID (0x1124) & PnP (%04X:%04X, pnp=%s)\n",
               (unsigned int)SAYO_VID, (unsigned int)SAYO_PID, pnp_ok ? "OK" : "CONF");
    }
    return sdp_fd;
}

static bool key_bit_is_set(const uint8_t *bits, size_t bits_len, uint32_t code) {
    size_t byte_idx = (size_t)(code / 8U);
    if (byte_idx >= bits_len) return false;
    return ((bits[byte_idx] & (uint8_t)(1U << (code % 8U))) != 0U);
}

static uint32_t map_event_to_button_bit(uint16_t code, int pad_role);

static uint32_t slot_buttons_from_bits(const input_slot_t *slot) {
    uint32_t buttons = 0U;
    for (unsigned code = 0; code <= KEY_MAX; ++code)
        if (key_bit_is_set(slot->key_bits, sizeof(slot->key_bits), code))
            buttons |= map_event_to_button_bit((uint16_t)code, slot->pad_role);
    return buttons;
}

static bool sync_input_slot(input_slot_t *slot) {
    uint8_t bits[sizeof(slot->key_bits)];
    memset(bits, 0, sizeof(bits));
    if (slot->fd < 0 || ioctl(slot->fd, EVIOCGKEY(sizeof(bits)), bits) < 0) return false;
    memcpy(slot->key_bits, bits, sizeof(bits));
    slot->buttons = slot_buttons_from_bits(slot);
    return true;
}

static uint32_t input_buttons(const input_set_t *iset) {
    uint32_t buttons = 0U;
    for (size_t i = 0; i < iset->count; ++i)
        if (iset->slots[i].fd >= 0) buttons |= iset->slots[i].buttons;
    return buttons;
}

static bool set_physical_buttons(keypad_state_t *st, uint32_t buttons) {
    bool minus = (buttons & BTN_BIT_MINUS) != 0U;
    bool center = (buttons & BTN_BIT_CENTER) != 0U;
    bool plus = (buttons & BTN_BIT_PLUS) != 0U;
    bool changed =
        st->pressed_minus != minus || st->pressed_center != center || st->pressed_plus != plus;
    st->pressed_minus = minus;
    st->pressed_center = center;
    st->pressed_plus = plus;
    return changed;
}

static bool sync_buttons_from_kernel_all(input_set_t *iset, keypad_state_t *st) {
    for (size_t i = 0; i < iset->count; ++i)
        if (!iset->slots[i].desynchronized) (void)sync_input_slot(&iset->slots[i]);
    return set_physical_buttons(st, input_buttons(iset));
}

static void reset_hid_session(keypad_state_t *st) {
    memset(&st->tx_input, 0, sizeof(st->tx_input));
    memset(&st->tx_control, 0, sizeof(st->tx_control));
    memset(&st->tx_vendor, 0, sizeof(st->tx_vendor));
    st->tx_fault = st->report_dirty = st->protocol_barrier = false;
    st->macro_q_head = st->macro_q_tail = 0U;
    st->macro_key_down = st->macro_tx_pending = false;
    memset(st->builtin_keys, 0, sizeof(st->builtin_keys));
    st->macro_held_mod = 0U;
    st->macro_wait_key = 0U;
    st->last_macro_ms = st->last_tx_ms = st->last_input_edge_ms = 0U;
    memset(st->last_kb_pkt, 0, sizeof(st->last_kb_pkt));
    st->last_kb_len = 0U;
    st->tgl_latch_mask = 0U;
    st->active_consumer_usage = st->queued_consumer_usage = 0U;
    st->active_mouse_btns = st->queued_mouse_btns = 0U;
    st->active_sysctrl_bits = st->queued_sysctrl_bits = 0U;
    st->enum_last_cmd = 0xFFU;
    st->enum_next_idx = 0U;
    st->save_reply_generation = 0U;
    memset(st->last_v1_resp, 0, sizeof(st->last_v1_resp));
    memset(st->last_v21_resp, 0, sizeof(st->last_v21_resp));
    st->last_v1_resp[0] = 0x02U;
    st->last_v21_resp[0] = 0x21U;
    st->host_leds = st->idle_rate = 0U;
    st->macro_enqueued_leds = 0U;
    st->peer_os = HOST_OS_UNKNOWN;
    st->has_peer_addr = false;
    st->cfg.cmd1f_data[7][0] = 0U;
    st->cfg.active_mode = 0U;
    st->protocol_mode = 1U;
    st->pressed_minus = st->pressed_center = st->pressed_plus = false;
    memset(st->key_press_ms, 0, sizeof(st->key_press_ms));
    memset(st->key_release_ms, 0, sizeof(st->key_release_ms));
}

static int send_hid_handshake(int ctrl_fd, keypad_state_t *st, uint8_t code) {
    uint8_t reply = (uint8_t)(HIDP_TRANS_HANDSHAKE | code);
    return send_control_packet(ctrl_fd, st, &reply, 1U);
}

static int handle_hid_get_report(int ctrl_fd, keypad_state_t *st, uint8_t param, const uint8_t *buf,
                                 size_t rx_len) {
    uint8_t rtype = (uint8_t)(param & HIDP_DATA_RTYPE_MASK);
    bool has_size = ((param & 0x08U) != 0U);
    size_t offset = 1U;
    uint8_t req_id = 0x01U;

    if (st->protocol_mode != 0U && rx_len > offset) {
        req_id = buf[offset];
        if (!has_size || rx_len >= 4U) offset++;
    }

    size_t max_payload = 65535U;
    if (has_size) {
        if (rx_len < offset + 2U)
            return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_ERR_INVALID_PARAM);
        max_payload = (size_t)buf[offset] | ((size_t)buf[offset + 1U] << 8U);
    }

    if (req_id == 0x22U || (req_id != 1U && req_id != 2U && req_id != 3U && req_id != 4U &&
                            req_id != 5U && req_id != 0x21U))
        return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_ERR_INVALID_REPORT);

    if ((req_id == 0x21U || req_id == 0x02U) && (st->save_pending || st->save_pid > 0))
        return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_NOT_READY);

    uint8_t reply[1032] = {0};
    size_t len = 0U;
    if (req_id == 0x21U || req_id == 0x02U) {
        reply[0] = (uint8_t)(HIDP_TRANS_DATA | rtype);
        memcpy(&reply[1], req_id == 0x21U ? st->last_v21_resp : st->last_v1_resp, 64U);
        len = 65U;
    } else if (req_id == 0x03U && rtype == HIDP_DATA_RTYPE_INPUT) {
        reply[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
        reply[1] = 0x03U;
        reply[2] = st->active_mouse_btns;
        len = 6U;
    } else if (req_id == 0x04U && rtype == HIDP_DATA_RTYPE_INPUT) {
        reply[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
        reply[1] = 0x04U;
        put_u16_le(&reply[2], st->active_consumer_usage);
        len = 4U;
    } else if (req_id == 0x05U && rtype == HIDP_DATA_RTYPE_INPUT) {
        reply[0] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT);
        reply[1] = 0x05U;
        reply[2] = st->active_sysctrl_bits;
        len = 3U;
    } else if (rtype == HIDP_DATA_RTYPE_INPUT) {
        len = build_hid_input_packet(st, reply);
    } else if (rtype == HIDP_DATA_RTYPE_OUTPUT) {
        reply[len++] = (uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_OUTPUT);
        if (st->protocol_mode != 0U) reply[len++] = 0x01U;
        reply[len++] = st->host_leds;
    } else {
        return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_ERR_INVALID_REPORT);
    }

    if (has_size && len > max_payload + 1U) len = max_payload + 1U;
    return send_control_packet(ctrl_fd, st, reply, len);
}

static int handle_hid_control_message(int ctrl_fd, int intr_fd, keypad_state_t *st,
                                      led_ring_t *ring) {
    uint8_t buf[2048];
    ssize_t n = recv(ctrl_fd, buf, sizeof(buf), MSG_DONTWAIT);
    if (n < 0)
        return (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) ? 0 : -1;
    if (n == 0) return -1;

    size_t rx_len = (size_t)n;
    uint8_t type = (uint8_t)(buf[0] & 0xF0U);
    uint8_t param = (uint8_t)(buf[0] & 0x0FU);

    switch (type) {
    case HIDP_TRANS_HANDSHAKE: return 0;
    case HIDP_TRANS_HID_CONTROL:
        return (param == HIDP_CTRL_VIRTUAL_CABLE_UNPLUG || param == HIDP_CTRL_HARD_RESET ||
                param == HIDP_CTRL_SOFT_RESET)
                   ? -1
                   : 0;
    case HIDP_TRANS_GET_REPORT:
        return handle_hid_get_report(ctrl_fd, st, param, buf, rx_len);
    case HIDP_TRANS_SET_REPORT: {
        uint8_t rtype = (uint8_t)(param & HIDP_DATA_RTYPE_MASK);
        if (st->protocol_mode != 0U && rx_len >= 2U && buf[1] == 0x22U)
            return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_ERR_INVALID_REPORT);
        if (rx_len < 2U)
            return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_ERR_INVALID_PARAM);
        if (rtype != HIDP_DATA_RTYPE_OUTPUT && rtype != HIDP_DATA_RTYPE_FEATURE)
            return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_ERR_INVALID_REPORT);
        if (send_hid_handshake(ctrl_fd, st, HIDP_HSHK_SUCCESSFUL) < 0) return -1;
        dispatch_incoming_output_report(&buf[1], rx_len - 1U, intr_fd, ctrl_fd, st, ring);
        return 0;
    }
    case HIDP_TRANS_GET_PROTOCOL: {
        if (rx_len != 1U) return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_ERR_INVALID_PARAM);
        uint8_t reply[2] = {(uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT), st->protocol_mode};
        return send_control_packet(ctrl_fd, st, reply, 2U);
    }
    case HIDP_TRANS_SET_PROTOCOL: {
        if (rx_len != 1U || (param != 0U && param != 1U))
            return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_ERR_INVALID_PARAM);
        if (st->tx_input.count != 0U || st->tx_vendor.count != 0U || st->macro_tx_pending ||
            st->protocol_barrier || st->active_consumer_usage || st->active_mouse_btns ||
            st->active_sysctrl_bits)
            return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_NOT_READY);
        st->protocol_mode = (uint8_t)(param & 0x01U);
        st->report_dirty = true;
        st->protocol_barrier = true;
        uint8_t reply = (uint8_t)(HIDP_TRANS_HANDSHAKE | HIDP_HSHK_SUCCESSFUL);
        if (queue_tx_packet(st, &st->tx_control, &reply, 1U, TX_PROTOCOL, MACRO_TX_NONE, false) < 0)
            return -1;
        return flush_tx_queue(ctrl_fd, st, &st->tx_control, TX_CONTROL_MAX_AGE_MS, 4U);
    }
    case HIDP_TRANS_GET_IDLE: {
        if (rx_len != 1U) return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_ERR_INVALID_PARAM);
        uint8_t reply[2] = {(uint8_t)(HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT), st->idle_rate};
        return send_control_packet(ctrl_fd, st, reply, 2U);
    }
    case HIDP_TRANS_SET_IDLE:
        if (rx_len != 2U) return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_ERR_INVALID_PARAM);
        st->idle_rate = buf[1];
        return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_SUCCESSFUL);
    case HIDP_TRANS_DATA: {
        uint8_t rtype = (uint8_t)(param & HIDP_DATA_RTYPE_MASK);
        if ((rtype == HIDP_DATA_RTYPE_OUTPUT || rtype == HIDP_DATA_RTYPE_FEATURE) && rx_len >= 2U)
            dispatch_incoming_output_report(&buf[1], rx_len - 1U, intr_fd, ctrl_fd, st, ring);
        return 0;
    }
    default:
        return send_hid_handshake(ctrl_fd, st, HIDP_HSHK_ERR_UNSUPPORTED);
    }
}

static int set_fd_nonblock_cloexec(int fd) {
    if (fd < 0) {
        errno = EBADF;
        return -1;
    }
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) return -1;
    int fd_flags = fcntl(fd, F_GETFD, 0);
    if (fd_flags < 0 || fcntl(fd, F_SETFD, fd_flags | FD_CLOEXEC) < 0) return -1;
    return 0;
}

static int tune_l2cap_socket_mtu_and_qos(int fd) {
    if (fd < 0) {
        errno = EBADF;
        return -1;
    }

    struct timeval send_timeout = {.tv_sec = 0, .tv_usec = 10000};
    if (setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &send_timeout, sizeof(send_timeout)) < 0) return -1;

    int sndbuf = 8192, rcvbuf = 65536, priority = 6;
    if (setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf)) < 0 ||
        setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf)) < 0 ||
        setsockopt(fd, SOL_SOCKET, SO_PRIORITY, &priority, sizeof(priority)) < 0)
        fprintf(stderr, "[Bluetooth] Socket tuning incomplete: %s\n", strerror(errno));
    socklen_t length = sizeof(sndbuf);
    if (getsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, &length) < 0)
        fprintf(stderr, "[Bluetooth] Cannot verify transmit buffer: %s\n", strerror(errno));

    uint8_t force_active = 1U;
    if (setsockopt(fd, 274, 9, &force_active, sizeof(force_active)) < 0) {
        fprintf(stderr, "[Bluetooth] Cannot request active mode: %s\n", strerror(errno));
    } else {
        length = sizeof(force_active);
        if (getsockopt(fd, 274, 9, &force_active, &length) < 0 || force_active != 1U)
            fprintf(stderr, "[Bluetooth] Active-mode option not verified\n");
    }
    return 0;
}

static int create_l2cap_listener(uint16_t psm) {
    int fd = socket(PF_BLUETOOTH, SOCK_SEQPACKET | SOCK_NONBLOCK | SOCK_CLOEXEC, BTPROTO_L2CAP);
    if (fd < 0) {
        perror("socket(PF_BLUETOOTH, BTPROTO_L2CAP)");
        return -1;
    }
    if (set_fd_nonblock_cloexec(fd) < 0 || tune_l2cap_socket_mtu_and_qos(fd) < 0) {
        (void)close(fd);
        return -1;
    }

    int opt = 1;
    (void)setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &opt, (socklen_t)sizeof(opt));

    struct sockaddr_l2 addr;
    memset(&addr, 0, sizeof(addr));
    addr.l2_family = AF_BLUETOOTH;
    addr.l2_psm = u16_to_le(psm);

    if (bind(fd, (const struct sockaddr *)&addr, (socklen_t)sizeof(addr)) < 0) {
        fprintf(stderr, "bind(L2CAP PSM 0x%04x) failed: %s\n", (unsigned int)psm, strerror(errno));
        (void)close(fd);
        return -1;
    }

    if (listen(fd, 1) < 0) {
        perror("listen(L2CAP)");
        (void)close(fd);
        return -1;
    }
    return fd;
}

static bool find_active_acl_peer(bdaddr_t *out_peer) {
    int hci_fd = socket(PF_BLUETOOTH, SOCK_RAW | SOCK_CLOEXEC, BTPROTO_HCI);
    if (hci_fd < 0) return false;
    struct local_hci_conn_list_req cl;
    memset(&cl, 0, sizeof(cl));
    cl.dev_id = 0U;
    cl.conn_num = 8U;
    if (ioctl(hci_fd, HCIGETCONNLIST, &cl) < 0) {
        (void)close(hci_fd);
        return false;
    }
    (void)close(hci_fd);

    uint16_t count = (cl.conn_num <= 8U) ? cl.conn_num : 8U;
    for (uint16_t i = 0U; i < count; ++i) {
        if (cl.conn_info[i].type == 1U && cl.conn_info[i].state == 1U) {
            *out_peer = cl.conn_info[i].bdaddr;
            return true;
        }
    }
    return false;
}

static int infer_pad_role_from_name(const char *dev_name) {
    if (dev_name == NULL) return -1;
    if (strstr(dev_name, "pad0") != NULL) return 0;
    if (strstr(dev_name, "pad1") != NULL) return 1;
    if (strstr(dev_name, "pad2") != NULL) return 2;
    return -1;
}

static bool is_relevant_touch_device(int fd, const char *dev_name) {
    if (dev_name != NULL && strstr(dev_name, "Headphones") != NULL) return false;
    if (dev_name != NULL &&
        (strstr(dev_name, "sar0_pad") != NULL || strstr(dev_name, "cy8cmbr") != NULL ||
         strstr(dev_name, "aw9610") != NULL)) {
        return true;
    }

    uint8_t key_caps[(KEY_MAX / 8U) + 1U];
    memset(key_caps, 0, sizeof(key_caps));
    if (ioctl(fd, EVIOCGBIT(EV_KEY, sizeof(key_caps)), key_caps) >= 0) {
        if (key_bit_is_set(key_caps, sizeof(key_caps), KEY_VOLUMEDOWN) ||
            key_bit_is_set(key_caps, sizeof(key_caps), KEY_VOICECOMMAND) ||
            key_bit_is_set(key_caps, sizeof(key_caps), KEY_VOLUMEUP)) {
            return true;
        }
    }
    return false;
}

static bool copy_slot_path(char dst[128], const char *src) {
    if (src == NULL) return false;
    size_t slen = strlen(src);
    if (slen == 0U || slen >= 128U) return false;
    memcpy(dst, src, slen + 1U);
    return true;
}

static int open_and_configure_slot(input_slot_t *slot, bool filter_relevance) {
    slot->grabbed = false;
    slot->desynchronized = slot->monotonic_clock = false;
    slot->buttons = 0U;
    memset(slot->key_bits, 0, sizeof(slot->key_bits));
    int fd = open(slot->path, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) {
        slot->fd = -1;
        return -1;
    }
    if (set_fd_nonblock_cloexec(fd) < 0) {
        (void)close(fd);
        slot->fd = -1;
        return -1;
    }

    memset(slot->name, 0, sizeof(slot->name));
    if (ioctl(fd, EVIOCGNAME(sizeof(slot->name) - 1U), slot->name) < 0)
        (void)snprintf(slot->name, sizeof(slot->name), "Unknown");
    slot->name[sizeof(slot->name) - 1U] = '\0';

    if (filter_relevance && !is_relevant_touch_device(fd, slot->name)) {
        (void)close(fd);
        slot->fd = -1;
        return -1;
    }

    slot->pad_role = infer_pad_role_from_name(slot->name);

#ifdef EVIOCSCLOCKID
    int clk_id = CLOCK_MONOTONIC;
    slot->monotonic_clock = ioctl(fd, EVIOCSCLOCKID, &clk_id) == 0;
#endif

    uint32_t ev_mask_bits = (1U << EV_SYN) | (1U << EV_KEY);
#ifdef EVIOCSMASK
    struct input_mask mask_req;
    memset(&mask_req, 0, sizeof(mask_req));
    mask_req.type = EV_SYN;
    mask_req.codes_size = sizeof(ev_mask_bits);
    mask_req.codes_ptr = (uintptr_t)&ev_mask_bits;
    (void)ioctl(fd, EVIOCSMASK, &mask_req);
#else
    struct local_input_mask mask_req;
    memset(&mask_req, 0, sizeof(mask_req));
    mask_req.type = EV_SYN;
    mask_req.codes_size = sizeof(ev_mask_bits);
    mask_req.codes_ptr = (uint64_t)(uintptr_t)&ev_mask_bits;
    (void)ioctl(fd, LOCAL_EVIOCSMASK, &mask_req);
#endif

    if (ioctl(fd, EVIOCGRAB, 1) == 0) slot->grabbed = true;

    slot->fd = fd;
    return fd;
}

static void close_input_slot(input_slot_t *slot) {
    slot->buttons = 0U;
    slot->desynchronized = false;
    memset(slot->key_bits, 0, sizeof(slot->key_bits));
    if (slot->fd >= 0) {
        if (slot->grabbed) {
            (void)ioctl(slot->fd, EVIOCGRAB, 0);
            slot->grabbed = false;
        }
        (void)close(slot->fd);
        slot->fd = -1;
    }
}

static void close_all_input_slots(input_set_t *iset) {
    for (size_t i = 0U; i < iset->count; ++i) close_input_slot(&iset->slots[i]);
}

static size_t init_input_set(input_set_t *iset, const char *input_arg, keypad_state_t *st) {
    memset(iset, 0, sizeof(*iset));
    for (size_t i = 0U; i < MAX_INPUT_DEVS; ++i) {
        iset->slots[i].fd = -1;
        iset->slots[i].pad_role = -1;
    }

    bool use_auto = (input_arg == NULL || *input_arg == '\0' || strcmp(input_arg, "auto") == 0 ||
                     strcmp(input_arg, "/dev/input/event0") == 0);

    iset->auto_scan = use_auto;
    size_t opened_count = 0U;

    if (use_auto) {
        for (unsigned int idx = 0U; idx < (unsigned int)MAX_INPUT_DEVS; ++idx) {
            if (iset->count >= (size_t)MAX_INPUT_DEVS) break;
            input_slot_t *slot = &iset->slots[iset->count];
            (void)snprintf(slot->path, sizeof(slot->path), "/dev/input/event%u", idx);
            if (open_and_configure_slot(slot, true) >= 0) {
                iset->count++;
                opened_count++;
            }
        }
        if (opened_count == 0U && input_arg != NULL && strcmp(input_arg, "auto") != 0) {
            input_slot_t *slot = &iset->slots[0];
            if (copy_slot_path(slot->path, input_arg) &&
                open_and_configure_slot(slot, false) >= 0) {
                iset->count = 1U;
                opened_count = 1U;
            }
        }
    } else {
        char buf[512];
        size_t len = strlen(input_arg);
        if (len >= sizeof(buf)) len = sizeof(buf) - 1U;
        memcpy(buf, input_arg, len);
        buf[len] = '\0';

        char *cursor = buf;
        while (cursor != NULL && *cursor != '\0' && iset->count < (size_t)MAX_INPUT_DEVS) {
            char *comma = strchr(cursor, ',');
            if (comma != NULL) *comma = '\0';
            if (*cursor != '\0') {
                input_slot_t *slot = &iset->slots[iset->count];
                if (copy_slot_path(slot->path, cursor)) {
                    if (open_and_configure_slot(slot, false) >= 0) opened_count++;
                    iset->count++;
                }
            }
            cursor = (comma != NULL) ? (comma + 1) : NULL;
        }
    }

    (void)sync_buttons_from_kernel_all(iset, st);
    return opened_count;
}

static bool any_input_slot_closed(const input_set_t *iset) {
    if (iset->count == 0U) return true;
    for (size_t i = 0U; i < iset->count; ++i)
        if (iset->slots[i].fd < 0) return true;
    return false;
}

static void reopen_closed_input_slots(input_set_t *iset, keypad_state_t *st) {
    bool reopened = false;
    if (iset->auto_scan) {
        for (unsigned idx = 0; idx < MAX_INPUT_DEVS; ++idx) {
            char path[128];
            (void)snprintf(path, sizeof(path), "/dev/input/event%u", idx);
            bool present = false;
            size_t available = iset->count;
            for (size_t i = 0; i < iset->count; ++i) {
                if (iset->slots[i].fd >= 0 && strcmp(iset->slots[i].path, path) == 0)
                    present = true;
                if (iset->slots[i].fd < 0 && available == iset->count) available = i;
            }
            if (present || available >= MAX_INPUT_DEVS) continue;
            input_slot_t *slot = &iset->slots[available];
            (void)copy_slot_path(slot->path, path);
            if (open_and_configure_slot(slot, true) >= 0) {
                if (available == iset->count) iset->count++;
                (void)sync_input_slot(slot);
                reopened = true;
            }
        }
    } else {
        for (size_t i = 0; i < iset->count; ++i) {
            input_slot_t *slot = &iset->slots[i];
            if (slot->fd < 0 && open_and_configure_slot(slot, true) >= 0) {
                (void)sync_input_slot(slot);
                reopened = true;
            }
        }
    }
    if (reopened && set_physical_buttons(st, input_buttons(iset))) st->report_dirty = true;
}

static void format_bdaddr(const bdaddr_t *ba, char out[18]) {
    (void)snprintf(out, 18U, "%02X:%02X:%02X:%02X:%02X:%02X", (unsigned int)ba->b[5],
                   (unsigned int)ba->b[4], (unsigned int)ba->b[3], (unsigned int)ba->b[2],
                   (unsigned int)ba->b[1], (unsigned int)ba->b[0]);
}

static void release_all_keys_if_connected(int intr_fd, keypad_state_t *st) {
    st->pressed_minus = st->pressed_center = st->pressed_plus = false;
    st->tgl_latch_mask = 0U;
    memset(st->builtin_keys, 0, sizeof(st->builtin_keys));
    st->macro_key_down = false;
    if (intr_fd >= 0) (void)send_hid_input_report(intr_fd, st);
}

static void disconnect_active_peer(const char *reason, int *conn_ctrl, int *conn_intr,
                                   bool *has_ctrl_peer, bool *is_connected, keypad_state_t *st,
                                   led_ring_t *ring, uint64_t *last_anim_ms,
                                   uint64_t *last_piscan_ms) {
    if (reason != NULL) {
        printf("[Bluetooth] %s\n", reason);
        (void)fflush(stdout);
    }
    close_fd_if_open(conn_intr);
    close_fd_if_open(conn_ctrl);
    *has_ctrl_peer = *is_connected = false;
    reset_hid_session(st);
    ensure_hci0_piscan();
    *last_piscan_ms = *last_anim_ms = monotonic_ms();
    led_ring_step_searching_blue(ring);
}

static uint32_t map_event_to_button_bit(uint16_t code, int pad_role) {
    if (code == KEY_VOLUMEDOWN) return BTN_BIT_MINUS;
    if (code == KEY_VOICECOMMAND) return BTN_BIT_CENTER;
    if (code == KEY_VOLUMEUP) return BTN_BIT_PLUS;
    if (pad_role >= 0 && pad_role <= 2) return 1U << (unsigned)pad_role;
    return 0U;
}

static const uint8_t k_us_hid_usage[96] = {
    0x2c, 0x1e, 0x34, 0x20, 0x21, 0x22, 0x24, 0x34, 0x26, 0x27, 0x25, 0x2e, 0x36, 0x2d, 0x37, 0x38,
    0x27, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x33, 0x33, 0x36, 0x2e, 0x37, 0x38,
    0x1f, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12,
    0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x2f, 0x31, 0x30, 0x23, 0x2d,
    0x35, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12,
    0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x2f, 0x31, 0x30, 0x35, 0x28};

static const uint8_t k_us_hid_mod[96] = {
    0x00, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x00, 0x02, 0x02, 0x02, 0x02, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x02,
    0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02,
    0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x00, 0x00, 0x00, 0x02, 0x02,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x02, 0x02, 0x02, 0x00};

static bool ascii_char_to_hid(uint16_t ch, uint8_t *out_mod, uint8_t *out_usage) {
    *out_mod = *out_usage = 0U;
    if (ch == '\n' || ch == '\r') {
        *out_usage = 0x28U;
        return true;
    }
    if (ch == '\b') {
        *out_usage = 0x2AU;
        return true;
    }
    if (ch == '\t') {
        *out_usage = 0x2BU;
        return true;
    }
    if (ch >= 0x20U && ch <= 0x7EU) {
        size_t idx = (size_t)(ch - 0x20U);
        *out_mod = k_us_hid_mod[idx];
        *out_usage = k_us_hid_usage[idx];
        return true;
    }
    return false;
}

static uint8_t parse_bluez_info_os(const char *buf) {
    const char *did = strstr(buf, "[DeviceID]");
    if (did != NULL) {
        const char *v = strstr(did, "Vendor=");
        if (v != NULL) {
            unsigned long vendor = strtoul(v + 7, NULL, 0);
            if (vendor == 76UL || vendor == 1452UL || vendor == 0x004CUL || vendor == 0x05ACUL)
                return HOST_OS_APPLE;
            if (vendor == 6UL || vendor == 1118UL || vendor == 0x0006UL || vendor == 0x045EUL)
                return HOST_OS_WINDOWS;
            if (vendor == 7531UL || vendor == 0x1D6BUL) return HOST_OS_LINUX;
            if (vendor == 224UL || vendor == 6353UL || vendor == 0x00E0UL || vendor == 0x18D1UL)
                return HOST_OS_ANDROID;
        }
    }
    if (strstr(buf, "00000000-deca-fade-deca-deafdecacaff") != NULL ||
        strstr(buf, "MacBook") != NULL || strstr(buf, "iMac") != NULL || strstr(buf, "Mac ") != NULL)
        return HOST_OS_APPLE;
    if (strstr(buf, "Windows") != NULL || strstr(buf, "DESKTOP-") != NULL ||
        strstr(buf, "LAPTOP-") != NULL)
        return HOST_OS_WINDOWS;
    if (strstr(buf, "BlueZ") != NULL || strstr(buf, "Linux") != NULL) return HOST_OS_LINUX;
    if (strstr(buf, "Android") != NULL) return HOST_OS_ANDROID;
    return HOST_OS_UNKNOWN;
}

static uint8_t detect_peer_host_os(keypad_state_t *st) {
    if (!st->has_peer_addr) return st->peer_os;
    char adapter_str[18], peer_str[18], path[160], buf[2048];
    format_bdaddr(&st->local_addr, adapter_str);
    format_bdaddr(&st->peer_addr, peer_str);
    (void)snprintf(path, sizeof(path), "/data/bluez_data/lib/bluetooth/%s/%s/info", adapter_str,
                   peer_str);
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return st->peer_os;
    ssize_t n = read(fd, buf, sizeof(buf) - 1U);
    (void)close(fd);
    if (n > 0) {
        buf[n] = '\0';
        uint8_t detected = parse_bluez_info_os(buf);
        if (detected != HOST_OS_UNKNOWN) st->peer_os = detected;
    }
    return st->peer_os;
}

static bool ordinary_keyboard_held(const keypad_state_t *st) {
    uint8_t keys[6], mods;
    size_t count = collect_keyboard_keys(st, keys, &mods);
    return mods != 0U || count != 0U;
}

static bool macro_waiting_for_release(const keypad_state_t *st) {
    if (st->macro_wait_key == 0U || st->macro_wait_key > SAYO_KEY_COUNT) return false;
    bool pressed[SAYO_KEY_COUNT];
    compute_effective_button_states(st, pressed);
    return pressed[st->macro_wait_key - 1U];
}

static uint8_t hex_nibble_to_hid_usage(unsigned hex) {
    return (uint8_t)(hex == 0U ? 0x27U : hex < 10U ? 0x1DU + hex : 0x04U + hex - 10U);
}

static bool enqueue_string_content_to_macro(keypad_state_t *st, const uint8_t *buf, uint8_t enc,
                                            uint8_t trailing_usage, uint16_t step_ms) {
    if (st->macro_q_head < st->macro_q_tail || st->macro_tx_pending || st->macro_key_down ||
        ordinary_keyboard_held(st)) {
        fprintf(stderr, "[Macro] busy or an ordinary key is held; trigger rejected\n");
        return false;
    }
    if (enc != 2U && enc != 3U) return false;
    if (st->peer_os == HOST_OS_UNKNOWN && st->has_peer_addr) (void)detect_peer_host_os(st);
    uint8_t layout_opt = st->cfg.opt_bytes[16];
    uint16_t pace = (step_ms >= 2U && step_ms <= 250U) ? step_ms : (uint16_t)MACRO_DEFAULT_STEP_MS;
    text_keystroke_t prepared[MACRO_QUEUE_CAP];
    size_t count = 0U;
    uint8_t restore_lock_usage = 0U;
    for (size_t i = 0U; i < 56U; i += enc == 3U ? 2U : 1U) {
        uint16_t units[2] = {enc == 3U ? get_u16_le(&buf[i]) : buf[i], 0U};
        size_t unit_count = 1U;
        uint16_t ch = units[0];
        if (ch == 0U) break;

        if (enc == 2U && ch >= 0x80U) goto invalid_text;
        if (ch >= 0xD800U && ch <= 0xDBFFU) {
            if (enc != 3U || i + 3U >= 56U) goto invalid_text;
            units[1] = get_u16_le(&buf[i + 2U]);
            if (units[1] < 0xDC00U || units[1] > 0xDFFFU) goto invalid_text;
            unit_count = 2U;
            i += 2U;
        } else if (ch >= 0xDC00U && ch <= 0xDFFFU)
            goto invalid_text;

        uint32_t cp = unit_count == 2U
                          ? (0x10000U + (((uint32_t)(units[0] - 0xD800U) << 10U) |
                                         (uint32_t)(units[1] - 0xDC00U)))
                          : (uint32_t)ch;
        bool macos_hex = (st->text_macos_hex || layout_opt == 4U) && ch >= 0x20U && ch != 0x7FU;
        bool win_numpad = !macos_hex &&
                          (layout_opt == 2U ||
                           (layout_opt == 0U && enc == 3U && st->peer_os == HOST_OS_WINDOWS)) &&
                          ch >= 0x20U && ch != 0x7FU;
        bool linux_hex = !macos_hex && !win_numpad &&
                         (layout_opt == 3U ||
                          (layout_opt == 0U && enc == 3U &&
                           (st->peer_os == HOST_OS_LINUX || st->peer_os == HOST_OS_ANDROID))) &&
                         ch >= 0x20U && ch != 0x7FU;

        if (macos_hex) {
            if ((st->host_leds & 2U) != 0U && restore_lock_usage == 0U) {
                if (count + 2U > MACRO_QUEUE_CAP) return false;
                prepared[count++] = (text_keystroke_t){0U, 0x39U, 0U, pace, pace, 0U};
                restore_lock_usage = 0x39U;
            }
            if (count + 1U + unit_count * 4U + (restore_lock_usage != 0U ? 1U : 0U) >
                MACRO_QUEUE_CAP)
                return false;
            prepared[count++] =
                (text_keystroke_t){0x04U, 0U, 0x04U, MACOS_UNICODE_START_MS, 0U, 0U};
            for (size_t unit = 0U; unit < unit_count; ++unit) {
                for (unsigned nibble = 0U; nibble < 4U; ++nibble) {
                    unsigned hex = (units[unit] >> ((3U - nibble) * 4U)) & 15U;
                    uint8_t usage = hex_nibble_to_hid_usage(hex);
                    bool last = unit + 1U == unit_count && nibble == 3U;
                    prepared[count++] =
                        (text_keystroke_t){0x04U, usage, last ? 0U : 0x04U, pace, pace, 0U};
                }
            }
        } else if (win_numpad) {
            if ((st->host_leds & 1U) == 0U && restore_lock_usage == 0U) {
                if (count + 2U > MACRO_QUEUE_CAP) return false;
                prepared[count++] = (text_keystroke_t){0U, 0x53U, 0U, pace, pace, 0U};
                restore_lock_usage = 0x53U;
            }
            uint8_t dec_usages[8];
            size_t dec_len = 0U;
            uint32_t tmp = cp;
            do {
                uint8_t d = (uint8_t)(tmp % 10U);
                dec_usages[dec_len++] = (d == 0U) ? 0x62U : (uint8_t)(0x58U + d);
                tmp /= 10U;
            } while (tmp > 0U);
            if (cp < 0x100U) dec_usages[dec_len++] = 0x62U;
            if (count + 1U + dec_len + (restore_lock_usage != 0U ? 1U : 0U) > MACRO_QUEUE_CAP)
                return false;
            prepared[count++] =
                (text_keystroke_t){0x04U, 0U, 0x04U, MACOS_UNICODE_START_MS, 0U, 0U};
            for (size_t d_idx = dec_len; d_idx > 0U; --d_idx) {
                bool last = (d_idx == 1U);
                prepared[count++] = (text_keystroke_t){
                    0x04U, dec_usages[d_idx - 1U], last ? 0U : 0x04U, pace, pace, 0U};
            }
        } else if (linux_hex) {
            if ((st->host_leds & 2U) != 0U && restore_lock_usage == 0U) {
                if (count + 2U > MACRO_QUEUE_CAP) return false;
                prepared[count++] = (text_keystroke_t){0U, 0x39U, 0U, pace, pace, 0U};
                restore_lock_usage = 0x39U;
            }
            uint8_t hex_usages[6];
            size_t hex_len = 0U;
            uint32_t tmp = cp;
            do {
                hex_usages[hex_len++] = hex_nibble_to_hid_usage((unsigned)(tmp & 15U));
                tmp >>= 4U;
            } while (tmp > 0U);
            if (count + 2U + hex_len + (restore_lock_usage != 0U ? 1U : 0U) > MACRO_QUEUE_CAP)
                return false;
            prepared[count++] = (text_keystroke_t){0x03U, 0x18U, 0U, pace, pace, 0U};
            for (size_t h_idx = hex_len; h_idx > 0U; --h_idx)
                prepared[count++] =
                    (text_keystroke_t){0U, hex_usages[h_idx - 1U], 0U, pace, pace, 0U};
            prepared[count++] = (text_keystroke_t){0U, 0x28U, 0U, pace, pace, 0U};
        } else {
            uint8_t mod = 0U, usage = 0U;
            if (unit_count != 1U || !ascii_char_to_hid(ch, &mod, &usage)) goto invalid_text;
            if (count + (restore_lock_usage != 0U ? 1U : 0U) >= MACRO_QUEUE_CAP) return false;
            bool is_alpha = (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z');
            uint8_t caps_inv = (is_alpha && restore_lock_usage == 0U) ? 1U : 0U;
            if (caps_inv != 0U && (st->host_leds & 2U) != 0U) mod ^= 0x02U;
            prepared[count++] = (text_keystroke_t){mod, usage, 0U, pace, pace, caps_inv};
        }
    }
    if (trailing_usage != 0U) {
        if (count + (restore_lock_usage != 0U ? 1U : 0U) >= MACRO_QUEUE_CAP) return false;
        prepared[count++] = (text_keystroke_t){0U, trailing_usage, 0U, pace, pace, 0U};
    }
    if (restore_lock_usage != 0U) {
        if (count >= MACRO_QUEUE_CAP) return false;
        prepared[count++] = (text_keystroke_t){0U, restore_lock_usage, 0U, pace, pace, 0U};
    }
    memcpy(st->macro_q, prepared, count * sizeof(prepared[0]));
    st->macro_q_head = 0U;
    st->macro_q_tail = count;
    st->macro_step_ms = pace;
    st->macro_wait_key = 0U;
    st->macro_enqueued_leds = st->host_leds;
    st->last_macro_ms = 0U;
    return true;

invalid_text:
    fprintf(stderr, "[Macro] text cannot be represented in the selected mode; no text sent\n");
    return false;
}

static int step_macro_typing_if_needed(int intr_fd, keypad_state_t *st) {
    if (intr_fd < 0 || st->macro_tx_pending || st->tx_input.count > 0U) return 0;
    if (st->macro_q_head >= st->macro_q_tail && !st->macro_key_down) return 0;
    if (macro_waiting_for_release(st)) return 0;
    st->macro_wait_key = 0U;
    if (!st->macro_key_down && ordinary_keyboard_held(st)) return 0;
    uint64_t now = monotonic_ms();
    if (st->last_macro_ms != 0ULL && now - st->last_macro_ms < st->macro_step_ms) return 0;
    const text_keystroke_t *key = &st->macro_q[st->macro_q_head];
    st->macro_key_down = !st->macro_key_down;
    st->macro_step_ms = st->macro_key_down ? key->down_ms : key->up_ms;
    st->macro_held_mod = st->macro_key_down ? 0U : key->release_mod;
    st->macro_tx_pending = true;
    return submit_hid_input_report(intr_fd, st, st->macro_key_down ? MACRO_TX_DOWN : MACRO_TX_UP);
}

enum builtin_op {
    B_END = 0,
    B_SLEEP = 6,
    B_SLEEP_REG = 10,
    B_MOD_DOWN = 20,
    B_KEY_DOWN = 21,
    B_MEDIA_DOWN = 23,
    B_MOD_UP = 28,
    B_KEY_UP = 29,
    B_MEDIA_UP = 31,
    B_JUMP_ZERO_REG = 74,
    B_JUMP_NONZERO_REG = 75,
    B_DECREMENT_JUMP_REG = 76,
    B_JUMP_ZERO = 80,
    B_DECREMENT_JUMP = 82,
    B_AND_REG = 86,
    B_AND = 87,
    B_OR_ACC = 92,
    B_NOT = 105,
    B_MOVE = 110,
    B_MOVE_IMMEDIATE = 111,
    B_REPORT_BARRIER = 244,
    B_SAVE_PC = 246,
    B_JOG = 248,
    B_WAIT_PRESS = 249,
    B_WAIT_RELEASE = 250,
    B_EXIT = 255
};
enum { B_REG_KEY_IO = 10, B_REG_ACC = 16, B_REG_HOST_LEDS = 20, B_INSTRUCTION_BUDGET = 64 };

static const uint8_t builtin_default[] = {0xf8, 0x50, 0x00, 0x00, 0x0d, 0x14, 0x00, 0x06,
                                          0x14, 0x50, 0x01, 0x00, 0x11, 0x15, 0x01, 0x06,
                                          0x14, 0xfa, 0x1c, 0x00, 0x1d, 0x01, 0xff};
static const uint8_t builtin_media[] = {0xf8, 0x17, 0x00, 0xfa, 0x1f, 0x00, 0xf4, 0x50,
                                        0x01, 0x00, 0x0f, 0x52, 0x01, 0x00, 0x00, 0xff};
static const uint8_t builtin_short_long[] = {
    0x6f, 0x10, 0x3c, 0xf6, 0x04, 0x06, 0x05, 0x4b, 0x0a, 0x05, 0x4c, 0x10, 0x04,
    0x4a, 0x02, 0x06, 0x14, 0x02, 0x06, 0x14, 0xf6, 0x06, 0x15, 0x03, 0x06, 0x14,
    0xfa, 0x1c, 0x02, 0x1d, 0x03, 0xff, 0xf6, 0x05, 0x4a, 0x00, 0x07, 0x14, 0x00,
    0x06, 0x14, 0xf6, 0x07, 0x15, 0x01, 0x06, 0x32, 0x1c, 0x00, 0x1d, 0x01, 0xff};
static const uint8_t builtin_media_short_long[] = {
    0x6f, 0x10, 0x3c, 0xf6, 0x02, 0x06, 0x05, 0x4b, 0x0a, 0x03, 0x4c, 0x10, 0x02, 0x17, 0x01,
    0x06, 0x1e, 0x1f, 0x01, 0xff, 0xf6, 0x03, 0x17, 0x00, 0x06, 0x14, 0xfa, 0x1f, 0x00, 0xff};
static const uint8_t builtin_press_release[] = {
    0xf8, 0x4a, 0x00, 0x04, 0x14, 0x00, 0x06, 0x14, 0xf6, 0x04, 0x15, 0x01, 0x06,
    0x1e, 0x1c, 0x00, 0x1d, 0x01, 0x06, 0x14, 0xfa, 0x4a, 0x02, 0x06, 0x14, 0x02,
    0x06, 0x14, 0xf6, 0x06, 0x15, 0x03, 0x06, 0x1e, 0x1c, 0x02, 0x1d, 0x03, 0xff};
static const uint8_t builtin_led_lock[] = {
    0xf8, 0x6e, 0x10, 0x14, 0x5c, 0x02, 0x6e, 0x14, 0x10, 0x06, 0x14, 0x6e, 0x14, 0x10,
    0x06, 0x14, 0x4a, 0x00, 0x04, 0x14, 0x00, 0x06, 0x14, 0x4a, 0x01, 0x05, 0xf6, 0x04,
    0x15, 0x01, 0x06, 0x14, 0xf6, 0x05, 0xfa, 0x1c, 0x00, 0x1d, 0x01, 0x06, 0x14, 0x69,
    0x03, 0x56, 0x03, 0x14, 0x6e, 0x14, 0x03, 0x06, 0x14, 0x6e, 0x14, 0x03, 0xff};
static const uint8_t builtin_four[] = {0x15, 0x00, 0x06, 0x1e, 0x15, 0x01, 0x06, 0x1e, 0x15,
                                       0x02, 0x06, 0x1e, 0x15, 0x03, 0x06, 0x1e, 0x1d, 0x00,
                                       0x1d, 0x01, 0x1d, 0x02, 0x1d, 0x03, 0xff};
static const uint8_t builtin_loop[] = {0x15, 0x00, 0x0a, 0x03, 0x1d, 0x00, 0x0a, 0x03, 0x15, 0x01,
                                       0x0a, 0x03, 0x1d, 0x01, 0x0a, 0x03, 0x15, 0x02, 0x0a, 0x03,
                                       0x1d, 0x02, 0x0a, 0x03, 0x50, 0x0a, 0x00, 0x00, 0xff};
static const uint8_t builtin_numlock[] = {
    0x6e, 0x04, 0x14, 0x57, 0x04, 0x01, 0x50, 0x04, 0x00, 0x20, 0x50, 0x00, 0x00, 0x16,
    0x14, 0x00, 0x06, 0x14, 0x50, 0x01, 0x00, 0x1a, 0x15, 0x01, 0x06, 0x14, 0xfa, 0x1c,
    0x00, 0x1d, 0x01, 0xff, 0x50, 0x02, 0x00, 0x2c, 0x14, 0x02, 0x06, 0x14, 0x50, 0x03,
    0x00, 0x30, 0x15, 0x03, 0x06, 0x14, 0xfa, 0x1c, 0x02, 0x1d, 0x03, 0xff};
static const uint8_t builtin_latch[] = {0xf8, 0x14, 0x00, 0x15, 0x01, 0xfa,
                                        0xf9, 0x1c, 0x00, 0x1d, 0x01, 0xff};
static const uint8_t builtin_shortcut[] = {0xf8, 0x50, 0x00, 0x00, 0x09, 0x14, 0x00, 0x06, 0x14,
                                           0x15, 0x01, 0x06, 0x23, 0x1d, 0x01, 0x06, 0x23, 0x15,
                                           0x02, 0x06, 0x23, 0x1d, 0x02, 0x06, 0x23, 0x15, 0x03,
                                           0x06, 0x23, 0x1d, 0x03, 0x06, 0x23, 0x1c, 0x00, 0xff};

static const uint8_t *builtin_program(uint8_t mode, size_t *length) {
#define BUILTIN_CASE(mode_id, program)                                                             \
    case mode_id: *length = sizeof(program); return program
    switch (mode) {
        BUILTIN_CASE(SAYO_KEY_DEFAULT, builtin_default);
        BUILTIN_CASE(SAYO_KEY_MEDIA, builtin_media);
        BUILTIN_CASE(SAYO_KEY_SHORT_LONG, builtin_short_long);
        BUILTIN_CASE(SAYO_MEDIA_SHORT_LONG, builtin_media_short_long);
        BUILTIN_CASE(SAYO_KEY_PRESS_RELEASE, builtin_press_release);
        BUILTIN_CASE(SAYO_KEY_LED_LOCK, builtin_led_lock);
        BUILTIN_CASE(SAYO_KEY_FOUR, builtin_four);
        BUILTIN_CASE(SAYO_KEY_LOOP, builtin_loop);
        BUILTIN_CASE(SAYO_KEY_NUMLOCK, builtin_numlock);
        BUILTIN_CASE(SAYO_KEY_LATCH, builtin_latch);
        BUILTIN_CASE(SAYO_KEY_SHORTCUT, builtin_shortcut);
    default: *length = 0U; return NULL;
    }
#undef BUILTIN_CASE
}

static size_t builtin_instruction_length(uint8_t opcode) {
    switch (opcode) {
    case B_END:
    case B_JOG:
    case B_WAIT_PRESS:
    case B_WAIT_RELEASE:
    case B_REPORT_BARRIER:
    case B_EXIT: return 1U;
    case B_SLEEP:
    case B_SLEEP_REG:
    case B_MOD_DOWN:
    case B_KEY_DOWN:
    case B_MEDIA_DOWN:
    case B_MOD_UP:
    case B_KEY_UP:
    case B_MEDIA_UP:
    case B_OR_ACC:
    case B_NOT:
    case B_SAVE_PC: return 2U;
    case B_JUMP_ZERO_REG:
    case B_JUMP_NONZERO_REG:
    case B_DECREMENT_JUMP_REG:
    case B_AND_REG:
    case B_AND:
    case B_MOVE:
    case B_MOVE_IMMEDIATE: return 3U;
    case B_JUMP_ZERO:
    case B_DECREMENT_JUMP: return 4U;
    default: return 0U;
    }
}

static bool builtin_key_held(const keypad_state_t *st, uint8_t key) {
    bool pressed[SAYO_KEY_COUNT];
    compute_effective_button_states(st, pressed);
    return pressed[key];
}

static bool builtin_wait_ready(const keypad_state_t *st, uint8_t key) {
    uint8_t wait = st->builtin_keys[key].wait_for;
    if (st->builtin_keys[key].mode == SAYO_KEY_LATCH) {
        if (wait == B_WAIT_RELEASE && st->builtin_keys[key].latch_released) return true;
        if (wait == B_WAIT_PRESS && st->builtin_keys[key].latch_repressed) return true;
    }
    return wait == 0U ||
           (wait == B_WAIT_PRESS ? builtin_key_held(st, key) : !builtin_key_held(st, key));
}

static bool start_builtin_key(keypad_state_t *st, uint8_t key, const uint8_t *kd) {
    size_t length;
    const uint8_t *code = builtin_program(kd[0], &length);
    if (code == NULL) return false;
    builtin_key_t *vm = &st->builtin_keys[key];
    if (vm->active || vm->pending) {

        if (vm->mode == SAYO_KEY_LATCH && vm->latch_released) vm->latch_repressed = true;
        if (vm->mode != SAYO_KEY_LATCH)
            fprintf(stderr, "[Macro] key %u is still running; repeated trigger rejected\n",
                    (unsigned)key);
        return true;
    }
    memset(vm, 0, sizeof(*vm));
    vm->code = code;
    vm->code_len = length;
    vm->mode = kd[0];
    for (size_t i = 0; i < 4U; ++i) vm->reg[i] = kd[4U + i];

    for (size_t pc = 0; pc < length;) {
        size_t n = builtin_instruction_length(code[pc]);
        if (n == 0U || n > length - pc) return true;
        if (code[pc] == B_SAVE_PC) vm->reg[code[pc + 1U]] = (uint32_t)(pc + n);
        pc += n;
    }
    vm->active = true;
    return true;
}

static void builtin_set_key(builtin_key_t *vm, uint8_t usage, bool down) {
    if (usage == 0U) return;
    if (usage >= 0xE0U && usage <= 0xE7U) {
        uint8_t bit = (uint8_t)(1U << (usage - 0xE0U));
        if (down)
            vm->modifiers |= bit;
        else
            vm->modifiers &= (uint8_t)~bit;
        return;
    }
    for (size_t i = 0; i < sizeof(vm->keys); ++i) {
        if (vm->keys[i] == usage) {
            if (!down) vm->keys[i] = 0U;
            return;
        }
    }
    if (down)
        for (size_t i = 0; i < sizeof(vm->keys); ++i)
            if (vm->keys[i] == 0U) {
                vm->keys[i] = usage;
                return;
            }
}

static void builtin_write_host_leds(keypad_state_t *st, builtin_key_t *vm, uint8_t target_leds) {
    if (vm->led_toggle_mask == 0U) {
        uint8_t diff = (uint8_t)((st->host_leds ^ target_leds) & 0x07U);
        vm->led_toggle_mask = (uint8_t)(0x10U | diff);
        if (diff != 0U) {
            if (diff & 0x01U) builtin_set_key(vm, 0x53U, true);
            if (diff & 0x02U) builtin_set_key(vm, 0x39U, true);
            if (diff & 0x04U) builtin_set_key(vm, 0x47U, true);
            st->host_leds ^= diff;
            st->cfg.cmd1f_data[7][0] = st->host_leds;
            vm->reg[B_REG_HOST_LEDS] = st->host_leds;
        }
    } else {
        if (vm->led_toggle_mask & 0x01U) builtin_set_key(vm, 0x53U, false);
        if (vm->led_toggle_mask & 0x02U) builtin_set_key(vm, 0x39U, false);
        if (vm->led_toggle_mask & 0x04U) builtin_set_key(vm, 0x47U, false);
        vm->led_toggle_mask = 0U;
    }
}

static int step_builtin_modes_if_needed(int intr_fd, keypad_state_t *st) {
    if (intr_fd < 0 || st->protocol_barrier || st->tx_input.count != 0U) return 0;
    for (uint8_t key = 0; key < SAYO_KEY_COUNT; ++key) {
        builtin_key_t *vm = &st->builtin_keys[key];
        uint64_t now = monotonic_ms();
        if (!vm->active || vm->pending || now < vm->deadline_ms || !builtin_wait_ready(st, key))
            continue;

        uint64_t stage_time = vm->wait_for != 0U || vm->deadline_ms == 0U ? now : vm->deadline_ms;
        if (vm->mode == SAYO_KEY_LATCH && vm->wait_for == B_WAIT_RELEASE) vm->latch_released = true;
        uint8_t old_mods = vm->modifiers, old_keys[sizeof(vm->keys)];
        uint16_t old_consumer = vm->consumer;
        memcpy(old_keys, vm->keys, sizeof(old_keys));
        vm->delay_ms = 0U;
        vm->wait_for = 0U;
        vm->reg[B_REG_KEY_IO] = builtin_key_held(st, key) ? 0U : 1U;
        vm->reg[B_REG_HOST_LEDS] = st->host_leds;
        for (unsigned budget = 0; vm->active && budget < B_INSTRUCTION_BUDGET; ++budget) {
            if (vm->pc >= vm->code_len) {
                vm->active = false;
                break;
            }
            const uint8_t *op = &vm->code[vm->pc];
            size_t n = builtin_instruction_length(op[0]);
            if (n == 0U || n > vm->code_len - vm->pc) {
                vm->active = false;
                break;
            }
            vm->pc += n;
            uint32_t value = n > 1U && op[1] < 21U ? vm->reg[op[1]] : 0U;

            bool new_key = op[0] == B_KEY_UP && value != 0U &&
                           memchr(vm->keys, (int)(uint8_t)value, sizeof(vm->keys)) != NULL &&
                           memchr(old_keys, (int)(uint8_t)value, sizeof(old_keys)) == NULL;
            bool new_modifier =
                op[0] == B_MOD_UP && (vm->modifiers & (uint8_t)value & (uint8_t)~old_mods) != 0U;
            bool new_media =
                op[0] == B_MEDIA_UP && vm->consumer != 0U && vm->consumer != old_consumer;
            if (new_key || new_modifier || new_media) {
                vm->pc -= n;
                vm->delay_ms = 1U;
                break;
            }
            switch (op[0]) {
            case B_END:
            case B_EXIT: vm->active = false; break;
            case B_JOG: break;
            case B_SLEEP: vm->delay_ms = op[1] != 0U ? op[1] : 1U; break;
            case B_SLEEP_REG: vm->delay_ms = value != 0U ? value : 1U; break;
            case B_MOD_DOWN: vm->modifiers |= (uint8_t)value; break;
            case B_MOD_UP: vm->modifiers &= (uint8_t)~value; break;
            case B_KEY_DOWN:
            case B_KEY_UP: builtin_set_key(vm, (uint8_t)value, op[0] == B_KEY_DOWN); break;
            case B_MEDIA_DOWN:
                vm->consumer = value < 32U ? k_sayo_consumer_table[value] : 0U;
                break;
            case B_MEDIA_UP: vm->consumer = 0U; break;
            case B_JUMP_ZERO_REG:
                if (value == 0U) vm->pc = vm->reg[op[2]];
                break;
            case B_JUMP_NONZERO_REG:
                if (value != 0U) vm->pc = vm->reg[op[2]];
                break;
            case B_DECREMENT_JUMP_REG:
                if (--vm->reg[op[1]] != 0U) vm->pc = vm->reg[op[2]];
                break;
            case B_JUMP_ZERO:
                if (value == 0U) vm->pc = ((size_t)op[2] << 8U) | op[3];
                break;
            case B_DECREMENT_JUMP:
                if (--vm->reg[op[1]] != 0U) vm->pc = ((size_t)op[2] << 8U) | op[3];
                break;
            case B_AND_REG: vm->reg[op[1]] &= vm->reg[op[2]]; break;
            case B_AND: vm->reg[op[1]] &= op[2]; break;
            case B_OR_ACC: vm->reg[B_REG_ACC] |= value; break;
            case B_NOT: vm->reg[op[1]] = ~value; break;
            case B_MOVE:
                if (op[1] == B_REG_HOST_LEDS)
                    builtin_write_host_leds(st, vm, (uint8_t)vm->reg[op[2]]);
                else
                    vm->reg[op[1]] = vm->reg[op[2]];
                break;
            case B_MOVE_IMMEDIATE:
                if (op[1] == B_REG_HOST_LEDS)
                    builtin_write_host_leds(st, vm, op[2]);
                else
                    vm->reg[op[1]] = op[2];
                break;
            case B_SAVE_PC: vm->reg[op[1]] = (uint32_t)vm->pc; break;
            case B_REPORT_BARRIER: vm->delay_ms = 1U; break;
            case B_WAIT_PRESS:
            case B_WAIT_RELEASE:
                vm->wait_for = op[0];
                if (builtin_wait_ready(st, key)) {
                    if (vm->mode == SAYO_KEY_LATCH && op[0] == B_WAIT_RELEASE)
                        vm->latch_released = true;
                    vm->wait_for = 0U;
                }
                break;
            default: vm->active = false; break;
            }

            if (op[0] == B_SLEEP || op[0] == B_SLEEP_REG || op[0] == B_REPORT_BARRIER ||
                vm->wait_for != 0U)
                break;
            if (budget + 1U == B_INSTRUCTION_BUDGET) vm->delay_ms = 1U;
        }
        if (!vm->active) {
            vm->modifiers = 0U;
            memset(vm->keys, 0, sizeof(vm->keys));
            vm->consumer = 0U;
        }
        vm->deadline_ms = stage_time + vm->delay_ms;
        if (vm->modifiers != old_mods || memcmp(vm->keys, old_keys, sizeof(old_keys)) != 0 ||
            vm->consumer != old_consumer) {
            if (cancel_macro_for_ordinary_keys(intr_fd, st) < 0) return -1;
            vm->pending = true;
            if (submit_hid_input_report(intr_fd, st, (uint8_t)(BUILTIN_TX_BASE + key)) < 0)
                return -1;
            if (st->tx_input.count != 0U) return 0;
        }
    }
    return 0;
}

static int reconcile_held_default_keys(int intr_fd, keypad_state_t *st) {
    if (intr_fd < 0) return 0;
    bool pressed[SAYO_KEY_COUNT];
    compute_effective_button_states(st, pressed);
    uint8_t fn = resolve_effective_fn_layer(st);
    bool started = false;
    for (uint8_t key = 0; key < SAYO_KEY_COUNT; ++key) {
        builtin_key_t *vm = &st->builtin_keys[key];
        const uint8_t *kd = &st->cfg.key_info[key][16U + (size_t)fn * 8U];
        if (pressed[key] && kd[0] == SAYO_KEY_DEFAULT && !vm->active && !vm->pending) {
            (void)start_builtin_key(st, key, kd);
            started = true;
        }
    }
    return started ? step_builtin_modes_if_needed(intr_fd, st) : 0;
}

static int builtin_modes_poll_timeout(const keypad_state_t *st, uint64_t now, int timeout) {
    if (st->protocol_barrier || st->tx_input.count != 0U) return timeout;
    for (uint8_t key = 0; key < SAYO_KEY_COUNT; ++key) {
        const builtin_key_t *vm = &st->builtin_keys[key];
        if (!vm->active || vm->pending || !builtin_wait_ready(st, key)) continue;
        uint64_t remaining = vm->deadline_ms > now ? vm->deadline_ms - now : 0U;
        if (remaining < (uint64_t)timeout) timeout = (int)remaining;
    }
    return timeout;
}

static void handle_special_modes_on_press(int intr_fd, keypad_state_t *st, uint8_t key_idx) {
    if (key_idx >= SAYO_KEY_COUNT) return;
    st->key_press_ms[key_idx] = monotonic_ms();
    if (st->cfg.adv_key[key_idx][0] == 3U) st->tgl_latch_mask ^= (uint8_t)(1U << key_idx);
    uint8_t fn = resolve_effective_fn_layer(st);
    const uint8_t *ld = &st->cfg.led_info[key_idx][16U + (size_t)fn * 8U];
    if ((ld[0] & 0x0FU) == 7U || ld[1] == 5U) st->key_color_step[key_idx]++;
    const uint8_t *kd = &st->cfg.key_info[key_idx][16U + (size_t)fn * 8U];
    uint8_t kmode = kd[0];
    if (start_builtin_key(st, key_idx, kd)) {
        (void)step_builtin_modes_if_needed(intr_fd, st);
        return;
    }
    if (kmode == 8U) {
        uint8_t slot = (uint8_t)(kd[4] & 0x03U);
        uint16_t step = (kd[6] > 0U) ? (uint16_t)kd[6] : (uint16_t)MACRO_DEFAULT_STEP_MS;
        enqueue_string_content_to_macro(st, st->cfg.passwords[slot], st->cfg.password_enc[slot],
                                        kd[5], step);
        (void)step_macro_typing_if_needed(intr_fd, st);
        return;
    }
    if (kmode == 48U) {
        uint8_t slot = (uint8_t)(kd[4] & 0x07U);
        if (enqueue_string_content_to_macro(st, st->cfg.strings[slot], st->cfg.string_enc[slot],
                                            (kd[5] == 0U) ? 0x28U : 0U,
                                            (uint16_t)MACRO_DEFAULT_STEP_MS))
            st->macro_wait_key = (uint8_t)(key_idx + 1U);
        (void)step_macro_typing_if_needed(intr_fd, st);
        return;
    }
    if (kmode == 129U) {
        st->cfg.key_fn = (uint8_t)(kd[4] % SAYO_FN_LAYERS);
        sync_legacy_usages_from_cfg(st);
        send_sayo_v2_broadcast_event(intr_fd, st, 0x01U, st->cfg.key_fn);
        return;
    }
    if (kmode == 63U) {
        uint8_t opt = kd[4];
        switch (opt) {
        case 1U: st->leds_master_off = false; break;
        case 2U: st->leds_master_off = true; break;
        case 3U: st->leds_master_off = !st->leds_master_off; break;
        case 16U:
            st->cfg.led_effect[7] =
                (st->cfg.led_effect[7] >= 10U) ? (uint8_t)(st->cfg.led_effect[7] - 10U) : 0U;
            break;
        case 17U:
            st->cfg.led_effect[7] =
                (st->cfg.led_effect[7] <= 90U) ? (uint8_t)(st->cfg.led_effect[7] + 10U) : 100U;
            break;
        case 18U:
            st->cfg.led_effect[6] =
                (st->cfg.led_effect[6] >= 10U) ? (uint8_t)(st->cfg.led_effect[6] - 10U) : 0U;
            break;
        case 19U:
            st->cfg.led_effect[6] =
                (st->cfg.led_effect[6] <= 90U) ? (uint8_t)(st->cfg.led_effect[6] + 10U) : 100U;
            break;
        case 20U: st->cfg.led_effect[5] = (uint8_t)((st->cfg.led_effect[5] + 1U) % 9U); break;
        case 21U:
            st->cfg.led_effect[3] = (st->cfg.led_effect[3] == 0U) ? 1U : 0U;
            send_sayo_v2_broadcast_event(intr_fd, st, 0x02U, st->cfg.led_effect[3]);
            break;
        case 23U:
            st->cfg.led_effect[4] = (uint8_t)((st->cfg.led_effect[4] + 1U) % 6U);
            st->cfg.led_effect[5] = 0U;
            break;
        default:
            if (opt >= 240U && opt <= 243U) {
                st->cfg.cfg_selection = (uint8_t)((opt - 240U) + 1U);
                send_sayo_v2_broadcast_event(intr_fd, st, 0x04U, st->cfg.cfg_selection);
            }
            break;
        }
        return;
    }
    if (kmode != SAYO_KEY_DEFAULT && kmode != SAYO_KEY_CHORD && kmode != 2U && kmode != 128U) {
        fprintf(stderr, "[Macro] key mode %u has no verified executor; trigger rejected\n",
                (unsigned)kmode);
    }
}

static void handle_special_modes_on_release(keypad_state_t *st, uint8_t key_idx) {
    if (key_idx >= SAYO_KEY_COUNT) return;
    st->key_release_ms[key_idx] = monotonic_ms();
    builtin_key_t *vm = &st->builtin_keys[key_idx];
    if (vm->mode == SAYO_KEY_LATCH && (vm->active || vm->pending)) vm->latch_released = true;
    uint8_t fn = resolve_effective_fn_layer(st);
    const uint8_t *ld = &st->cfg.led_info[key_idx][16U + (size_t)fn * 8U];
    if (ld[1] == 6U) st->key_color_step[key_idx]++;
}

static int cancel_macro_for_ordinary_keys(int intr_fd, keypad_state_t *st) {
    if ((st->macro_q_head == st->macro_q_tail && !st->macro_tx_pending &&
         st->macro_held_mod == 0U) ||
        !ordinary_keyboard_held(st))
        return 0;
    fprintf(stderr, "[Macro] ordinary key pressed; remaining text cancelled\n");

    for (size_t i = 0U; i < st->tx_input.count; ++i) {
        tx_record_t *r = &st->tx_input.records[(st->tx_input.head + i) % TX_QUEUE_CAP];
        if (r->macro_action == MACRO_TX_DOWN || r->macro_action == MACRO_TX_UP)
            r->macro_action = MACRO_TX_NONE;
    }
    st->macro_q_head = st->macro_q_tail = 0U;
    st->macro_key_down = st->macro_tx_pending = false;
    st->macro_held_mod = 0U;
    st->macro_wait_key = 0U;
    st->last_macro_ms = 0U;
    uint8_t release[10] = {HIDP_TRANS_DATA | HIDP_DATA_RTYPE_INPUT, 0U};
    size_t length = st->protocol_mode == 0U ? 9U : 10U;
    if (st->protocol_mode != 0U) release[1] = 1U;
    if (queue_tx_packet(st, &st->tx_input, release, length, TX_KEYBOARD, MACRO_TX_NONE, false) < 0)
        return -1;
    return flush_tx_queue(intr_fd, st, &st->tx_input, TX_INPUT_MAX_AGE_MS, 16U);
}

static int publish_input_state(input_set_t *iset, keypad_state_t *st, int intr_fd, led_ring_t *ring,
                               bool connected, bool physical_edges) {
    bool before[3] = {st->pressed_minus, st->pressed_center, st->pressed_plus};
    bool changed = set_physical_buttons(st, input_buttons(iset));
    if (!physical_edges && connected && reconcile_held_default_keys(intr_fd, st) < 0) return -1;
    if (!changed) return 0;
    if (physical_edges) st->last_input_edge_ms = monotonic_ms();
    bool after[3] = {st->pressed_minus, st->pressed_center, st->pressed_plus};
    for (uint8_t key = 0; physical_edges && key < SAYO_KEY_COUNT; ++key) {
        if (before[key] == after[key]) continue;
        if (after[key])
            handle_special_modes_on_press(intr_fd, st, key);
        else
            handle_special_modes_on_release(st, key);
    }
    if (connected && step_builtin_modes_if_needed(intr_fd, st) < 0) return -1;
    if (connected) {
        uint8_t pkt[16];
        size_t len = build_hid_input_packet(st, pkt);
        bool macro_active =
            st->macro_q_head < st->macro_q_tail || st->macro_tx_pending || st->macro_held_mod != 0U;
        if (st->report_dirty || st->last_kb_len != len || memcmp(st->last_kb_pkt, pkt, len) != 0 ||
            extra_hid_reports_needed(st) || (macro_active && ordinary_keyboard_held(st))) {
            if (send_hid_input_report(intr_fd, st) < 0) return -1;
        }
    }
    mark_leds_dirty(ring);
    return 0;
}

static int process_input_event(input_set_t *iset, input_slot_t *slot, keypad_state_t *st,
                               const raw_input_event_t *event, int intr_fd, led_ring_t *ring,
                               bool connected) {
    if (slot->monotonic_clock) {
        uint64_t event_ms = event->tv_sec * 1000ULL + event->tv_usec / 1000ULL;
        uint64_t now = monotonic_ms();
        if (event_ms <= now && now - event_ms > st->max_input_age_ms)
            st->max_input_age_ms = now - event_ms;
    }
    if (event->type == EV_SYN && event->code == SYN_DROPPED) {
        slot->desynchronized = true;
        st->input_overruns++;
        return 0;
    }
    if (slot->desynchronized) {
        if (event->type != EV_SYN || event->code != SYN_REPORT) return 0;
        if (!sync_input_slot(slot)) return 0;
        slot->desynchronized = false;
        return publish_input_state(iset, st, intr_fd, ring, connected, false);
    }
    if (event->type == EV_KEY && event->code <= KEY_MAX &&
        (event->value == 0 || event->value == 1)) {
        uint8_t mask = (uint8_t)(1U << (event->code % 8U));
        if (event->value)
            slot->key_bits[event->code / 8U] |= mask;
        else
            slot->key_bits[event->code / 8U] &= (uint8_t)~mask;
    }
    if (event->type == EV_SYN && event->code == SYN_REPORT) {
        slot->buttons = slot_buttons_from_bits(slot);
        return publish_input_state(iset, st, intr_fd, ring, connected, true);
    }
    return 0;
}

static int poll_add_fd(struct pollfd *pfds, nfds_t *nfds, int fd, short events) {
    if (fd < 0) return -1;
    int idx = (int)(*nfds)++;
    pfds[idx] = (struct pollfd){.fd = fd, .events = events, .revents = 0};
    return idx;
}

static int accept_l2cap_client(int listen_fd, bdaddr_t *out_peer, bdaddr_t *out_local) {
    struct sockaddr_l2 peer = {0}, loc = {0};
    socklen_t plen = (socklen_t)sizeof(peer), llen = (socklen_t)sizeof(loc);
    int fd = accept(listen_fd, (struct sockaddr *)&peer, &plen);
    if (fd < 0) return -1;
    if (set_fd_nonblock_cloexec(fd) < 0 || tune_l2cap_socket_mtu_and_qos(fd) < 0) {
        (void)close(fd);
        return -1;
    }
    if (out_peer != NULL) *out_peer = peer.l2_bdaddr;
    if (out_local != NULL && getsockname(fd, (struct sockaddr *)&loc, &llen) == 0)
        *out_local = loc.l2_bdaddr;
    return fd;
}

static void print_usage(const char *prog) {
    printf("Usage: %s [-d <dev|auto>] [-D] [-l <log>] [-p <pid>] [-z] [-v] [-h]\n", prog);
}

int main(int argc, char **argv) {
    const char *input_dev = "auto";
    const char *log_path = NULL;
    const char *pid_path = NULL;
    bool daemon_mode = false, zero_on_exit = false, verbose = false;

    int opt;
    while ((opt = getopt(argc, argv, "d:Dl:p:zvh")) != -1) {
        switch (opt) {
        case 'd': input_dev = optarg; break;
        case 'D': daemon_mode = true; break;
        case 'l': log_path = optarg; break;
        case 'p': pid_path = optarg; break;
        case 'z': zero_on_exit = true; break;
        case 'v': verbose = true; break;
        case 'h':
        default: print_usage(argv[0]); return (opt == 'h') ? 0 : 1;
        }
    }

    keypad_state_t st;
    memset(&st, 0, sizeof(st));
    st.protocol_mode = 1U;
    st.enum_last_cmd = 0xFFU;

    init_default_sayo_cfg(&st);
    (void)load_sayo_cfg_from_disk(&st);

    (void)signal(SIGPIPE, SIG_IGN);
    (void)signal(SIGHUP, SIG_IGN);
    struct sigaction sa = {.sa_handler = handle_signal};
    sigemptyset(&sa.sa_mask);
    (void)sigaction(SIGINT, &sa, NULL);
    (void)sigaction(SIGTERM, &sa, NULL);
    (void)sigaction(SIGQUIT, &sa, NULL);

    led_ring_t ring;
    led_ring_init(&ring);

    input_set_t iset;
    if (init_input_set(&iset, input_dev, &st) == 0U) {
        fprintf(stderr, "open(%s) failed: %s\n", input_dev, strerror(errno));
        close_all_input_slots(&iset);
        led_ring_restore_and_close(&ring, zero_on_exit);
        return 1;
    }

    int listen_ctrl = create_l2cap_listener(L2CAP_PSM_HIDP_CTRL);
    int listen_intr = create_l2cap_listener(L2CAP_PSM_HIDP_INTR);
    if (listen_ctrl < 0 || listen_intr < 0 ||
        (daemon_mode && daemonize_process(log_path, pid_path) < 0)) {
        close_fd_if_open(&listen_ctrl);
        close_fd_if_open(&listen_intr);
        close_all_input_slots(&iset);
        led_ring_restore_and_close(&ring, zero_on_exit);
        return 1;
    }

    int sdp_fd = register_sayodevice_sdp_records(verbose);
    optimize_realtime_priority(verbose);

    if (verbose) led_ring_log_saved(&ring);
    for (size_t i = 0U; i < iset.count; ++i) {
        printf("[SayoDevice Mini 2] Input[%zu]: %s (%s, EVIOCGRAB=%s)\n", i, iset.slots[i].path,
               iset.slots[i].name, iset.slots[i].grabbed ? "OK" : "NO");
    }
    ensure_hci0_piscan();
    printf("[SayoDevice Mini 2] awaiting connection\n");
    (void)fflush(stdout);

    int conn_ctrl = -1, conn_intr = -1;
    bdaddr_t ctrl_peer = {{0}};
    bool has_ctrl_peer = false, is_connected = false;
    uint64_t ctrl_connected_ms = 0ULL, last_reopen_ms = 0ULL;

    led_ring_step_searching_blue(&ring);
    uint64_t last_anim_ms = monotonic_ms();
    uint64_t last_effect_ms = last_anim_ms, last_piscan_ms = last_anim_ms;

    while (!g_stop) {
        uint64_t now = monotonic_ms(), loop_started_ms = now;

        if ((any_input_slot_closed(&iset) || listen_ctrl < 0 || listen_intr < 0 || sdp_fd < 0) &&
            (now - last_reopen_ms >= REOPEN_RETRY_INTERVAL_MS)) {
            last_reopen_ms = now;
            if (any_input_slot_closed(&iset)) reopen_closed_input_slots(&iset, &st);
            if (listen_ctrl < 0) listen_ctrl = create_l2cap_listener(L2CAP_PSM_HIDP_CTRL);
            if (listen_intr < 0) listen_intr = create_l2cap_listener(L2CAP_PSM_HIDP_INTR);
            if (sdp_fd < 0 && conn_ctrl < 0 && conn_intr < 0)
                sdp_fd = register_sayodevice_sdp_records(verbose);
        }

        if (conn_ctrl >= 0 && conn_intr < 0 &&
            (now - ctrl_connected_ms >= HALF_OPEN_CTRL_TIMEOUT_MS)) {
            disconnect_active_peer("HID Interrupt (PSM 0x0013) timeout", &conn_ctrl, &conn_intr,
                                   &has_ctrl_peer, &is_connected, &st, &ring, &last_anim_ms,
                                   &last_piscan_ms);
        }

        bool vendor_hold =
            is_connected && (st.pressed_minus || st.pressed_center || st.pressed_plus ||
                             (st.last_input_edge_ms != 0U && now - st.last_input_edge_ms < 250ULL));
        if (vendor_hold) {
            for (size_t i = 0U; i < st.tx_vendor.count; ++i)
                st.tx_vendor.records[(st.tx_vendor.head + i) % TX_QUEUE_CAP].queued_ms = now;
        }

        struct pollfd pfds[MAX_INPUT_DEVS + 5];
        nfds_t nfds = 0U;
        int idx_ev[MAX_INPUT_DEVS];
        for (size_t i = 0U; i < iset.count; ++i)
            idx_ev[i] = poll_add_fd(pfds, &nfds, iset.slots[i].fd, POLLIN);
        int idx_l_ctrl = poll_add_fd(pfds, &nfds, listen_ctrl, POLLIN);
        int idx_l_intr = poll_add_fd(pfds, &nfds, listen_intr, POLLIN);
        int idx_ctrl = poll_add_fd(
            pfds, &nfds, conn_ctrl,
            (short)(POLLIN | POLLERR | POLLHUP |
                    (tx_queue_ready(&st.tx_control, now) ? POLLOUT : 0)));
        int idx_intr = poll_add_fd(
            pfds, &nfds, conn_intr,
            (short)(POLLIN | POLLERR | POLLHUP |
                    (((!st.protocol_barrier && tx_queue_ready(&st.tx_input, now)) ||
                      (!vendor_hold && st.tx_input.count == 0U &&
                       tx_queue_ready(&st.tx_vendor, now)))
                         ? POLLOUT
                         : 0)));
        int idx_sdp = poll_add_fd(pfds, &nfds, sdp_fd, POLLERR | POLLHUP);

        now = monotonic_ms();
        int timeout_ms = 1000;
        if (!is_connected) {
            timeout_ms =
                deadline_poll_timeout(now, last_anim_ms, SEARCH_ANIM_INTERVAL_MS, timeout_ms);
        } else {
            timeout_ms = builtin_modes_poll_timeout(&st, now, timeout_ms);
            if (st.tx_input.count == 0U && st.tx_control.count == 0U) {
                if (ring.dirty)
                    timeout_ms =
                        deadline_poll_timeout(now, st.last_input_edge_ms, 15ULL, timeout_ms);
                else if (sayo_leds_need_animation(&st))
                    timeout_ms = deadline_poll_timeout(now, last_effect_ms, EFFECT_ANIM_INTERVAL_MS,
                                                       timeout_ms);
                if (st.tx_vendor.count > 0U && vendor_hold && !st.pressed_minus &&
                    !st.pressed_center && !st.pressed_plus)
                    timeout_ms =
                        deadline_poll_timeout(now, st.last_input_edge_ms, 250ULL, timeout_ms);
            }
            if (!st.macro_tx_pending && st.tx_input.count == 0U &&
                (st.macro_key_down || !ordinary_keyboard_held(&st)) &&
                !macro_waiting_for_release(&st) &&
                (st.macro_q_head < st.macro_q_tail || st.macro_key_down)) {
                timeout_ms =
                    deadline_poll_timeout(now, st.last_macro_ms, st.macro_step_ms, timeout_ms);
            }
            if (st.idle_rate > 0U && st.tx_input.count == 0U && !st.protocol_barrier) {
                timeout_ms = deadline_poll_timeout(now, st.last_tx_ms,
                                                   (uint64_t)st.idle_rate * 4ULL, timeout_ms);
            }
        }
        if (any_input_slot_closed(&iset) || listen_ctrl < 0 || listen_intr < 0 || sdp_fd < 0)
            timeout_ms =
                deadline_poll_timeout(now, last_reopen_ms, REOPEN_RETRY_INTERVAL_MS, timeout_ms);
        if (conn_ctrl >= 0 && conn_intr < 0)
            timeout_ms = deadline_poll_timeout(now, ctrl_connected_ms, HALF_OPEN_CTRL_TIMEOUT_MS,
                                               timeout_ms);

        timeout_ms = tx_poll_timeout(&st.tx_input, now, timeout_ms, TX_INPUT_MAX_AGE_MS);
        timeout_ms = tx_poll_timeout(&st.tx_control, now, timeout_ms, TX_CONTROL_MAX_AGE_MS);
        if (!vendor_hold)
            timeout_ms = tx_poll_timeout(&st.tx_vendor, now, timeout_ms, TX_CONTROL_MAX_AGE_MS);
        if (st.report_dirty || st.tx_fault) timeout_ms = 0;
        if (st.save_pid > 0 && timeout_ms > 100) timeout_ms = 100;

        uint64_t work_ms = monotonic_ms() - loop_started_ms;
        if (work_ms > st.max_loop_gap_ms) st.max_loop_gap_ms = work_ms;
        int ret = poll(pfds, nfds, timeout_ms);
        loop_started_ms = monotonic_ms();
        if (ret < 0) {
            if (errno == EINTR) continue;
            perror("poll");
            break;
        }

        if (idx_sdp >= 0 && (pfds[idx_sdp].revents & (POLLERR | POLLHUP | POLLNVAL)) != 0)
            close_fd_if_open(&sdp_fd);

        bool input_failed = false;
        for (size_t slot_index = 0; slot_index < iset.count; ++slot_index) {
            int p_idx = idx_ev[slot_index];
            input_slot_t *slot = &iset.slots[slot_index];
            if (p_idx < 0 || slot->fd < 0) continue;
            bool closed = (pfds[p_idx].revents & (POLLERR | POLLHUP | POLLNVAL)) != 0;
            if (!closed && (pfds[p_idx].revents & POLLIN)) {
                struct timespec coal_ts = {0, 120000L};
                (void)nanosleep(&coal_ts, NULL);
                raw_input_event_t events[64];
                for (unsigned batch = 0; batch < INPUT_READ_BUDGET; ++batch) {
                    ssize_t n = read(slot->fd, events, sizeof(events));
                    if (n < 0) {
                        if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
                            closed = true;
                        break;
                    }
                    if (n == 0 || (size_t)n % sizeof(events[0]) != 0U) {
                        closed = true;
                        break;
                    }
                    size_t ev_count = (size_t)n / sizeof(events[0]);
                    uint32_t frame_buttons = 0U;
                    for (size_t i = 0; i < ev_count; ++i) {
                        if (events[i].type == EV_KEY) {
                            frame_buttons |= map_event_to_button_bit(events[i].code, slot->pad_role);
                        } else if (events[i].type == EV_SYN && events[i].code == SYN_REPORT &&
                                   !slot->desynchronized && i + 2U < ev_count &&
                                   events[i + 1U].type == EV_KEY &&
                                   events[i + 2U].type == EV_SYN &&
                                   events[i + 2U].code == SYN_REPORT) {
                            uint32_t next_btn =
                                map_event_to_button_bit(events[i + 1U].code, slot->pad_role);
                            uint64_t t0 =
                                events[i].tv_sec * 1000ULL + events[i].tv_usec / 1000ULL;
                            uint64_t t1 = events[i + 2U].tv_sec * 1000ULL +
                                          events[i + 2U].tv_usec / 1000ULL;
                            if (next_btn != 0U && (frame_buttons & next_btn) == 0U && t1 >= t0 &&
                                t1 - t0 <= 2ULL) {
                                continue;
                            }
                        }
                        if (events[i].type == EV_SYN && events[i].code == SYN_REPORT)
                            frame_buttons = 0U;
                        if (process_input_event(&iset, slot, &st, &events[i], conn_intr, &ring,
                                                is_connected) < 0)
                            input_failed = true;
                    }
                    if (input_failed) break;
                }
            }
            if (closed) {
                close_input_slot(slot);
                st.tgl_latch_mask = 0U;
                if (publish_input_state(&iset, &st, conn_intr, &ring, is_connected, false) < 0)
                    input_failed = true;
                st.report_dirty = true;
            }
            if (input_failed) break;
        }
        if (input_failed) {
            disconnect_active_peer("Input transmit queue failed", &conn_ctrl, &conn_intr,
                                   &has_ctrl_peer, &is_connected, &st, &ring, &last_anim_ms,
                                   &last_piscan_ms);
            idx_ctrl = idx_intr = -1;
        }

        if (idx_l_ctrl >= 0 && listen_ctrl >= 0) {
            if ((pfds[idx_l_ctrl].revents & (POLLERR | POLLHUP | POLLNVAL)) != 0) {
                close_fd_if_open(&listen_ctrl);
            } else if ((pfds[idx_l_ctrl].revents & POLLIN) != 0) {
                bdaddr_t peer_addr = {{0}}, local_addr = {{0}};
                int fd = accept_l2cap_client(listen_ctrl, &peer_addr, &local_addr);
                if (fd >= 0) {
                    close_fd_if_open(&conn_ctrl);
                    close_fd_if_open(&conn_intr);
                    reset_hid_session(&st);
                    st.peer_addr = peer_addr;
                    st.local_addr = local_addr;
                    st.has_peer_addr = true;
                    (void)detect_peer_host_os(&st);
                    idx_ctrl = idx_intr = -1;
                    conn_ctrl = fd;
                    ctrl_peer = peer_addr;
                    has_ctrl_peer = true;
                    is_connected = false;
                    ctrl_connected_ms = monotonic_ms();
                    (void)sync_buttons_from_kernel_all(&iset, &st);
                    if (verbose) {
                        char addr_str[18];
                        format_bdaddr(&peer_addr, addr_str);
                        printf("[Bluetooth] Control (0x0011) connected: %s\n", addr_str);
                        (void)fflush(stdout);
                    }
                }
            }
        }

        if (idx_l_intr >= 0 && listen_intr >= 0) {
            if ((pfds[idx_l_intr].revents & (POLLERR | POLLHUP | POLLNVAL)) != 0) {
                close_fd_if_open(&listen_intr);
            } else if ((pfds[idx_l_intr].revents & POLLIN) != 0) {
                bdaddr_t peer_addr = {{0}};
                int fd = accept_l2cap_client(listen_intr, &peer_addr, NULL);
                if (fd >= 0) {
                    if (conn_ctrl < 0 || !has_ctrl_peer || conn_intr >= 0 ||
                        memcmp(&ctrl_peer, &peer_addr, sizeof(bdaddr_t)) != 0) {
                        (void)close(fd);
                    } else {
                        conn_intr = fd;
                        idx_intr = -1;
                        is_connected = true;
                        st.report_dirty = true;
                        set_hci0_scan(0U);
                        (void)sync_buttons_from_kernel_all(&iset, &st);
                        if (reconcile_held_default_keys(conn_intr, &st) < 0) st.tx_fault = true;
                        char addr_str[18];
                        format_bdaddr(&peer_addr, addr_str);
                        printf("[Bluetooth] Connected: %s\n", addr_str);
                        (void)fflush(stdout);
                        mark_leds_dirty(&ring);
                    }
                }
            }
        }

        if (idx_ctrl >= 0 && conn_ctrl >= 0 && pfds[idx_ctrl].fd == conn_ctrl &&
            (pfds[idx_ctrl].revents & (POLLIN | POLLOUT | POLLERR | POLLHUP | POLLNVAL)) != 0) {
            bool drop = ((pfds[idx_ctrl].revents & (POLLERR | POLLHUP | POLLNVAL)) != 0);
            if (!drop && (pfds[idx_ctrl].revents & POLLIN) != 0 &&
                handle_hid_control_message(conn_ctrl, conn_intr, &st, &ring) < 0)
                drop = true;
            if (drop) {
                disconnect_active_peer("Control channel closed", &conn_ctrl, &conn_intr,
                                       &has_ctrl_peer, &is_connected, &st, &ring, &last_anim_ms,
                                       &last_piscan_ms);
            }
        }

        if (idx_intr >= 0 && conn_intr >= 0 && pfds[idx_intr].fd == conn_intr &&
            (pfds[idx_intr].revents & (POLLIN | POLLOUT | POLLERR | POLLHUP | POLLNVAL)) != 0) {
            bool drop = ((pfds[idx_intr].revents & (POLLERR | POLLHUP | POLLNVAL)) != 0);
            if (!drop && (pfds[idx_intr].revents & POLLIN) != 0) {
                uint8_t dump[2048];
                ssize_t n = recv(conn_intr, dump, sizeof(dump), MSG_DONTWAIT);
                if (n < 0) {
                    if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) drop = true;
                } else if (n == 0) {
                    drop = true;
                } else if ((size_t)n >= 2U) {
                    uint8_t htype = (uint8_t)(dump[0] & 0xF0U);
                    uint8_t rtype = (uint8_t)(dump[0] & HIDP_DATA_RTYPE_MASK);
                    if (htype == HIDP_TRANS_DATA &&
                        (rtype == HIDP_DATA_RTYPE_OUTPUT || rtype == HIDP_DATA_RTYPE_FEATURE)) {
                        dispatch_incoming_output_report(&dump[1], (size_t)n - 1U, conn_intr,
                                                        conn_ctrl, &st, &ring);
                    }
                }
            }
            if (drop) {
                disconnect_active_peer("Interrupt channel closed", &conn_ctrl, &conn_intr,
                                       &has_ctrl_peer, &is_connected, &st, &ring, &last_anim_ms,
                                       &last_piscan_ms);
            }
        }

        bool failed = st.tx_fault;
        if (is_connected && conn_intr >= 0 && !failed) {
            if (st.report_dirty && send_hid_input_report(conn_intr, &st) < 0) failed = true;
            if (!failed &&
                flush_tx_queue(conn_intr, &st, &st.tx_input, TX_INPUT_MAX_AGE_MS, 16U) < 0)
                failed = true;
            if (!failed && step_builtin_modes_if_needed(conn_intr, &st) < 0) failed = true;
            if (!failed && step_macro_typing_if_needed(conn_intr, &st) < 0) failed = true;
            now = monotonic_ms();
            if (!failed && st.idle_rate && st.tx_input.count == 0U &&
                now - st.last_tx_ms >= (uint64_t)st.idle_rate * 4ULL &&
                send_hid_input_report(conn_intr, &st) < 0)
                failed = true;
        } else if (!is_connected) {
            st.report_dirty = false;
        }
        if (!failed && conn_ctrl >= 0 &&
            flush_tx_queue(conn_ctrl, &st, &st.tx_control, TX_CONTROL_MAX_AGE_MS, 4U) < 0)
            failed = true;
        now = monotonic_ms();
        vendor_hold =
            is_connected && (st.pressed_minus || st.pressed_center || st.pressed_plus ||
                             (st.last_input_edge_ms != 0U && now - st.last_input_edge_ms < 250ULL));
        if (!failed && conn_intr >= 0 && !vendor_hold && st.tx_input.count == 0U &&
            flush_tx_queue(conn_intr, &st, &st.tx_vendor, TX_CONTROL_MAX_AGE_MS, 1U) < 0)
            failed = true;
        if (failed) {
            fprintf(stderr,
                    "[HID] Session reset: queue failure/timeout (retries=%llu, high-water=%zu, "
                    "input-age=%llums, loop-work=%llums)\n",
                    (unsigned long long)st.tx_retries, st.tx_high_water,
                    (unsigned long long)st.max_input_age_ms,
                    (unsigned long long)st.max_loop_gap_ms);
            disconnect_active_peer("Transmit failed", &conn_ctrl, &conn_intr, &has_ctrl_peer,
                                   &is_connected, &st, &ring, &last_anim_ms, &last_piscan_ms);
        }
        if (st.tx_input.count == 0U && st.tx_control.count == 0U) {
            now = monotonic_ms();
            if (is_connected && now - st.last_input_edge_ms >= 15ULL &&
                (ring.dirty || (sayo_leds_need_animation(&st) &&
                                now - last_effect_ms >= EFFECT_ANIM_INTERVAL_MS))) {
                if (now - last_effect_ms >= EFFECT_ANIM_INTERVAL_MS)
                    ring.effect_phase = (ring.effect_phase + 2U) & 0xFFFFU;
                render_sayo_led_config(&ring, &st, is_connected);
                ring.dirty = false;
                last_effect_ms = now;
            }
        }
        if (st.tx_input.count == 0U) service_config_save(&st);

        if (!is_connected) {
            now = monotonic_ms();
            if (now - last_anim_ms >= SEARCH_ANIM_INTERVAL_MS) {
                led_ring_step_searching_blue(&ring);
                last_anim_ms = now;
            }
            if (conn_ctrl < 0 && conn_intr < 0 &&
                (now - last_piscan_ms >= PISCAN_REFRESH_INTERVAL_MS)) {
                last_piscan_ms = now;
                bdaddr_t acl_peer;
                if (!find_active_acl_peer(&acl_peer)) ensure_hci0_piscan();
            }
        }
        work_ms = monotonic_ms() - loop_started_ms;
        if (work_ms > st.max_loop_gap_ms) st.max_loop_gap_ms = work_ms;
    }

    if (is_connected && conn_intr >= 0) release_all_keys_if_connected(conn_intr, &st);
    close_fd_if_open(&conn_intr);
    close_fd_if_open(&conn_ctrl);
    close_fd_if_open(&listen_intr);
    close_fd_if_open(&listen_ctrl);
    close_fd_if_open(&sdp_fd);
    close_all_input_slots(&iset);
    if (pid_path != NULL && *pid_path != '\0') (void)unlink(pid_path);
    led_ring_restore_and_close(&ring, zero_on_exit);
    if (st.save_pid > 0) {
        while (waitpid(st.save_pid, NULL, 0) < 0 && errno == EINTR) {
        }
        st.save_pid = 0;
    }
    if (st.save_pending && !write_sayo_cfg_snapshot(&st.save_snapshot))
        fprintf(stderr, "[Config] Final save failed\n");
    return 0;
}
