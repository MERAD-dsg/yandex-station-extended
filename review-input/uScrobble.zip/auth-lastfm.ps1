$ErrorActionPreference = 'Stop'

$config = Join-Path $PSScriptRoot 'config.json'
$exe = Join-Path $PSScriptRoot 'bin\scrobbler-windows.exe'
$tempConfig = Join-Path ([IO.Path]::GetTempPath()) 'station-scrobbler-auth.json'

try {
    Copy-Item -LiteralPath $config -Destination $tempConfig -Force

    & $exe -auth -config $tempConfig
    if ($LASTEXITCODE -ne 0) {
        throw "Last.fm authorization failed"
    }

    adb push $tempConfig /data/quasar/scrobbler/config.json
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to push config to the Station"
    }

    adb shell 'chmod 600 /data/quasar/scrobbler/config.json; /etc/init.d/S99scrobbler restart'
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to restart the scrobbler"
    }

    Write-Output "Live scrobbling enabled."
}
finally {
    Remove-Item -LiteralPath $tempConfig -Force -ErrorAction SilentlyContinue
}
