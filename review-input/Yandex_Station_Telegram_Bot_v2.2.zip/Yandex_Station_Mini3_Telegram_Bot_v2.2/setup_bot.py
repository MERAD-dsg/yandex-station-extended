#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Automated Setup Wizard for Yandex Station Mini 3 - Telegram Control Bot
Guides the user step-by-step through setup, speaker installation, configuration, and autostart.
"""

import os
import sys
import time
import shutil
import subprocess
import configparser

try:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except Exception:
    pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

def print_header():
    print("=" * 70)
    print("   YANDEX STATION MINI 3 - TELEGRAM CONTROL BOT SETUP WIZARD")
    print("   Универсальный мастер установки и настройки бота для колонки")
    print("=" * 70)

def check_dependencies():
    print("\n[Шаг 1/5] Проверка библиотек Python...")
    required = ["telethon", "miniaudio", "psutil", "keyboard", "requests"]
    missing = []
    for pkg in required:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)

    if missing:
        print(f"Установка недостающих модулей: {', '.join(missing)}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing)
            print("✅ Все библиотеки успешно установлены!")
        except Exception as e:
            print(f"⚠️ Ошибка установки библиотек: {e}")
            print("Попробуйте выполнить вручную: pip install -r requirements.txt")
    else:
        print("✅ Все необходимые библиотеки Python уже установлены.")

def find_adb():
    candidates = [
        os.path.join(BASE_DIR, "tools_adb", "adb.exe"),
        os.path.join(BASE_DIR, "..", "tools_adb", "adb.exe"),
        os.path.join(BASE_DIR, "adb.exe"),
        r"C:\platform-tools\adb.exe"
    ]
    for c in candidates:
        if os.path.exists(c):
            return os.path.abspath(c)
    return "adb.exe"

def setup_speaker(adb_path):
    print("\n[Шаг 2/5] Подключение к Яндекс Станции Мини 3 по ADB...")
    print("Убедитесь, что колонка включена и находится в одной Wi-Fi сети с вашим ПК.")
    
    cfg_path = os.path.join(BASE_DIR, "config.ini")
    def_ip = "192.168.0.100"
    def_port = "5555"
    if os.path.exists(cfg_path):
        cfg = configparser.ConfigParser()
        cfg.read(cfg_path, encoding='utf-8')
        if cfg.has_section("Station"):
            def_ip = cfg.get("Station", "ip", fallback=def_ip)
            def_port = cfg.get("Station", "port", fallback=def_port)

    ip = input(f"Введите IP-адрес колонки [по умолчанию {def_ip}]: ").strip() or def_ip
    port = input(f"Введите порт ADB [по умолчанию {def_port}]: ").strip() or def_port
    target = f"{ip}:{port}"

    print(f"Подключение к {target}...")
    subprocess.run([adb_path, "connect", target], capture_output=True, timeout=8)

    res = subprocess.run([adb_path, "devices"], capture_output=True, text=True)
    if target not in res.stdout:
        print(f"\n⚠️ ВНИМАНИЕ: Не удалось подключиться к {target}.")
        print("1. Проверьте правильность IP-адреса в роутере.")
        print("2. Проверьте, включен ли режим ADB (отладка) на колонке.")
        ans = input("Продолжить установку файлов на свой страх и риск? [y/N]: ").strip().lower()
        if ans != 'y':
            print("Установка прервана пользователем.")
            sys.exit(0)
    else:
        print(f"✅ Успешное подключение к колонке ({target})!")

    print("\n[Шаг 3/5] Установка скриптов управления и звуков на колонку...")
    # Create target directories on speaker
    subprocess.run([adb_path, "shell", "mkdir -p /bkupgrade/data/opt/sounds"], capture_output=True)

    scripts_dir = os.path.join(BASE_DIR, "speaker_scripts")
    rgb_sh = os.path.join(scripts_dir, "rgb_effects.sh")
    led_sh = os.path.join(scripts_dir, "led_helper.sh")

    if os.path.exists(rgb_sh):
        print(" -> Загрузка rgb_effects.sh...")
        subprocess.run([adb_path, "push", rgb_sh, "/bkupgrade/data/opt/rgb_effects.sh"], capture_output=True)
        subprocess.run([adb_path, "shell", "chmod 755 /bkupgrade/data/opt/rgb_effects.sh"], capture_output=True)
    if os.path.exists(led_sh):
        print(" -> Загрузка led_helper.sh...")
        subprocess.run([adb_path, "push", led_sh, "/bkupgrade/data/opt/led_helper.sh"], capture_output=True)
        subprocess.run([adb_path, "shell", "chmod 755 /bkupgrade/data/opt/led_helper.sh"], capture_output=True)

    sounds_dir = os.path.join(BASE_DIR, "sounds")
    if os.path.exists(sounds_dir):
        sound_files = [f for f in os.listdir(sounds_dir) if f.lower().endswith(".wav")]
        print(f" -> Загрузка {len(sound_files)} аудиофайлов саундборда на колонку...")
        for sf in sound_files:
            local_wav = os.path.join(sounds_dir, sf)
            subprocess.run([adb_path, "push", local_wav, f"/bkupgrade/data/opt/sounds/{sf}"], capture_output=True)
            print(f"   [+] {sf}")

    # Set master volume to comfortable high level (92%)
    subprocess.run([adb_path, "shell", "amixer sset Master 235 2>/dev/null"], capture_output=True)

    print("Проверка подсветки и звука...")
    subprocess.run([adb_path, "shell", "sh /bkupgrade/data/opt/rgb_effects.sh rainbow 0.05 && sleep 1 && sh /bkupgrade/data/opt/rgb_effects.sh notify"], capture_output=True)
    print("✅ Скрипты и звуки установлены на колонку!")
    return ip, port

def setup_telegram_config(ip, port):
    print("\n[Шаг 4/5] Настройка Telegram-бота...")
    cfg_path = os.path.join(BASE_DIR, "config.ini")
    
    cur_token = ""
    cur_admin = ""
    cur_api_id = "37391973"
    cur_api_hash = "19b41be2db006b1be52d7f0fefa1f8ae"

    if os.path.exists(cfg_path):
        cfg = configparser.ConfigParser()
        cfg.read(cfg_path, encoding='utf-8')
        if cfg.has_section("TelegramBot"):
            cur_token = cfg.get("TelegramBot", "token", fallback="")
            cur_admin = cfg.get("TelegramBot", "admin_id", fallback="")
            cur_api_id = cfg.get("TelegramBot", "api_id", fallback=cur_api_id)
            cur_api_hash = cfg.get("TelegramBot", "api_hash", fallback=cur_api_hash)

    print("1. Откройте @BotFather в Telegram (https://t.me/BotFather)")
    print("2. Отправьте /newbot, введите имя и юзернейм для бота.")
    print("3. Скопируйте полученный API токен (HTTP API Token).\n")

    token = input(f"Введите токен бота [{cur_token or 'Обязательно'}]: ").strip() or cur_token
    while not token:
        print("❌ Токен бота не может быть пустым!")
        token = input("Введите токен бота: ").strip()

    print("\n4. Откройте @userinfobot в Telegram (https://t.me/userinfobot) и узнайте ваш цифровой ID.")
    print("   Это нужно для защиты: колонка будет слушаться ТОЛЬКО вас!")
    admin_id = input(f"Введите ваш Telegram ID [{cur_admin or 'Обязательно'}]: ").strip() or cur_admin
    while not admin_id or not admin_id.isdigit():
        print("❌ ID должен состоять только из цифр!")
        admin_id = input("Введите ваш Telegram ID: ").strip()

    # Save to config.ini
    cfg = configparser.ConfigParser()
    cfg["Station"] = {
        "ip": ip,
        "port": port
    }
    cfg["TelegramBot"] = {
        "token": token,
        "admin_id": admin_id,
        "api_id": cur_api_id,
        "api_hash": cur_api_hash
    }

    with open(cfg_path, "w", encoding="utf-8") as f:
        cfg.write(f)

    print("✅ Файл config.ini успешно сохранен!")

def setup_autostart():
    print("\n[Шаг 5/5] Настройка скрытого автозапуска при включении Windows...")
    print("Бот может запускаться автоматически в скрытом фоновом режиме (без черных окон),")
    print("чтобы вы могли управлять колонкой с телефона в любой момент, когда включен ПК.")
    
    ans = input("Включить автоматический скрытый автозапуск? [Y/n]: ").strip().lower()
    if ans in ['', 'y', 'yes', 'д', 'да']:
        import manage_autostart
        manage_autostart.enable()
    else:
        print("Автозапуск пропущен. Вы всегда можете включить его позже через manage_autostart.py.")

def main():
    print_header()
    check_dependencies()
    adb_path = find_adb()
    ip, port = setup_speaker(adb_path)
    setup_telegram_config(ip, port)
    setup_autostart()

    print("\n" + "=" * 70)
    print("🎉 НАСТРОЙКА УСПЕШНО ЗАВЕРШЕНА!")
    print("=" * 70)
    print("Теперь вы можете запустить бота:")
    print(" • В скрытом фоновом режиме: через manage_bot.py (выберите пункт 1)")
    print(" • Или в обычном окне консоли: запустив run_bot.py")
    print("=" * 70)
    
    start_now = input("\nЗапустить бота в скрытом фоновом режиме прямо сейчас? [Y/n]: ").strip().lower()
    if start_now in ['', 'y', 'yes', 'д', 'да']:
        import manage_bot
        manage_bot.start()

    input("\nНажмите Enter для выхода из мастера настройки...")

if __name__ == "__main__":
    main()
