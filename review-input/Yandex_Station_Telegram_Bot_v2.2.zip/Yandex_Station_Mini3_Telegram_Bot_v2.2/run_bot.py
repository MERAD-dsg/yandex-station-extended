#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Interactive Launcher for Yandex Station Telegram Control Bot
"""

import os
import sys
import subprocess

try:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except Exception:
    pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

print("=" * 65)
print("     YANDEX STATION MINI 3 - TELEGRAM CONTROL BOT")
print("=" * 65)
print("Starting Bot in interactive console mode...")
print("Откройте Telegram и отправьте команду /start вашему боту.")
print("Press Ctrl+C to stop the bot.")
print("=" * 65)

try:
    subprocess.run([sys.executable, os.path.join(BASE_DIR, "bot.py")])
except KeyboardInterrupt:
    print("\nBot stopped.")
