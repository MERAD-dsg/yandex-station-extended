#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Windows Autostart Manager for Yandex Station Telegram Control Bot
Enables or disables automatic launch of the bot on Windows boot.
"""

import os
import sys

try:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except Exception:
    pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STARTUP_DIR = os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup")
VBS_PATH = os.path.join(STARTUP_DIR, "Yandex_Station_Control_Bot.vbs")

def is_enabled():
    return os.path.exists(VBS_PATH)

def enable():
    pyw_exe = sys.executable.replace("python.exe", "pythonw.exe")
    if not os.path.exists(pyw_exe):
        pyw_exe = sys.executable
    target_script = os.path.join(BASE_DIR, "bot.py")
    vbs_content = (
        f'Set WshShell = CreateObject("WScript.Shell")\n'
        f'WshShell.CurrentDirectory = "{BASE_DIR}"\n'
        f'WshShell.Run """{pyw_exe}"" ""{target_script}""", 0, False\n'
    )
    with open(VBS_PATH, "w", encoding="ascii", errors="ignore") as f:
        f.write(vbs_content)
    print("✅ Bot autostart ENABLED! The bot will now launch silently in the background on Windows boot.")

def disable():
    if os.path.exists(VBS_PATH):
        os.remove(VBS_PATH)
        print("✅ Bot autostart DISABLED! Removed startup shortcut.")
    else:
        print("Bot autostart was not enabled.")

def main():
    print("=" * 55)
    print("    BOT WINDOWS AUTOSTART MANAGER")
    print("=" * 55)
    print(f"Status: {'🟢 ENABLED' if is_enabled() else '🔴 DISABLED'}")
    print("-" * 55)
    print("1. Enable Autostart")
    print("2. Disable Autostart")
    print("3. Exit")
    choice = input("\nSelect an option [1-3]: ").strip()
    if choice == "1":
        enable()
    elif choice == "2":
        disable()
    elif choice == "3":
        return
    else:
        print("Invalid choice.")
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
