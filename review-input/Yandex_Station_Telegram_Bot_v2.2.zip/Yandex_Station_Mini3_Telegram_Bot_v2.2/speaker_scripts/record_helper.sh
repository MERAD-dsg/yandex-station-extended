#!/bin/sh
DURATION=${1:-5}
OUTFILE=${2:-/tmp/rec_room.wav}

# 1. Boost PDM microphone gain to 40 (out of 48) so speech is crystal clear
amixer cset numid=12 40 >/dev/null 2>&1

# 2. Pause launcher so it doesn't enter retry backoff
LPID=$(pidof quasar_launcher2)
if [ -n "$LPID" ]; then
    kill -STOP $LPID 2>/dev/null
fi

# 3. Kill maind so ALSA capture device hw:0,1 is released
killall -9 maind 2>/dev/null
usleep 150000

# 4. Record high quality 8-channel audio
arecord -D hw:0,1 -d "$DURATION" -c 8 -r 48000 -f S16_LE "$OUTFILE"

# 5. Instantly resume launcher to restart maind cleanly with 0 delay
if [ -n "$LPID" ]; then
    kill -CONT $LPID 2>/dev/null
fi
