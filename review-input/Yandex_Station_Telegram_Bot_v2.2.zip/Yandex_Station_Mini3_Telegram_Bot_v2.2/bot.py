#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Yandex Station Mini 3 - Full Telegram Control Center, Intercom, Soundboard & PC Guard Bot (v2.1)
"""

import os
import sys
import time
import re
import wave
import socket
import asyncio
import configparser
import json
import subprocess
import urllib.request
import urllib.parse
import threading
import ctypes
import ctypes.wintypes
import miniaudio
import soundfile as sf
import numpy as np
import keyboard

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)
LOG_FILE = os.path.join(BASE_DIR, "bot.log")

# Safe stdout/stderr redirection for pythonw (completely silent background run)
if sys.stdout is None:
    try:
        sys.stdout = open(LOG_FILE, "a", encoding="utf-8")
    except Exception:
        sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    try:
        sys.stderr = open(LOG_FILE, "a", encoding="utf-8")
    except Exception:
        sys.stderr = open(os.devnull, "w")

# Single instance protection via loopback socket bind
_lock_socket = None
try:
    _lock_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    _lock_socket.bind(("127.0.0.1", 49153))
except Exception:
    if sys.stdout:
        print("⚠️ Another instance of Telegram Control Bot is already running.")
    sys.exit(0)

from telethon import TelegramClient, events, Button

CONFIG_PATH = os.path.join(BASE_DIR, "config.ini")
SESSION_PATH = os.path.join(BASE_DIR, "tg_bot_session")

# Defaults
device_ip = "192.168.0.100"
device_port = "5555"
BOT_TOKEN = ""
ADMIN_ID = 0
API_ID = 37391973
API_HASH = "19b41be2db006b1be52d7f0fefa1f8ae"

def log(msg):
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    entry = f"[{timestamp}] {msg}\n"
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(entry)
            f.flush()
    except Exception:
        pass

if os.path.exists(CONFIG_PATH):
    try:
        cfg = configparser.ConfigParser()
        cfg.read(CONFIG_PATH, encoding="utf-8")
        if cfg.has_section("Station"):
            device_ip = cfg.get("Station", "ip", fallback=device_ip)
            device_port = cfg.get("Station", "port", fallback=device_port)
        if cfg.has_section("TelegramBot"):
            BOT_TOKEN = cfg.get("TelegramBot", "token", fallback=BOT_TOKEN)
            ADMIN_ID = cfg.getint("TelegramBot", "admin_id", fallback=ADMIN_ID)
            API_ID = cfg.getint("TelegramBot", "api_id", fallback=API_ID)
            API_HASH = cfg.get("TelegramBot", "api_hash", fallback=API_HASH)
    except Exception as e:
        log(f"Config read error: {e}")

TARGET = f"{device_ip}:{device_port}"

# Find adb.exe
ADB_PATH = os.path.join(BASE_DIR, "tools_adb", "adb.exe")
if not os.path.exists(ADB_PATH):
    ADB_PATH = os.path.join(BASE_DIR, "..", "tools_adb", "adb.exe")
if not os.path.exists(ADB_PATH):
    ADB_PATH = os.path.join(BASE_DIR, "adb.exe")
if not os.path.exists(ADB_PATH):
    ADB_PATH = r"C:\platform-tools\adb.exe"

def ensure_adb():
    try:
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0
        subprocess.run(
            [ADB_PATH, "connect", TARGET],
            startupinfo=startupinfo,
            creationflags=subprocess.CREATE_NO_WINDOW,
            timeout=3,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
    except Exception:
        pass

def run_adb(cmd, timeout=10):
    ensure_adb()
    try:
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0
        res = subprocess.run(
            [ADB_PATH, "-s", TARGET, "shell", cmd],
            startupinfo=startupinfo,
            creationflags=subprocess.CREATE_NO_WINDOW,
            timeout=timeout,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace"
        )
        return res.returncode == 0, res.stdout.strip()
    except Exception as e:
        return False, str(e)

# 7-Segment character mapping
CHAR_MAP = {
    '0':'ABCDEF','1':'BC','2':'ABGED','3':'ABCDG','4':'FGBC','5':'AFGCD',
    '6':'AFGECD','7':'ABC','8':'ABCDEFG','9':'ABCDFG',
    'A':'ABCEFG','B':'CDEFG','C':'ADEF','D':'BCDEG','E':'ADEFG','F':'AEFG',
    'G':'AFGCD','H':'BCEFG','I':'BC','J':'BCD','K':'CEFG','L':'DEF',
    'M':'CEG','N':'CEG','O':'ABCDEF','P':'ABEFG','Q':'ABCFG','R':'EG',
    'S':'AFGCD','T':'DEFG','U':'BCDEF','V':'CDE','W':'CDE','X':'CEFG',
    'Y':'BCDFG','Z':'ABGED', ' ':'', '-': 'G', '_': 'D'
}

def set_screen_text(text):
    text = (text.upper() + '    ')[:4]
    segs = []
    for pos, ch in enumerate(text):
        for s in CHAR_MAP.get(ch, ''):
            segs.append(f'{s}{pos}')
    if segs:
        run_adb("sh /bkupgrade/data/opt/led_helper.sh show " + " ".join(segs))
    else:
        run_adb("sh /bkupgrade/data/opt/led_helper.sh clear")

def play_sound_async(sound_name):
    ensure_adb()
    cmd = [ADB_PATH, "-s", TARGET, "shell", f"aplay /bkupgrade/data/opt/sounds/{sound_name}.wav"]
    try:
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0
        subprocess.Popen(
            cmd,
            startupinfo=startupinfo,
            creationflags=subprocess.CREATE_NO_WINDOW,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return True
    except Exception as e:
        log(f"Sound error: {e}")
        return False

def generate_and_speak(text):
    try:
        enc_text = urllib.parse.quote(text)
        url = f"https://translate.google.com/translate_tts?ie=UTF-8&q={enc_text}&tl=ru&client=tw-ob"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as resp:
            mp3_data = resp.read()

        decoded = miniaudio.decode(mp3_data, nchannels=2, sample_rate=48000)
        temp_wav = os.path.join(BASE_DIR, "temp_tts.wav")
        with wave.open(temp_wav, "wb") as wf:
            wf.setnchannels(decoded.nchannels)
            wf.setsampwidth(decoded.sample_width)
            wf.setframerate(decoded.sample_rate)
            wf.writeframes(decoded.samples)

        ensure_adb()
        subprocess.run([ADB_PATH, "-s", TARGET, "push", temp_wav, "/bkupgrade/data/opt/sounds/speech.wav"], capture_output=True, timeout=10)
        play_sound_async("speech")
        return True
    except Exception as e:
        log(f"TTS Error: {e}")
        return False

# Room Recording (extracts and normalizes channels to clean high-volume mono voice file)
def record_room_mono(duration_sec=10, out_filename="listen_room.wav"):
    ensure_adb()
    raw_local = os.path.join(BASE_DIR, "temp_raw_8ch.wav")
    mono_local = os.path.join(BASE_DIR, out_filename)
    
    rec_cmd = [
        ADB_PATH, "-s", TARGET, "shell",
        f"sh /bkupgrade/data/opt/record_helper.sh {duration_sec} /tmp/rec_room.wav"
    ]
    try:
        subprocess.run(rec_cmd, capture_output=True, timeout=duration_sec + 8)
        subprocess.run([ADB_PATH, "-s", TARGET, "pull", "/tmp/rec_room.wav", raw_local], capture_output=True)

        if os.path.exists(raw_local) and os.path.getsize(raw_local) > 1000:
            data, sr = sf.read(raw_local)
            # Mix channels 0, 1, 4, 5 for clean vocal clarity and highest gain
            mono = (data[:, 0] + data[:, 1] + data[:, 4] + data[:, 5]) / 4.0
            max_v = np.max(np.abs(mono))
            if max_v > 0.0001:
                mono = (mono / max_v) * 0.95
            else:
                mono = mono * 5.0
            sf.write(mono_local, mono, sr, subtype='PCM_16', format='WAV')
            return mono_local
    except Exception as e:
        log(f"Record room error: {e}")
    return None

# State variables
active_timer_task = None
siren_active = False
waiting_for_action = {}

# PC Anti-Theft Guard System
guard_active = False
guard_triggered = False
guard_thread = None

def get_mouse_pos():
    pt = ctypes.wintypes.POINT()
    ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
    return pt.x, pt.y

async def trigger_guard_alarm(client, chat_id):
    global guard_triggered
    guard_triggered = True
    start_siren()
    now_str = time.strftime("%H:%M:%S")
    text = (
        "🚨 **ТРЕВОГА! ЗАМЕЧЕНА АКТИВНОСТЬ ЗА КОМПЬЮТЕРОМ!**\n\n"
        f"⏰ **Время срабатывания:** `{now_str}`\n"
        "⚠️ **Причина:** Движение мыши или нажатие клавиши на ПК!\n\n"
        "📢 Колонка включила громкую сирену и полицейскую подсветку."
    )
    buttons = [
        [Button.inline("⏹️ ВЫКЛЮЧИТЬ ТРЕВОГУ И СНЯТЬ ОХРАНУ", b"guard_disarm")],
        [Button.inline("👂 Послушать комнату (10 сек)", b"action_listen")]
    ]
    await client.send_message(chat_id, text, buttons=buttons)

def guard_monitor(loop, client, chat_id):
    global guard_active, guard_triggered
    log("PC Guard monitor thread started.")
    last_x, last_y = get_mouse_pos()

    key_pressed = [False]
    def on_key(e):
        if guard_active and not guard_triggered:
            key_pressed[0] = True
    try:
        keyboard.hook(on_key)
    except Exception as e:
        log(f"Keyboard hook error: {e}")

    # 3 seconds grace period to release mouse & keyboard
    time.sleep(3)
    last_x, last_y = get_mouse_pos()
    key_pressed[0] = False

    while guard_active and not guard_triggered:
        time.sleep(0.2)
        if not guard_active:
            break
        cur_x, cur_y = get_mouse_pos()
        dist = ((cur_x - last_x)**2 + (cur_y - last_y)**2)**0.5
        if dist > 25 or key_pressed[0]:
            log(f"Guard triggered! Dist: {dist}, Key: {key_pressed[0]}")
            asyncio.run_coroutine_threadsafe(trigger_guard_alarm(client, chat_id), loop)
            break

    try:
        keyboard.unhook(on_key)
    except Exception:
        pass
    log("PC Guard monitor thread stopped.")

def start_guard(loop, client, chat_id):
    global guard_active, guard_triggered, guard_thread
    if guard_active:
        return False
    guard_active = True
    guard_triggered = False
    guard_thread = threading.Thread(target=guard_monitor, args=(loop, client, chat_id), daemon=True)
    guard_thread.start()
    return True

def stop_guard():
    global guard_active, guard_triggered
    guard_active = False
    guard_triggered = False
    stop_siren()

async def timer_countdown(total_seconds, chat_id, client):
    remaining = total_seconds
    try:
        while remaining > 0:
            mins = remaining // 60
            secs = remaining % 60
            disp_str = f"{mins:02d}{secs:02d}"
            set_screen_text(disp_str)
            await asyncio.sleep(1)
            remaining -= 1

        set_screen_text("0000")
        run_adb("sh /bkupgrade/data/opt/rgb_effects.sh notify")
        play_sound_async("alarm_loud")
        await client.send_message(chat_id, "⏰ **ВРЕМЯ ВЫШЛО! Таймер завершен!**")
        await asyncio.sleep(5)
        run_adb("sh /bkupgrade/data/opt/led_helper.sh clear")
    except asyncio.CancelledError:
        run_adb("sh /bkupgrade/data/opt/led_helper.sh clear")
        run_adb("sh /bkupgrade/data/opt/rgb_effects.sh restore")
        await client.send_message(chat_id, "⏹️ **Таймер остановлен.**")

def start_siren():
    global siren_active
    siren_active = True
    set_screen_text("ALRM")
    run_adb("sh /bkupgrade/data/opt/rgb_effects.sh police 0.05")
    play_sound_async("alarm_loud")

def stop_siren():
    global siren_active
    siren_active = False
    run_adb("killall -9 aplay 2>/dev/null")
    run_adb("sh /bkupgrade/data/opt/rgb_effects.sh stop")
    run_adb("sh /bkupgrade/data/opt/led_helper.sh clear")

# =========================================================================
# Dialogue / Chat History Database & Realtime Watcher
# =========================================================================
HISTORY_FILE = os.path.join(BASE_DIR, "dialog_history.json")

def load_dialog_history():
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            log(f"History load error: {e}")
    return {}

def save_dialog_history(data):
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"History save error: {e}")

def add_dialog_event(user_text, alice_text, event_type="voice", date_str=None, time_str=None):
    if not date_str:
        date_str = time.strftime("%d.%m.%y")
    if not time_str:
        time_str = time.strftime("%H:%M:%S")
    history = load_dialog_history()
    if date_str not in history:
        history[date_str] = []

    # Deduplicate within last 5 entries for the same date
    for item in history[date_str][-5:]:
        if item.get("time") == time_str and item.get("user") == user_text:
            return

    history[date_str].append({
        "time": time_str,
        "user": user_text,
        "alice": alice_text,
        "type": event_type
    })
    save_dialog_history(history)

def _dialog_log_watcher():
    last_seen_lines = set()
    while True:
        try:
            time.sleep(15)
            ret, out = run_adb("tail -n 25 /bkupgrade/data/quasar/daemons_logs/maind.log 2>/dev/null", timeout=8)
            if not out:
                continue
            for line in out.splitlines():
                line = line.strip()
                if not line or line in last_seen_lines:
                    continue
                last_seen_lines.add(line)
                if len(last_seen_lines) > 200:
                    last_seen_lines = set(list(last_seen_lines)[-100:])

                m_time = re.search(r'\[(\d{4})-(\d{2})-(\d{2})\s+(\d{2}:\d{2}:\d{2})', line)
                if not m_time:
                    continue
                yr, mo, dy, hms = m_time.group(1)[2:], m_time.group(2), m_time.group(3), m_time.group(4)
                d_str = f"{dy}.{mo}.{yr}"
                t_str = hms

                if "AudioPlayerPlayDirectiveType" in line or "music_play" in line or "audio_play" in line:
                    add_dialog_event(
                        "Алиса, включи музыку",
                        "Включаю трек на Яндекс Музыке 🎵",
                        event_type="music",
                        date_str=d_str,
                        time_str=t_str
                    )
                elif "alarm" in line or "timer" in line:
                    add_dialog_event(
                        "Алиса, поставь таймер / будильник",
                        "Таймер / будильник успешно установлен ⏱️",
                        event_type="timer",
                        date_str=d_str,
                        time_str=t_str
                    )
                elif "volume" in line or "Volume" in line:
                    add_dialog_event(
                        "Алиса, измени громкость",
                        "Громкость колонки настроена 🔊",
                        event_type="command",
                        date_str=d_str,
                        time_str=t_str
                    )
                elif "onStartVinsRequest" in line and "VoiceInput" in line:
                    add_dialog_event(
                        "Голосовой вопрос к Алисе",
                        "Ответ озвучен вслух через динамик Станции 🗣️",
                        event_type="voice",
                        date_str=d_str,
                        time_str=t_str
                    )
        except Exception:
            pass

def get_voice_walkie_menu():
    text = (
        "🎙️ **Режим рации (Голосовое сообщение на колонку)**\n\n"
        "Зажмите кнопку микрофона 🎤 (или кружочка ⚪) в Telegram, наговорите сообщение и отправьте прямо в этот чат!\n\n"
        "▶️ **Как работает рация:**\n"
        "1. Станция мгновенно включит бирюзовую подсветку и громко воспроизведет ваш голос прямо в комнате.\n"
        "2. Сразу после окончания сообщения колонка запишет **5 секунд ответа / реакции** из комнаты через 8 микрофонов и пришлет вам аудиозапись в ответ!\n\n"
        "💡 *Вы можете наговаривать и слать голосовые в любой момент прямо в чат без захода в это меню.*"
    )
    buttons = [
        [Button.inline("⬅️ В главное меню", b"menu_main")]
    ]
    return text, buttons

def get_history_dates_menu():
    history = load_dialog_history()
    dates = list(history.keys())
    def parse_d(d):
        try:
            parts = d.split(".")
            return (int("20" + parts[2]), int(parts[1]), int(parts[0]))
        except Exception:
            return (0, 0, 0)
    dates.sort(key=parse_d, reverse=True)

    today_str = time.strftime("%d.%m.%y")
    text = (
        "💬 **История запросов и диалогов с Алисой**\n\n"
        "Выберите дату, чтобы просмотреть все голосовые вопросы, команды и ответы Станции за этот день:\n"
    )
    buttons = []
    row = []
    for d in dates:
        count = len(history[d])
        label = f"📅 {d} (Сегодня: {count})" if d == today_str else f"📅 {d} ({count})"
        cb = f"hd_{d}".encode("utf-8")
        row.append(Button.inline(label, cb))
        if len(row) == 2:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)

    buttons.append([
        Button.inline("🔄 Обновить", b"menu_history"),
        Button.inline("⬅️ В главное меню", b"menu_main")
    ])
    return text, buttons

def get_history_day_view(date_str):
    history = load_dialog_history()
    entries = history.get(date_str, [])
    total = len(entries)

    if not entries:
        text = f"📅 **История диалогов за {date_str}**\n\nВ этот день обращений к колонке не зафиксировано."
    else:
        text = (
            f"📅 **История диалогов за {date_str}**\n"
            f"Всего запросов за день: **{total}**\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
        )
        for e in entries:
            t = e.get("time", "--:--:--")
            u = e.get("user", "")
            a = e.get("alice", "")
            entry_str = f"`[{t}]` 🗣️ **Вы:** «{u}»\n└ 🤖 **Алиса:** «{a}»\n\n"
            if len(text) + len(entry_str) > 3800:
                text += f"... *(показаны записи из {total})*\n"
                break
            text += entry_str

    buttons = [
        [Button.inline("📅 К выбору даты", b"menu_history")],
        [Button.inline("⬅️ В главное меню", b"menu_main")]
    ]
    return text, buttons

# Menus and Keyboards
def get_main_menu():
    guard_label = "ВКЛ 🔴" if guard_active else "ВЫКЛ ⚪"
    text = (
        "🤖 **Центр управления Яндекс Станцией Мини 3**\n\n"
        f"📡 **Статус:** `Онлайн` ({TARGET})\n"
        f"🛡️ **Охрана ПК:** `{guard_label}`\n\n"
        "Выбери нужный раздел кнопками ниже:"
    )
    buttons = [
        [Button.inline("🎙️ Голосовое на колонку", b"action_voice_walkie"), Button.inline("💬 История диалогов", b"menu_history")],
        [Button.inline("🌈 Верхнее кольцо (RGB)", b"menu_rgb"), Button.inline("⏰ Экран и Циферблат", b"menu_screen")],
        [Button.inline("🔊 Саундборд и Мемы", b"menu_audio"), Button.inline("⏱️ Таймер / Будильник", b"menu_timer")],
        [Button.inline("👂 Прослушка (10 сек)", b"action_listen"), Button.inline(f"🛡️ Охрана ПК: {guard_label}", b"menu_guard")],
        [Button.inline("🚨 ГРОМКАЯ СИРЕНА", b"menu_siren"), Button.inline("🗣️ Сказать вслух (TTS)", b"action_tts")],
        [Button.inline("⚡ Система / Fastfetch", b"menu_sys"), Button.inline("🔄 Обновить", b"menu_main")]
    ]
    return text, buttons

def get_guard_menu():
    status_str = "🔴 ВКЛЮЧЕНА (Компьютер на охране!)" if guard_active else "⚪ Выключена"
    if guard_triggered:
        status_str = "🚨 ТРЕВОГА! БЫЛО ДВИЖЕНИЕ!"
    text = (
        "🛡️ **Охранная система компьютера (Anti-Theft Guard)**\n\n"
        f"Статус охраны: **{status_str}**\n\n"
        "Когда охрана включена, скрипт отслеживает любое движение мыши "
        "или нажатие клавиш на твоем ПК. При малейшей активности колонка "
        "врубает сирену на 100% громкости и присылает тревогу в Telegram."
    )
    if guard_active or guard_triggered:
        buttons = [
            [Button.inline("🔓 Снять компьютер с охраны", b"guard_off")],
            [Button.inline("⬅️ В главное меню", b"menu_main")]
        ]
    else:
        buttons = [
            [Button.inline("🔒 ВКЛЮЧИТЬ ОХРАНУ ПК", b"guard_on")],
            [Button.inline("⬅️ В главное меню", b"menu_main")]
        ]
    return text, buttons

def get_rgb_menu():
    text = "🌈 **Управление подсветкой верхнего кольца**\nВыбери анимацию или цвет:"
    buttons = [
        [Button.inline("🌈 Радуга", b"rgb_rainbow"), Button.inline("💜 Дыхание", b"rgb_breathe")],
        [Button.inline("🌀 Спин", b"rgb_spin"), Button.inline("🚨 Полиция", b"rgb_police")],
        [Button.inline("⚡ Вспышка", b"rgb_notify"), Button.inline("⏹️ Выключить RGB", b"rgb_off")],
        [
            Button.inline("🔴", b"rgb_c_red"),
            Button.inline("🟢", b"rgb_c_green"),
            Button.inline("🔵", b"rgb_c_blue"),
            Button.inline("🟣", b"rgb_c_purple")
        ],
        [
            Button.inline("🟡", b"rgb_c_orange"),
            Button.inline("🩵", b"rgb_c_cyan"),
            Button.inline("🌸", b"rgb_c_pink"),
            Button.inline("⚪", b"rgb_c_white")
        ],
        [Button.inline("⬅️ В главное меню", b"menu_main")]
    ]
    return text, buttons

def get_screen_menu():
    text = "⏰ **Управление экраном и циферблатом**\nПресеты, мордочки и яркость:"
    buttons = [
        [Button.inline("1337", b"scr_1337"), Button.inline("COOL", b"scr_cool"), Button.inline("2026", b"scr_2026"), Button.inline("HELP", b"scr_help")],
        [Button.inline("(=^.^=) Кот", b"scr_cat"), Button.inline("(^_^) Счастье", b"scr_happy"), Button.inline("(uwu)", b"scr_uwu")],
        [Button.inline("🔆 100% Яркость (Обход ALS)", b"scr_bright_max"), Button.inline("🌙 Ночь 10%", b"scr_bright_night")],
        [Button.inline("✍️ Ввести свой текст", b"scr_custom"), Button.inline("⏹️ Очистить", b"scr_clear")],
        [Button.inline("⬅️ В главное меню", b"menu_main")]
    ]
    return text, buttons

def get_audio_menu():
    text = (
        "🔊 **Саундборд и Мемные звуки**\n"
        "Нажми на кнопку для моментального воспроизведения на колонке:"
    )
    buttons = [
        [Button.inline("🗿 Bruh", b"snd_bruh"), Button.inline("💥 Vine Boom", b"snd_vine_boom")],
        [Button.inline("🔩 Metal Pipe", b"snd_metal_pipe"), Button.inline("💨 Fart Reverb", b"snd_fart")],
        [Button.inline("💬 Discord", b"snd_discord"), Button.inline("💻 Windows XP", b"snd_winxp")],
        [Button.inline("📢 MLG Airhorn", b"snd_airhorn"), Button.inline("❌ Win Error", b"snd_win_error")],
        [Button.inline("🕺 Rickroll", b"snd_rickroll"), Button.inline("❓ What?!", b"snd_what")],
        [Button.inline("🔔 Telegram", b"snd_telegram"), Button.inline("🚨 Полиция", b"snd_siren")],
        [Button.inline("⬅️ В главное меню", b"menu_main")]
    ]
    return text, buttons

def get_siren_menu():
    status_str = "🔴 ВКЛЮЧЕНА!" if siren_active else "⚪ Выключена"
    text = (
        "🚨 **Экстренная громкая сирена**\n\n"
        f"Текущий статус: **{status_str}**\n\n"
        "Включает полицейский стробоскоп верхнего кольца, надпись `ALRM` "
        "на часах и непрерывный громкий вой сирены на полную мощность."
    )
    buttons = [
        [Button.inline("🚨 ВКЛЮЧИТЬ СИРЕНУ", b"siren_on")],
        [Button.inline("⏹️ ВЫКЛЮЧИТЬ ТРЕВОГУ", b"siren_off")],
        [Button.inline("⬅️ В главное меню", b"menu_main")]
    ]
    return text, buttons

def get_timer_menu():
    text = (
        "⏱️ **Таймер / Будильник с обратным отсчетом на часах**\n\n"
        "Выбери готовое время или отправь команду `/alarm 10m` / `/alarm 30s`.\n"
        "Время будет тикать прямо на лицевом дисплее Станции!"
    )
    buttons = [
        [Button.inline("⏱️ 1 мин", b"tmr_60"), Button.inline("⏱️ 3 мин", b"tmr_180"), Button.inline("⏱️ 5 мин", b"tmr_300")],
        [Button.inline("⏱️ 10 мин", b"tmr_600"), Button.inline("⏱️ 15 мин", b"tmr_900"), Button.inline("⏱️ 30 мин", b"tmr_1800")],
        [Button.inline("⏹️ ОСТАНОВИТЬ ТАЙМЕР", b"tmr_stop")],
        [Button.inline("⬅️ В главное меню", b"menu_main")]
    ]
    return text, buttons

def get_system_menu():
    text = (
        "⚡ **Система и Диагностика Станции**\n"
        "Выбери нужную операцию:"
    )
    buttons = [
        [Button.inline("📊 Fastfetch (Характеристики)", b"sys_fastfetch")],
        [Button.inline("💾 Память и Диск (df / free)", b"sys_storage")],
        [Button.inline("🔄 Перезагрузить Станцию", b"sys_reboot_ask")],
        [Button.inline("⬅️ В главное меню", b"menu_main")]
    ]
    return text, buttons

async def main():
    global active_timer_task
    log("=" * 60)
    log("Starting Ultimate Control Bot v2.1 (Intercom + Guard)...")
    ensure_adb()

    client = TelegramClient(
        SESSION_PATH,
        API_ID,
        API_HASH
    )

    await client.start(bot_token=BOT_TOKEN)
    me = await client.get_me()
    log(f"Bot online as @{me.username} [ID: {me.id}]")

    t_watcher = threading.Thread(target=_dialog_log_watcher, daemon=True)
    t_watcher.start()
    log("Live dialog log watcher thread started.")

    @client.on(events.NewMessage)
    async def message_handler(event):
        global active_timer_task
        sender_id = event.sender_id
        if sender_id != ADMIN_ID:
            log(f"Unauthorized message from user {sender_id}")
            await event.reply("⛔ **Доступ запрещен!**\nЭтот бот управляет персональной Яндекс Станцией.")
            return

        # Voice note / Audio from user (Intercom Walkie-Talkie)
        if event.voice or event.audio:
            log("Received voice message from user.")
            status_msg = await event.reply("🎙️ **Получено голосовое сообщение!**\n▶️ Воспроизвожу на колонке...")
            ogg_path = os.path.join(BASE_DIR, "temp_voice_in.ogg")
            wav_path = os.path.join(BASE_DIR, "temp_voice_in.wav")
            await event.download_media(file=ogg_path)

            try:
                data, sr = sf.read(ogg_path)
                sf.write(wav_path, data, sr, subtype='PCM_16', format='WAV')
                add_dialog_event("🎙️ Голосовое сообщение через Telegram (Рация)", "Голос озвучен в комнате + записан ответ 5 сек.", event_type="intercom")

                run_adb("sh /bkupgrade/data/opt/rgb_effects.sh static 0 255 255")
                subprocess.run([ADB_PATH, "-s", TARGET, "push", wav_path, "/bkupgrade/data/opt/sounds/voice_in.wav"], capture_output=True)
                subprocess.run([ADB_PATH, "-s", TARGET, "shell", "aplay /bkupgrade/data/opt/sounds/voice_in.wav"], capture_output=True, timeout=60)
            except Exception as e:
                log(f"Voice playback error: {e}")
                await status_msg.edit(f"❌ Ошибка воспроизведения голосового: {e}")
                return

            # Record 5 seconds response immediately
            await status_msg.edit("🎙️ **Голосовое воспроизведено в комнате!**\n👂 Записываю реакцию / ответ (5 сек)...")
            loop = asyncio.get_event_loop()
            mono_reply = await loop.run_in_executor(None, lambda: record_room_mono(5, "reply_room_5s.wav"))

            if mono_reply and os.path.exists(mono_reply):
                await client.send_file(
                    event.chat_id,
                    mono_reply,
                    voice_note=True,
                    caption="🎙️ **Ответ из комнаты (последние 5 сек):**"
                )
                await status_msg.delete()
            else:
                await status_msg.edit("✅ Голосовое воспроизведено! (Ответ записать не удалось)")

            run_adb("sh /bkupgrade/data/opt/rgb_effects.sh restore")
            return

        text = (event.raw_text or "").strip()

        # Handle user text prompts
        if sender_id in waiting_for_action:
            action = waiting_for_action.pop(sender_id)
            if action == "tts":
                await event.reply(f"🗣️ **Озвучиваю через колонку:** *«{text}»*...")
                generate_and_speak(text)
                add_dialog_event(f"Озвучить текст: «{text}»", "Воспроизведено вслух через динамик Станции", event_type="tts")
                await event.reply("✅ Готово!")
                return
            elif action == "screen":
                set_screen_text(text)
                await event.reply(f"✅ На экран выведено: **{text[:4].upper()}**")
                return

        # /say command
        if text.startswith("/say "):
            speech_text = text[5:].strip()
            if speech_text:
                await event.reply(f"🗣️ **Произношу вслух:** *«{speech_text}»*...")
                generate_and_speak(speech_text)
                add_dialog_event(f"Озвучить текст: «{speech_text}»", "Воспроизведено вслух через динамик Станции", event_type="tts")
                await event.reply("✅ Готово!")
                return

        # /listen command
        if text == "/listen" or text.startswith("/listen "):
            secs = 10
            if text.startswith("/listen "):
                arg = text.split()[1]
                if arg.isdigit():
                    secs = min(max(int(arg), 3), 30)
            msg = await event.reply(f"👂 **Слушаю комнату через микрофоны ({secs} сек)...**")
            add_dialog_event(f"Дистанционная прослушка ({secs} сек)", "Запись с микрофонов отправлена в Telegram", event_type="listen")
            loop = asyncio.get_event_loop()
            mono_file = await loop.run_in_executor(None, lambda: record_room_mono(secs, "listen_room.wav"))
            if mono_file and os.path.exists(mono_file):
                await msg.delete()
                await client.send_file(
                    event.chat_id,
                    mono_file,
                    voice_note=True,
                    caption=f"👂 **Запись из комнаты ({secs} секунд):**"
                )
            else:
                await msg.edit("⚠️ Не удалось получить запись с микрофонов.")
            return

        # /guard command
        if text.startswith("/guard"):
            parts = text.split()
            loop = asyncio.get_event_loop()
            if len(parts) > 1 and parts[1].lower() in ["on", "1", "вкл"]:
                start_guard(loop, client, event.chat_id)
                await event.reply("🔒 **Охрана ПК активирована!** У вас 3 секунды убрать руку от мыши.")
            elif len(parts) > 1 and parts[1].lower() in ["off", "0", "выкл"]:
                stop_guard()
                await event.reply("🔓 **Охрана ПК отключена.**")
            else:
                m_text, m_btns = get_guard_menu()
                await event.reply(m_text, buttons=m_btns)
            return

        # /screen command
        if text.startswith("/screen "):
            scr_val = text[8:].strip()
            if scr_val.lower() == "clear":
                run_adb("sh /bkupgrade/data/opt/led_helper.sh clear")
                await event.reply("⏹️ Экран очищен.")
            elif scr_val.lower() == "uwu":
                run_adb("sh /bkupgrade/data/opt/led_helper.sh face uwu")
                await event.reply("🥺 Мордочка uwu выведена.")
            elif scr_val.lower() == "cat":
                run_adb("sh /bkupgrade/data/opt/led_helper.sh face cool")
                await event.reply("😺 Котик выведен.")
            else:
                set_screen_text(scr_val)
                await event.reply(f"✅ Выведено на экран: `{scr_val[:4].upper()}`")
            return

        # /sound command
        if text.startswith("/sound "):
            sname = text[7:].strip().lower()
            alias = {
                "bruh": "bruh",
                "boom": "vine_boom",
                "vine": "vine_boom",
                "pipe": "metal_pipe",
                "metal": "metal_pipe",
                "metal_pipe": "metal_pipe",
                "discord": "discord",
                "fart": "fart",
                "winxp": "winxp",
                "xp": "winxp",
                "airhorn": "airhorn",
                "error": "win_error",
                "win_error": "win_error",
                "rickroll": "rickroll",
                "rick": "rickroll",
                "what": "what",
                "alarm": "alarm_loud",
                "siren": "siren",
                "tg": "telegram",
                "telegram": "telegram"
            }
            if sname in alias:
                play_sound_async(alias[sname])
                await event.reply(f"🔊 Играет звук: **{alias[sname]}**")
            else:
                await event.reply(f"❌ Неизвестный звук '{sname}'. Доступно: bruh, boom, pipe, discord, fart, winxp, airhorn, error, rickroll, what, siren, alarm")
            return

        # /alarm or /timer command
        if text.startswith("/alarm ") or text.startswith("/timer "):
            arg = text.split(maxsplit=1)[1].strip().lower()
            seconds = 0
            if arg.endswith("m"):
                seconds = int(arg[:-1]) * 60
            elif arg.endswith("s"):
                seconds = int(arg[:-1])
            elif arg.isdigit():
                seconds = int(arg) * 60

            if seconds > 0:
                if active_timer_task and not active_timer_task.done():
                    active_timer_task.cancel()
                active_timer_task = asyncio.create_task(timer_countdown(seconds, event.chat_id, client))
                await event.reply(f"⏱️ **Таймер на {seconds} сек запущен!** Отсчет отображается на экране колонки.")
                return
            else:
                await event.reply("❌ Неверный формат. Используй: `/alarm 5m` или `/alarm 30s`")
                return

        if text.startswith("/siren"):
            start_siren()
            await event.reply("🚨 **СИРЕНА ВКЛЮЧЕНА!**")
            return

        if text.startswith("/stop"):
            stop_siren()
            stop_guard()
            if active_timer_task and not active_timer_task.done():
                active_timer_task.cancel()
            await event.reply("⏹️ **Все звуки, сирена, охрана и таймеры остановлены.**")
            return

        if text.startswith("/history"):
            text_menu, btns = get_history_dates_menu()
            await event.reply(text_menu, buttons=btns)
            return

        if text.startswith("/start") or text.startswith("/menu"):
            m_text, m_btns = get_main_menu()
            await event.reply(m_text, buttons=m_btns)
            return

        # Direct short words on screen
        if len(text) <= 4:
            set_screen_text(text)
            await event.reply(f"✅ Выведено на экран: `{text.upper()}`")
            return

        # Fallback to main menu
        m_text, m_btns = get_main_menu()
        await event.reply(m_text, buttons=m_btns)

    @client.on(events.CallbackQuery)
    async def callback_handler(event):
        global active_timer_task
        if event.sender_id != ADMIN_ID:
            await event.answer("⛔ Доступ запрещен!", alert=True)
            return

        data = event.data.decode("utf-8")
        log(f"Callback: {data}")

        # Navigation
        if data == "menu_main":
            text, btns = get_main_menu()
            await event.edit(text, buttons=btns)
            await event.answer()
            return
        elif data == "menu_history":
            text, btns = get_history_dates_menu()
            await event.edit(text, buttons=btns)
            await event.answer()
            return
        elif data.startswith("hd_"):
            chosen_date = data[3:]
            text, btns = get_history_day_view(chosen_date)
            await event.edit(text, buttons=btns)
            await event.answer()
            return
        elif data == "action_voice_walkie":
            text, btns = get_voice_walkie_menu()
            await event.edit(text, buttons=btns)
            await event.answer()
            return
        elif data == "menu_rgb":
            text, btns = get_rgb_menu()
            await event.edit(text, buttons=btns)
            await event.answer()
            return
        elif data == "menu_screen":
            text, btns = get_screen_menu()
            await event.edit(text, buttons=btns)
            await event.answer()
            return
        elif data == "menu_audio":
            text, btns = get_audio_menu()
            await event.edit(text, buttons=btns)
            await event.answer()
            return
        elif data == "menu_siren":
            text, btns = get_siren_menu()
            await event.edit(text, buttons=btns)
            await event.answer()
            return
        elif data == "menu_timer":
            text, btns = get_timer_menu()
            await event.edit(text, buttons=btns)
            await event.answer()
            return
        elif data == "menu_guard":
            text, btns = get_guard_menu()
            await event.edit(text, buttons=btns)
            await event.answer()
            return
        elif data == "menu_sys":
            text, btns = get_system_menu()
            await event.edit(text, buttons=btns)
            await event.answer()
            return

        # Listen Room action
        if data == "action_listen":
            await event.answer("👂 Включаю запись с микрофонов...")
            msg = await client.send_message(event.chat_id, "👂 **Слушаю комнату через микрофоны Станции (10 сек)...**")
            loop = asyncio.get_event_loop()
            mono_file = await loop.run_in_executor(None, lambda: record_room_mono(10, "listen_room.wav"))
            if mono_file and os.path.exists(mono_file):
                await msg.delete()
                await client.send_file(
                    event.chat_id,
                    mono_file,
                    voice_note=True,
                    caption="👂 **Запись из комнаты (10 секунд):**"
                )
            else:
                await msg.edit("⚠️ Не удалось получить запись с микрофонов.")
            return

        # Guard actions
        if data == "guard_on":
            loop = asyncio.get_event_loop()
            start_guard(loop, client, event.chat_id)
            text, btns = get_guard_menu()
            await event.edit(text, buttons=btns)
            await event.answer("🔒 Охрана ПК активирована! У вас 3 секунды убрать руку от мыши.", alert=True)
            return
        elif data in ["guard_off", "guard_disarm"]:
            stop_guard()
            text, btns = get_guard_menu()
            try:
                await event.edit(text, buttons=btns)
            except Exception:
                await client.send_message(event.chat_id, "🔓 **Компьютер снят с охраны.** Тревога выключена.")
            await event.answer("🔓 Охрана снята.")
            return

        # Siren actions
        if data == "siren_on":
            start_siren()
            text, btns = get_siren_menu()
            await event.edit(text, buttons=btns)
            await event.answer("🚨 СИРЕНА ВКЛЮЧЕНА!")
            return
        elif data == "siren_off":
            stop_siren()
            text, btns = get_siren_menu()
            await event.edit(text, buttons=btns)
            await event.answer("⏹️ Сирена выключена.")
            return

        # Soundboard actions
        if data.startswith("snd_"):
            sound_name = data[4:]
            play_sound_async(sound_name)
            await event.answer(f"🔊 Играет: {sound_name}!")
            return

        # TTS action
        if data == "action_tts":
            waiting_for_action[event.sender_id] = "tts"
            await event.respond("🗣️ **Отправь мне текст, который колонка должна сказать вслух:**")
            await event.answer()
            return

        # Timer actions
        if data.startswith("tmr_"):
            val = data[4:]
            if val == "stop":
                if active_timer_task and not active_timer_task.done():
                    active_timer_task.cancel()
                await event.answer("⏹️ Таймер отменен!")
            elif val.isdigit():
                sec = int(val)
                if active_timer_task and not active_timer_task.done():
                    active_timer_task.cancel()
                active_timer_task = asyncio.create_task(timer_countdown(sec, event.chat_id, client))
                await event.answer(f"⏱️ Таймер на {sec//60} мин запущен!")
            return

        # RGB actions
        if data == "rgb_rainbow":
            run_adb("sh /bkupgrade/data/opt/rgb_effects.sh rainbow 0.08")
            await event.answer("🌈 Радуга запущена!")
            return
        elif data == "rgb_breathe":
            run_adb("sh /bkupgrade/data/opt/rgb_effects.sh breathe 180 0 255 0.04")
            await event.answer("💜 Пульсация запущена!")
            return
        elif data == "rgb_spin":
            run_adb("sh /bkupgrade/data/opt/rgb_effects.sh spin 0.08")
            await event.answer("🌀 Спин запущен!")
            return
        elif data == "rgb_police":
            run_adb("sh /bkupgrade/data/opt/rgb_effects.sh police 0.08")
            await event.answer("🚨 Полиция!")
            return
        elif data == "rgb_notify":
            run_adb("sh /bkupgrade/data/opt/rgb_effects.sh notify")
            await event.answer("⚡ Вспышка!")
            return
        elif data == "rgb_off":
            run_adb("sh /bkupgrade/data/opt/rgb_effects.sh stop")
            await event.answer("⏹️ Подсветка выключена")
            return
        elif data.startswith("rgb_c_"):
            color = data[6:]
            colors = {
                "red": "255 0 0",
                "green": "0 255 0",
                "blue": "0 0 255",
                "purple": "180 0 255",
                "orange": "255 80 0",
                "cyan": "0 255 255",
                "pink": "255 20 147",
                "white": "255 255 255"
            }
            if color in colors:
                run_adb(f"sh /bkupgrade/data/opt/rgb_effects.sh static {colors[color]}")
                await event.answer(f"🎨 Цвет {color.capitalize()}!")
            return

        # Screen actions
        if data in ["scr_1337", "scr_cool", "scr_2026", "scr_help"]:
            txt = data[4:].upper()
            set_screen_text(txt)
            await event.answer(f"🔢 {txt} на экране")
            return
        elif data == "scr_cat":
            run_adb("sh /bkupgrade/data/opt/led_helper.sh face cool")
            await event.answer("😺 Котик")
            return
        elif data == "scr_happy":
            run_adb("sh /bkupgrade/data/opt/led_helper.sh face bigsmile")
            await event.answer("😊 Счастье")
            return
        elif data == "scr_uwu":
            run_adb("sh /bkupgrade/data/opt/led_helper.sh face uwu")
            await event.answer("🥺 uwu")
            return
        elif data == "scr_bright_max":
            run_adb("sh /bkupgrade/data/opt/led_helper.sh max")
            await event.answer("🔆 100% Яркость (обход ALS)!")
            return
        elif data == "scr_bright_night":
            run_adb("sh /bkupgrade/data/opt/led_helper.sh brightness 25")
            await event.answer("🌙 Ночной режим 10%")
            return
        elif data == "scr_clear":
            run_adb("sh /bkupgrade/data/opt/led_helper.sh clear")
            await event.answer("⏹️ Экран очищен")
            return
        elif data == "scr_custom":
            waiting_for_action[event.sender_id] = "screen"
            await event.respond("✍️ **Отправь мне текст или цифры (до 4 символов) для экрана:**")
            await event.answer()
            return

        # System actions
        if data == "sys_fastfetch":
            await event.answer("⏳ Запуск fastfetch...")
            _, out = run_adb("/usr/bin/fastfetch 2>/dev/null || /bkupgrade/data/opt/fastfetch", timeout=12)
            if out:
                clean = re.sub(r'\x1b\[[0-9;]*m', '', out)
                await event.respond(f"```text\n{clean}\n```")
            else:
                await event.respond("⚠️ Fastfetch не вернул данные.")
            return

        if data == "sys_storage":
            await event.answer("⏳ Чтение памяти...")
            _, disk = run_adb("df -h / /bkupgrade")
            _, mem = run_adb("free -m")
            _, upt = run_adb("uptime")
            reply = f"**💾 Диск:**\n```\n{disk}\n```\n**🧠 ОЗУ:**\n```\n{mem}\n```\n**⏱️ Аптайм:**\n`{upt}`"
            await event.respond(reply)
            return

        if data == "sys_reboot_ask":
            confirm_btns = [
                [Button.inline("⚠️ ДА, ПЕРЕЗАГРУЗИТЬ", b"sys_reboot_confirm")],
                [Button.inline("❌ Отмена", b"menu_sys")]
            ]
            await event.edit("⚠️ **Действительно перезагрузить Станцию?**", buttons=confirm_btns)
            await event.answer()
            return

        if data == "sys_reboot_confirm":
            await event.answer("🔄 Перезагрузка...")
            run_adb("reboot")
            await event.edit("🔄 **Команда reboot отправлена на Станцию.**", buttons=[[Button.inline("⬅️ В главное меню", b"menu_main")]])
            return

    log("Ultimate Bot v2.1 is listening for all commands, audio, intercom and callbacks...")
    await client.run_until_disconnected()

if __name__ == "__main__":
    while True:
        try:
            asyncio.run(main())
        except Exception as e:
            log(f"Crash: {e}. Retrying in 5 seconds...")
            time.sleep(5)
